3D Shape Reconstruction from Sketches via Multi-view Convolutional Networks
Supplementary Material

Zhaoliang Lun, Matheus Gadelha, Evangelos Kalogerakis, Subhransu Maji, Rui Wang
University of Massachusetts Amherst

1. Supplementary material document (please read first)
	- supplementary.pdf
2. User study results
	- user-study.pdf
3. Comparison with variants of our method - Character Models
	- variant-character.pdf
4. Comparison with variants of our method - Chair Models
	- variant-chair.pdf
5. Comparison with variants of our method - Airplane Models
	- variant-plane.pdf
6. Comparison with alternative methods - Character Models
	- baseline-character.pdf
7. Comparison with alternative methods - Chair Models
	- baseline-chair.pdf
8. Comparison with alternative methods - Airplane Models
	- baseline-plane.pdf

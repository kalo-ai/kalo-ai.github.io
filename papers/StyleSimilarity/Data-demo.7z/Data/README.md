# Elements of Style: Learning Perceptual Shape Style Similarity

[Project Page](http://people.cs.umass.edu/~zlun/papers/StyleSimilarity)

## Introduction

This archive contains 3D shape data and user study data used for the Style Similarity project.

## Data Sets

- We have collected data sets of different shape categories, organized in sub-folders named after the category name. See the paper for more details on how we collect our data sets
- Due to license restriction, we cannot release the meshes for category `coffeeset` in the paper
- The `demo` data set contains minimum data to run the algorithm. It's provided for demonstration purpose only

## 3D Shape Data

- The 3D shape mesh data is in the `mesh` folder inside each data set folder. All 3D shapes in this archive are collected from [3D Warehouse](https://3dwarehouse.sketchup.com/)
- All 3D shape mesh data are converted and organized in [PLY file format](http://paulbourke.net/dataformats/ply/)

## User Study Data

- The user study data is in the `response` folder inside each data set folder
- File `triplets.txt` contains all triplets of the data set. Each line in this file describes the names of mesh A, mesh B and mesh C of one triplet. See the paper for detail on how we select these triplets
- File `tripletDistribution.txt` contains the distribution of answers to the query triplets. Each line corresponds to one triplet. The four numbers of each line indicate the number of users who answer *A*, *B*, *Both* or *Neither* to the query. See the paper for more details on how we conduct the user study

## Copyright

All 3D shape models are downloaded from the Internet and the original authors hold the copyright of the models. The user study data was obtained by us via Amazon Mechanical Turk service and it is provided freely. This data set is provided for the convenience of academic research only

## Other Notes

- If you would like to use our data, please cite the following paper:

> Zhaoliang Lun, Evangelos Kalogerakis, Alla Sheffer,
"Elements of Style: Learning Perceptual Shape Style Similarity",
ACM Transactions on Graphics (Proc. ACM SIGGRAPH 2015)

- For any questions or comments, please contact Zhaoliang Lun ([zlun@cs.umass.edu](mailto:zlun@cs.umass.edu))
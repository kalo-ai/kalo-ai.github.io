/*Copyright (C) 2016 Yahan Zhou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "XNode.h"
#include "ZNode.h"
#include "ADMM.h"

using namespace std;
using namespace ADMMLib;

//#define _ZERO_RHO_NEW_RULE

XNode::XNode(int iSize)
	: m_n(iSize, 0)
	, m_x(iSize, 0)
	, m_u(iSize, 0)
	, m_rhoIn(iSize, 0)
	, m_rhoOut(iSize, 0)
	, mp_z(iSize, 0)
{
}


XNode::~XNode(void)
{
}

void XNode::FetchN()
{
	for (int i=0; i<(int)m_n.size(); i++)
	{
		m_n[i] = mp_z[i]->m_z-m_u[i];
#ifdef _ZERO_RHO_NEW_RULE
		if (mp_z[i]->m_rhoOut!=0 && mp_z[i]->m_znonzero==1 && m_rhoOut[i]!=0)
			m_rhoIn[i] = 0;
		else
#endif
			m_rhoIn[i] = mp_z[i]->m_rhoOut;
	}
}

void XNode::SetZInput()
{
	for (int i=0; i<(int)mp_z.size(); i++)
	{
		ZNode* znode = mp_z[i];
		_T_FLOAT val = m_x[i]+m_u[i];
		_T_FLOAT rho = m_rhoOut[i];
		omp_set_lock(&znode->mUpdateLock);
		if (rho==0 && znode->m_znonzero==0)
		{
			znode->m_zsum = val;
		}
		else if (!_finite(rho))
		{
			znode->m_zsum = val;
			znode->m_zweight = rho;
			znode->m_znonzero++;
		}
		else if (rho!=0 && znode->m_znonzero==0)
		{
			znode->m_zsum = val*rho;
			znode->m_zweight = rho;
			znode->m_znonzero++;
		}
		else if (rho!=0 && _finite(znode->m_zweight))
		{
			znode->m_zsum += rho*val;
			znode->m_zweight += rho;
			znode->m_znonzero++;
		}
		omp_unset_lock(&znode->mUpdateLock);
	}
}

void XNode::UpdateU()
{
	for (int i=0; i<(int)m_u.size(); i++)
	if (mp_z[i]->m_znonzero>1
			&& mp_z[i]->m_rhoOut!=0 && _finite(mp_z[i]->m_rhoOut)
			&& m_rhoOut[i]!=0 && _finite(m_rhoOut[i]))
	{
		m_u[i] = m_u[i]*mpADMM->mUDec+mpADMM->mAlpha/mpADMM->mRho*(m_x[i]-mp_z[i]->m_z);
	}
	else
		m_u[i] = 0;
}
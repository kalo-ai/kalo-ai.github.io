/*Copyright (C) 2016 Yahan Zhou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "ZNode.h"
#include <math.h>
#include <float.h>
#include "ADMM.h"

using namespace std;
using namespace ADMMLib;

ZNode::ZNode(void)
	: m_z(0)
	, m_rhoOut(0)
{
	omp_init_lock(&mUpdateLock);
}

ZNode::~ZNode(void)
{
	omp_destroy_lock(&mUpdateLock);
}

void ZNode::UpdateZ()
{
	if (m_zweight!=0 && _finite(m_zweight))
	{
		m_z = m_zsum/m_zweight;
		m_rhoOut = mpADMM->mRho;
	}
	else
	{
		m_z = m_zsum;
		if (m_zweight==0)
			m_rhoOut = 0;
		else
			m_rhoOut = numeric_limits<_T_FLOAT>::infinity();
	}
	//m_zsum = 0;
	//m_zweight = 0;
	//m_znonzero = 0;
}
/*Copyright (C) 2016 Yahan Zhou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#pragma once

#include "..\StaticFEM\Config.h"
#include <vector>
#include <omp.h>

namespace ADMMLib
{

class ADMM;

class ZNode // per value node
{
public:
	ZNode(void);
	~ZNode(void);
	ZNode(ADMM* ipADMM, _T_FLOAT iRho = 0)
		: mpADMM(ipADMM)
		, m_rhoOut(iRho)
	{omp_init_lock(&mUpdateLock);}

	_T_FLOAT m_z;
	_T_FLOAT m_zsum;
	_T_FLOAT m_zweight;
	int m_znonzero;
	_T_FLOAT m_rhoOut;
	void UpdateZ();
	void ResetIntermediate(){m_zsum = 0;m_zweight = 0;m_znonzero = 0;}
	ADMM* mpADMM;
	omp_lock_t mUpdateLock;
};

}
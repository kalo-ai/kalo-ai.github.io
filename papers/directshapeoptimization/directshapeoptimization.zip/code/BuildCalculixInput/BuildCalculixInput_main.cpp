/*Copyright (C) 2016 Yahan Zhou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "..\SSSLib\SSSLibOGL\SSSVolMesh.h"
#include <fstream>

using namespace std;
using namespace SSSLib;

int main(int argc, char* argv[])
{
	SSSVolMesh mesh;
	mesh.LoadVolMesh(argv[1]);
	mesh.Rotate(Vec3f(1.0f, 0, 0), -Pi/2);
	mesh.BuildSurfaceMesh();
	Vec3d low, high;
	mesh.mSurfaceMesh.ComputeBB(low, high);
	double lowBar = low[1]+(high[1]-low[1])*0.01;
	// save abaqus mesh
	mesh.WriteAbaqusMsh(argv[2]);
	// save boundary condition
	if (argc>3)
	{
		ofstream outFile(argv[3]);
		outFile<<"** Names based on fix\n"
				<<"*NSET,NSET=Nfix\n";
		for (int v=0; v<(int)mesh.mVtx.size(); v++)
		if (mesh.mVtx[v][1]<lowBar)
			outFile<<v+1<<",\n";
	}
	if (argc>4)
		mesh.mSurfaceMesh.WriteStl(argv[4]);
	return 0;
}

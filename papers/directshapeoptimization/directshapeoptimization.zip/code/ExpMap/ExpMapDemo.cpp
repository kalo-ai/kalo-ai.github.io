// Author: Ryan Schmidt  (rms@unknownroad.com)  http://www.unknownroad.com
// Copyright (c) 2008. All Rights Reserved.
// The ExpMapDemo package is supplied "AS IS". The Author disclaims all warranties, expressed or implied, including, 
// without limitation, the warranties of merchantability and of fitness for any purpose. The Author assume no liability for 
// direct, indirect, incidental, special, exemplary, or consequential damages, which may result from the use of the 
// ExpMapDemo package, even if advised of the possibility of such damage. Permission is hereby granted to use, copy, 
// modify, and distribute this source code, or portions hereof, for any purpose, without fee, subject to the following restrictions:
// 1) The origin of this source code must not be misrepresented.
// 2) This Copyright notice may not be removed or altered from any source or altered source distribution.
// The Author specifically permits, without fee, the use of this source code as a component in commercial products.
// ExpMapDemo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "gl\freeglut.h"
#include "MeshObject.h"
#include <MeshUtils.h>
#include <ExtendedWmlCamera.h>

MeshObject g_mesh;
Wml::ExtendedWmlCamera * g_pCamera = NULL;

// input modes for mouse handler
enum INPUT_MODE {
	NONE,
	DOLLY,
	ORBIT,
	PAN,
	MOVE_EXPMAP_SEED,
	SCALE_EXPMAP,
	ROTATE_EXPMAP,
	DRAW_SURFCUVE,
	MOVE_VERTEX,
	MOVE_SELECTION
};
INPUT_MODE g_inputMode = NONE;


// display layout modes
enum DISPLAY_MODE {
	MESH,
	MESH_AND_QUARTERUV,
	UVONLY,

	LAST_MODE		// leave at the end!
};
DISPLAY_MODE g_displayMode = MESH;

// render flags
bool g_bRenderMeshAsWireframe = false;

// input device state
bool g_bAltButtonDown = false;
bool g_bCtrlButtonDown = false;
bool g_bLeftMouseDown = false;
bool g_bMiddleMouseDown = false;
bool g_bRightMouseDown = false;
bool g_bGotMouseClick = false;
Wml::Vector2f g_vLastMousePos = Wml::Vector2f::ZERO;

std::vector<rms::Frame3f> m_vSurfCurve;

std::string g_outFilename = "data\\out.dat";	// rui
std::string g_cparamFilename; // rui
bool g_interactive = false;	// rui
std::string g_objFilename;	// rui
double g_pdr = 0.01;		// rui
int g_nthres = 10;			// rui
int g_tid = 0;				// rui

enum PROG_ARG {
	PROG_NAME = 0,
	OBJ_NAME,
	PD_RADIUS,
	NR_THRES,
	SAMPLE_METHOD,
	PROG_ITE
};

void 
drawString (char *s)
{
  unsigned int i;
  for (i = 0; i < strlen (s); i++)
    glutBitmapCharacter (GLUT_BITMAP_HELVETICA_10, s[i]);
};


// this is (well, should be) the only platform-dependent bit of code...
void LoadNewMesh(const char * pFilename = NULL, const char *extName = NULL)
{
	std::string sFilename;
	if ( pFilename == NULL ) {
		CFileDialog dialog(TRUE, "obj", "mesh.obj", 0, "OBJ Files (*.obj)|*.obj|All Files (*.*)|*.*", NULL);
		if ( dialog.DoModal() != IDOK ) 
			return;
		sFilename = std::string(dialog.GetPathName());
	} else
		sFilename = std::string(pFilename);

	g_mesh.ReadMeshOBJ(sFilename.c_str());

	if (extName) {

		sFilename = ".\\data\\"+sFilename+extName+".asp";
		g_mesh.ReadASPoints(sFilename.c_str());
	}
}


void ExportMesh(const char * pFilename = NULL)
{
	std::string sFilename;
	if ( pFilename == NULL ) {
		CFileDialog dialog(FALSE, "obj", "export.obj", 0, "OBJ Files (*.obj)|*.obj|All Files (*.*)|*.*", NULL);
		if ( dialog.DoModal() != IDOK ) 
			return;
		sFilename = std::string(dialog.GetPathName());
	} else
		sFilename = std::string(pFilename);
	std::string errString;
	g_mesh.GetMesh().WriteOBJ(sFilename.c_str(), errString);
}


void glut_initgl()
{
	g_pCamera = new Wml::ExtendedWmlCamera(1.0f,1.0f);
	// set default frame (lookat)
	g_pCamera->SetTargetFrame( Wml::Vector3f(0.0, 0.0, 4.0f), 
		Wml::Vector3f(-1.0f, 0.0, 0.0),
		Wml::Vector3f(0.0, 1.0f, 0.0), 
		Wml::Vector3f(0.0, 0.0, 0.0));

	// enable color material
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);

	// initialize depth test
	glEnable(GL_DEPTH_TEST);

	// enable lighting
	glEnable(GL_LIGHTING);

	// set ambient light
	GLfloat ambient[] = { 0.25f, 0.25f, 0.25f, 1.0f };
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient);

	// enable 2 lights
	glEnable(GL_LIGHT0);
	float fEye = (g_pCamera->GetLocation() - g_pCamera->GetTarget()).Length();
	float vUpLeft[4] = {-2.0f*fEye, fEye, fEye, 1.0f};
	glLightfv(GL_LIGHT0, GL_POSITION, vUpLeft);
	float fAmbient1[4] = {0,0,0,1};
	glLightfv(GL_LIGHT0, GL_AMBIENT, fAmbient1);
	float fDiffuse1[4] = {0.6f, 0.6f, 0.6f, 1.0f};
	glLightfv(GL_LIGHT0, GL_DIFFUSE, fDiffuse1);
	float fSpec1[4] = {0.25f, 0.25f, 0.25f,1.0f};
	glLightfv(GL_LIGHT0, GL_SPECULAR, fSpec1);

	glEnable(GL_LIGHT1);
	float vUpRight[4] = { 2.0f*fEye, fEye, fEye, 1.0f};
	glLightfv(GL_LIGHT1, GL_POSITION, vUpRight);
	float fAmbient2[4] = {0,0,0,1};
	glLightfv(GL_LIGHT1, GL_AMBIENT, fAmbient2);
	float fDiffuse2[4] = {0.5f, 0.5f, 0.5f, 1.0f};
	glLightfv(GL_LIGHT1, GL_DIFFUSE, fDiffuse2);
	float fSpec2[4] = {0.25f, 0.25f, 0.25f,1.0f};
	glLightfv(GL_LIGHT1, GL_SPECULAR, fSpec2);

	// set fixed specular material color
	float fSpecular[] = {1.0f, 1.0f, 1.0f, 1.0f};
	glMaterialfv( GL_FRONT_AND_BACK, GL_SPECULAR, fSpecular );
	glMaterialf( GL_FRONT_AND_BACK, GL_SHININESS, 40.0f );
}



void glut_main_display(void)
{
	static bool once = false;
	if (g_interactive == false)
	{
		// rui
		if (!once) {
			//g_mesh.generateASP(g_pdr, g_nthres, g_method, g_tid);
			g_mesh.SetDecalRadius(g_pdr*g_nthres);			
			g_mesh.outputPD(g_outFilename.c_str(), g_pdr, g_nthres);
			exit(0);	// rui
			once = true;
		}
	}

	// clear window
	g_mesh.ValidateExpMap();
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	// render the 3D view
	if ( g_displayMode == MESH || g_displayMode == MESH_AND_QUARTERUV ) {
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		g_pCamera->Update();

		g_mesh.Render(g_bRenderMeshAsWireframe);

		/*glPushAttrib(GL_ENABLE_BIT | GL_POINT_BIT);
		glDisable(GL_LIGHTING);
		glColor3f(0.0f,1.0f,0.0f);
		glPointSize(10.0f);
		glBegin(GL_POINTS);
		glVertex3fv( g_mesh.ExpMapFrame().Origin() );
		glEnd();
		glPopAttrib();*/
	}


	if ( g_displayMode == MESH_AND_QUARTERUV || g_displayMode == UVONLY ) {

		// render the 2D overlay
		const unsigned int * viewport = g_pCamera->GetViewport();
		int nDivider = (g_displayMode == MESH_AND_QUARTERUV) ? 2 : 1;
		int nMinDim = std::min(viewport[2], viewport[3]);
		glViewport(0, 0, nMinDim/nDivider, nMinDim/nDivider);
		
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluOrtho2D(-1, 1, -1, 1);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		g_mesh.RenderParamMesh();
	}
	glutSwapBuffers();

};




void glut_main_reshape (int cx, int cy)
{
	// set viewport and frustum, and update camera
	g_pCamera->SetViewPort(0, 0, cx, cy);
	g_pCamera->SetFrustum( 30.0f, float(cx)/float(cy), 0.1f, 100.0);
	g_pCamera->Update();
};



bool find_hit( float x, float y, rms::Frame3f & vHitFrame ) 
{
	// find hit point
	const unsigned int * pViewport = g_pCamera->GetViewport();
	Wml::Ray3f ray;
	g_pCamera->GetPickRay( x, y, 
		pViewport[2], pViewport[3], ray.Origin, ray.Direction );
	return g_mesh.FindHitFrame(ray, vHitFrame);
}

void glut_mouse(int button, int state, int x, int y)
{
	rms::Frame3f vHitFrame;
	bool bHit = find_hit(x, y, vHitFrame);

	g_bAltButtonDown = ( glutGetModifiers() == GLUT_ACTIVE_ALT );
	g_bCtrlButtonDown = ( glutGetModifiers() == GLUT_ACTIVE_CTRL );
	bool bShiftButtonDown = ( glutGetModifiers() == GLUT_ACTIVE_SHIFT );
	g_vLastMousePos = Wml::Vector2f(x,y);

	g_bRightMouseDown = g_bMiddleMouseDown = g_bLeftMouseDown = false;
	bool bLeftMouseUp = false, bRightMouseUp = false;
	
	if ( button == GLUT_RIGHT_BUTTON ) {
		g_bRightMouseDown = ( state == GLUT_DOWN ) ? true : false;
		bRightMouseUp = (state == GLUT_UP) ? true : false;
	} else if ( button == GLUT_LEFT_BUTTON ) {
		g_bLeftMouseDown = ( state == GLUT_DOWN ) ? true : false;
		bLeftMouseUp = ( state == GLUT_UP) ? true : false;
	} else if ( button == GLUT_MIDDLE_BUTTON ) {
		g_bMiddleMouseDown = ( state == GLUT_DOWN ) ? true : false;
	}
	if ( g_bRightMouseDown || g_bLeftMouseDown || g_bMiddleMouseDown )
		g_bGotMouseClick = true;


	INPUT_MODE lastMode = g_inputMode;
	g_inputMode = NONE;

	if ( g_bAltButtonDown && g_bRightMouseDown ) 
		g_inputMode = DOLLY;
	else if ( g_bAltButtonDown && g_bLeftMouseDown ) 
		g_inputMode = ORBIT;
	else if ( g_bAltButtonDown && g_bMiddleMouseDown ) 
		g_inputMode = PAN;
	else if ( g_bRightMouseDown ) {

	} else if ( g_bLeftMouseDown ) {

		if ( bShiftButtonDown ) {
			g_inputMode = ROTATE_EXPMAP;
		} else if ( g_bCtrlButtonDown ) {
			g_inputMode = SCALE_EXPMAP;
		} else
			g_inputMode = MOVE_EXPMAP_SEED;

	} else if ( bLeftMouseUp ) {
	}

}



void glut_mouse_motion(int x, int y)
{
	static const float fPanScale = 0.01f;
	static const float fZoomScale = 0.01f;
	static const float fOrbitScale = 0.01f;
	static const float fExpMapScale = 0.005f;

	rms::Frame3f vLastHitFrame;
	bool bLastHit = find_hit(g_vLastMousePos.X(), g_vLastMousePos.Y(), vLastHitFrame);

	Wml::Vector2f vCur(x,y);
	Wml::Vector2f vDelta(vCur - g_vLastMousePos);
	g_vLastMousePos = vCur;
	g_bGotMouseClick = false;		// got a drag, not a click

	rms::Frame3f vHitFrame;
	bool bHit = find_hit(x, y, vHitFrame);

	switch ( g_inputMode ) {
		case DOLLY:
			g_pCamera->DollyZoom((-vDelta.Y() + vDelta.X()) * fZoomScale);
			glutPostRedisplay();
			break;
		case PAN:
			g_pCamera->PanLateral(vDelta.X() * fPanScale);
			g_pCamera->PanVertical(vDelta.Y() * fPanScale);
			glutPostRedisplay();
			break;
		case ORBIT:
			g_pCamera->OrbitLateral(-vDelta.X() * fOrbitScale);
			g_pCamera->OrbitVertical(vDelta.Y() * fOrbitScale);
			glutPostRedisplay();
			break;

		case MOVE_EXPMAP_SEED:
			if ( bHit )
				g_mesh.MoveExpMap( vHitFrame );
			glutPostRedisplay();
			break;

		case SCALE_EXPMAP:
			g_mesh.ScaleExpMap( 1.0f + (vDelta.X() - vDelta.Y())*fExpMapScale );
			glutPostRedisplay();
			break;

		case ROTATE_EXPMAP:
			g_mesh.RotateExpMap( -(vDelta.X() + vDelta.Y())*fExpMapScale );
			glutPostRedisplay();
			break;
	}

}



// keyboard event handler
void glut_keyboard (unsigned char key, int x, int y)
{
	static int info_banner = 1;

	switch (key) {

	case 'd':  case 'D':
		g_displayMode = (DISPLAY_MODE)((g_displayMode + 1) % LAST_MODE);
		glutPostRedisplay();
		break;

	case 'e': case 'E':
		ExportMesh(NULL);
		break;

	case 'f':	case 'F':
		LoadNewMesh();
		glutPostRedisplay();
		break;

	case 'w': 
		g_bRenderMeshAsWireframe = ! g_bRenderMeshAsWireframe;
		glutPostRedisplay();
		break;


	case '+':
		g_mesh.ScaleExpMap( 1.1f );
		glutPostRedisplay();
		break;
	case '-':
		g_mesh.ScaleExpMap( 0.9f );
		glutPostRedisplay();
		break;

	case 'q':
	case 'Q':
		exit (0);
		break;

	// rui
	case 'c':
	case 'C':
		/* save camera parameters */
		{
			std::ofstream out(g_cparamFilename.c_str());
			Wm4::Vector3f v = g_pCamera->GetLocation();
			out<<v[0]<<" "<<v[1]<<" "<<v[2]<<endl;
			v = g_pCamera->GetLeft();
			out<<v[0]<<" "<<v[1]<<" "<<v[2]<<endl;
			v = g_pCamera->GetUp();
			out<<v[0]<<" "<<v[1]<<" "<<v[2]<<endl;
			v = g_pCamera->GetTarget();
			out<<v[0]<<" "<<v[1]<<" "<<v[2]<<endl;
			out.close();
			glutPostRedisplay();
		}
		break;

	case 'v':
	case 'V':
		{
			std::ifstream in(g_cparamFilename.c_str());
			Wm4::Vector3f location, left, up, target;
			in>>location[0]>>location[1]>>location[2];
			in>>left[0]>>left[1]>>left[2];
			in>>up[0]>>up[1]>>up[2];
			in>>target[0]>>target[1]>>target[2];
			g_pCamera->SetTargetFrame(location, left, up, target);
			in.close();
			glutPostRedisplay();
		}
		break;
	case '0':
		LoadNewMesh(g_objFilename.c_str(), "");
		glutPostRedisplay();
		break;
	case '1':
		LoadNewMesh(g_objFilename.c_str(), ".wn");
		glutPostRedisplay();
		break;
	case '2':
		LoadNewMesh(g_objFilename.c_str(), ".pd");
		glutPostRedisplay();
		break;
	case '3':
		LoadNewMesh(g_objFilename.c_str(), ".apd");
		glutPostRedisplay();
		break;
	};
};




void glut_idle (void)
{
};




CWinApp theApp;

int _tmain(int argc, _TCHAR* argv[])
{
	// init some MFC stuff so that CFileDialog won't throw any exceptions...
	InitCommonControls();
	AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0);

	// rui
	if (argc == 1) {
		g_interactive = true;
		g_objFilename = "eight.obj";
		g_cparamFilename = g_objFilename + ".camera.txt";
		LoadNewMesh(g_objFilename.c_str());

	} else if (argc == 2) {
		g_interactive = true;
		g_cparamFilename = argv[OBJ_NAME];
		g_cparamFilename += ".camera.txt";
		g_objFilename = argv[OBJ_NAME];
		LoadNewMesh(g_objFilename.c_str());

	} else {
		if (argc != 6) {
			printf("Usage: %s in.obj radius nthres method ite\n", argv[PROG_NAME]);
			exit(-1);
		}
		g_objFilename = argv[OBJ_NAME];
		string extname = "-t";
		extname += argv[PROG_ITE];
		LoadNewMesh(g_objFilename.c_str(), NULL);
		//LoadNewMesh(g_objFilename.c_str(), extname.c_str());
		g_outFilename = ".\\data\\robj-";
		g_outFilename = g_outFilename+argv[OBJ_NAME]+"-"+argv[PD_RADIUS]+"-"+argv[NR_THRES]+"-t"+argv[PROG_ITE]+".dat";
		g_pdr = atof(argv[PD_RADIUS]);
		g_nthres = atoi(argv[NR_THRES]);
		g_tid = atoi(argv[PROG_ITE]);
		g_mesh.generateASP(g_pdr, g_nthres, string(argv[SAMPLE_METHOD]), g_tid);
	}

	/* Glut initializations */
	glutInit (&argc, argv);
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowPosition(5, 5);
	glutInitWindowSize(512, 512);

	/* Main window creation and setup */
	glutCreateWindow("ExpMap Demo");
	glutDisplayFunc(glut_main_display);
	glutReshapeFunc(glut_main_reshape);
	glutKeyboardFunc(glut_keyboard);
	glutMouseFunc(glut_mouse);
	glutMotionFunc(glut_mouse_motion);
	//glutIdleFunc(glut_idle);

	glut_initgl();

	glutMainLoop();

	return 0;
}


// Author: Ryan Schmidt  (rms@unknownroad.com)  http://www.unknownroad.com
// Copyright (c) 2008. All Rights Reserved.
// The ExpMapDemo package is supplied "AS IS". The Author disclaims all warranties, expressed or implied, including, 
// without limitation, the warranties of merchantability and of fitness for any purpose. The Author assume no liability for 
// direct, indirect, incidental, special, exemplary, or consequential damages, which may result from the use of the 
// ExpMapDemo package, even if advised of the possibility of such damage. Permission is hereby granted to use, copy, 
// modify, and distribute this source code, or portions hereof, for any purpose, without fee, subject to the following restrictions:
// 1) The origin of this source code must not be misrepresented.
// 2) This Copyright notice may not be removed or altered from any source or altered source distribution.
// The Author specifically permits, without fee, the use of this source code as a component in commercial products.
#include "StdAfx.h"
#include ".\meshobject.h"

#include <gl/freeglut.h>
//#include <gl/GL.h>
//#include <gl/GLU.h>
#include <VFMeshRenderer.h>
#include <string>
#include <Wm4IntpThinPlateSpline2.h>
#include <MeshUtils.h>
#include <stdlib.h>
#include <time.h>
#include <algorithm>
#include <omp.h>
//#include <opencv2\opencv.hpp>
#include <hash_map>
#include "..\..\SSSLib\SSSSmallVec.h"
#include <boost/functional/hash.hpp>

MeshObject::MeshObject(void)
{
	m_bExpMapValid = true;
	m_bComputeExpMap = true;
	//m_fDecalRadius = 0.1f;
	m_fDecalRadius = 1.2f;

	// create checker texture...
	std::vector<unsigned char> vTexBuf;
	Texture::MakeCheckerImage(512, 64, vTexBuf, true);
	m_texture.InitializeBuffer(512, 512, vTexBuf, GL_RGBA);
	m_texture.SetTextureInfo( GL_TEXTURE_2D );
	m_texture.TextureEnvMode() = GL_DECAL;
	m_texture.SetEdgeAlpha( 0 );

	// rui
	aspID = 0;
}

MeshObject::~MeshObject(void)
{
}

void MeshObject::ReadMeshOBJ( const char * pFilename, Wml::Vector3f center, float scale)
{
	rms::VFTriangleMesh readMesh;
	std::string err;
	bool bOK = readMesh.ReadOBJ(pFilename,err);
	if ( ! bOK ) {
		char buf[1024];
		sprintf(buf,"Error opening file %s:\n%s\n", pFilename, err.c_str() );
		MessageBox(NULL, buf, "Error!", MB_OK);
	}
	for (int i=0; i<readMesh.GetVertexCount(); i++)
	{
		Wml::Vector3f vtx;
		readMesh.GetVertex(i, vtx);
		readMesh.SetVertex(i, (vtx-center)*scale);
	}

	// rui: potentially causing problem
	//readMesh.ClipEarTriangles();	

	SetMesh(readMesh);

	computeCumarea(readMesh);
}


// rui
void MeshObject::computeCumarea(rms::VFTriangleMesh & mesh) {
	double _area = 0.f;
	Wm4::Vector3f tri[3];
	cumarea.clear();
	for (int i=0; i<mesh.GetTriangleCount(); i++) {
		mesh.GetTriangle(i, tri);
		_area += 0.5*((tri[1]-tri[0]).Cross((tri[2]-tri[0])).Length());
		cumarea.push_back(_area);
	}
	printf("Total area: %g\n", _area);
}

void MeshObject::ReadASPoints( const char * pFilename)
{
	aspoints.clear();

	ifstream in(pFilename);
	if (!in) {
		char buf[1024];
		sprintf(buf, "Error opening file %s:\n", pFilename);
		MessageBox(NULL, buf, "Error!", MB_OK);
	}
	char line[256];
	while(in.getline(line, 255)) {
		unsigned int tid;
		double a, b, r;
		sscanf(line, "%d%lf%lf%lf", &tid, &a, &b, &r);
		aspoints.push_back(ASPoint(this->m_mesh, tid, a, b, r));
	}
	in.close();
}

void MeshObject::SetMesh( rms::VFTriangleMesh & mesh )
{
	m_mesh.Clear(false);
	m_mesh.Copy(mesh);

	m_bvTree.SetMesh(&m_mesh);
	m_expmapgen.SetSurface(&m_mesh, &m_bvTree);
	m_bExpMapValid = false;

	if ( ! m_mesh.HasUVSet(0) )
		m_mesh.AppendUVSet();
	m_mesh.InitializeUVSet(0);

	float fMin, fMax, fAvg;
	m_mesh.GetEdgeLengthStats(fMin, fMax, fAvg);
	m_fBoundaryWidth =  fMax * 1.0f;

	NotifyMeshModified();
}

void MeshObject::NotifyMeshModified()
{
	m_bvTree.SetMesh(&m_mesh);
	m_expmapgen.SetSurface(&m_mesh, &m_bvTree);
	m_bExpMapValid = false;

	// find new seed point
	Wml::Vector3f vHit;
	rms::IMesh::TriangleID tID;
	if (! m_bvTree.FindNearest( m_vSeedFrame.Origin(), vHit, tID ) )
		return;
	Wml::Vector3f vVerts[3], vNorms[3];
	m_mesh.GetTriangle(tID, vVerts, vNorms);

	float fBary[3];
	rms::BarycentricCoords( vVerts[0], vVerts[1], vVerts[2], vHit, fBary[0], fBary[1], fBary[2] );
	Wml::Vector3f vHitNormal = fBary[0]*vNorms[0] + fBary[1]*vNorms[1] + fBary[2]*vNorms[2];
	vHitNormal.Normalize();

	m_vSeedFrame.Origin() = vHit;
	m_vSeedFrame.AlignZAxis(vHitNormal);	
}


bool MeshObject::FindIntersection( Wml::Ray3f & vRay, Wml::Vector3f & vHit, Wml::Vector3f & vHitNormal )
{
	rms::IMesh::TriangleID tID;
	if ( ! m_bvTree.FindRayIntersection( vRay.Origin, vRay.Direction, vHit, tID ) )
		return false;
	Wml::Vector3f vVerts[3], vNorms[3];
	m_mesh.GetTriangle(tID, vVerts, vNorms);

	float fBary[3];
	rms::BarycentricCoords( vVerts[0], vVerts[1], vVerts[2], vHit, fBary[0], fBary[1], fBary[2] );
	vHitNormal = 
		fBary[0]*vNorms[0] + fBary[1]*vNorms[1] + fBary[2]*vNorms[2];
	vHitNormal.Normalize();

	return true;
}

bool MeshObject::FindHitFrame( Wml::Ray3f & vRay, rms::Frame3f & vFrame )
{
	Wml::Vector3f vHit, vHitNormal;
	if ( ! FindIntersection(vRay, vHit, vHitNormal ) ) 
		return false;
	vFrame.Origin() = vHit;
	vFrame.AlignZAxis(vHitNormal);	
	return true;
}


void MeshObject::MoveExpMap( rms::Frame3f & vFrame )
{
	m_vSeedFrame.Origin() = vFrame.Origin();
	m_vSeedFrame.AlignZAxis( vFrame.Z() );
	m_bExpMapValid = false;
}

void MeshObject::ScaleExpMap( float fScale )
{
	if ( fScale <= 0 )
		return;
	m_fDecalRadius *= fScale;
	if ( m_fDecalRadius < 0.01f )
		m_fDecalRadius = 0.01f;
	m_bExpMapValid = false;
}

void MeshObject::SetDecalRadius( float fRadius )
{
	m_fDecalRadius = fRadius;
	m_bExpMapValid = false;
}


void MeshObject::RotateExpMap( float fRotate )
{
	Wml::Matrix3f matRotate;
	matRotate.FromAxisAngle(m_vSeedFrame.Z(), fRotate);
	m_vSeedFrame.Rotate(matRotate);
	m_bExpMapValid = false;
}


void MeshObject::ValidateExpMap()
{
	if ( ! m_bComputeExpMap )
		return;
	if ( m_bExpMapValid )
		return;

	float fParamRadius = m_fDecalRadius + m_fBoundaryWidth;
	m_expmapgen.SetSurfaceDistances(m_vSeedFrame.Origin(), 0.0f, 
		fParamRadius, &m_vSeedFrame);
	m_expmapgen.CopyVertexUVs(&m_mesh, 0);

	m_bExpMapValid = true;
}










void MeshObject::Render(bool bWireframe)
{
	glPushAttrib(GL_ENABLE_BIT | GL_POLYGON_BIT | GL_LINE_BIT | GL_POINT_BIT | GL_DEPTH_BUFFER_BIT );

	// render base mesh
	glColor3f(0.9f, 1.0f, 0.9f);
	rms::VFMeshRenderer renderer(&m_mesh);
	renderer.SetNormalMode( rms::VFMeshRenderer::VertexNormals );
	renderer.SetDrawNormals(false);

	if ( bWireframe ) {
		glColor3f(0.3f, 0.8f, 0.3f);
		glPushAttrib(GL_ENABLE_BIT | GL_POLYGON_BIT | GL_LINE_BIT);
		glDisable(GL_LIGHTING);

		// render mesh as z-fill
		glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
		renderer.Render();
		glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);

		glLineWidth(3.0f);
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	}

	renderer.Render();

	if ( bWireframe )
		glPopAttrib();

	// rui
	glDisable(GL_LIGHTING);
	Wml::Vector2f vTriUV[3];
	glPointSize(3.0f);
	glColor3f(0.0f, 0.0, 0.0f);
	glBegin(GL_POINTS);
	for (int j=0; j<aspoints.size(); j++) {
		Wm4::Vector3f dp = aspoints[j].point;
		/*if (m_mesh.GetTriangleUV( dp.triID, 0, vTriUV) == true) {
			glColor3f(1, 0, 0);
		} else {
			glColor3f(0.2f, 0.2, 0.2f);
		}*/
		dp += Wm4::Vector3f(aspoints[j].normal[0],
						    aspoints[j].normal[1],
							aspoints[j].normal[2]) * 0.001;
		glVertex3f(dp[0], dp[1], dp[2]);
	}
	glEnd();
	glEnable(GL_LIGHTING);

	// render support region of decal parameterization
	glDepthFunc(GL_LEQUAL);
	renderer.SetTexture2DMode( rms::VFMeshRenderer::VertexTexture2D_Required );
	glColor4f(0.5f, 0.5f, 1.0f, 1.0f);
	// rui renderer.Render();

	// do texture rendering

	// enable transparency and alpha test
	glDepthFunc(GL_LEQUAL);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
	glAlphaFunc( GL_NOTEQUAL, 0.0f );
	glEnable( GL_ALPHA_TEST );

	// enable texture
	m_texture.Enable();
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	// set texture matrix transformation so that decal is in the right spot
	glMatrixMode(GL_TEXTURE);
	glPushMatrix();
	glTranslatef( 0.5f, 0.5f, 0.0f );	
	float fScale = 1.0f / (m_fDecalRadius * (float)sqrt(2.0f));
	glScalef( fScale, fScale, 1.0f );
	glMatrixMode(GL_MODELVIEW);

	renderer.SetTexture2DMode( rms::VFMeshRenderer::VertexTexture2D_Required );
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	// rui renderer.Render();

	glMatrixMode(GL_TEXTURE);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);

	m_texture.Disable();



	// draw seed point frame
	glDisable(GL_LIGHTING);

	// rui
	//glLineWidth(5.0f);
	//glBegin(GL_LINES);
	//glColor3f(1.0f,0.0f,0.0f);
	//glVertex3fv(m_vSeedFrame.Origin());
	//glVertex3fv(m_vSeedFrame.Origin() + 0.25f * m_vSeedFrame.X());
	//glColor3f(0.0f,1.0f,0.0f);
	//glVertex3fv(m_vSeedFrame.Origin());
	//glVertex3fv(m_vSeedFrame.Origin() + 0.25f * m_vSeedFrame.Y());
	//glColor3f(0.0f,0.0f,1.0f);
	//glVertex3fv(m_vSeedFrame.Origin());
	//glVertex3fv(m_vSeedFrame.Origin() + 0.25f * m_vSeedFrame.Z());
	//glEnd();

	glPopAttrib();
}



void MeshObject::RenderParamMesh()
{
	glPushAttrib(GL_ENABLE_BIT | GL_POLYGON_BIT | GL_LINE_BIT);
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glLineWidth(2.0f);
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glColor3f(0.0f, 0.0f, 0.0f);

	// set transformation so that decal is in the right spot
	glPushMatrix();
	glLoadIdentity();
	//glTranslatef( 0.5f, 0.5f, 0.0f );	
	//float fScale = 1.0f / (m_fDecalRadius * (float)sqrt(2.0f));
	float fParamRadius = m_fDecalRadius + m_fBoundaryWidth;
	float fScale = 1.5f / (fParamRadius * (float)sqrt(2.0f));
	glScalef( fScale, fScale, 1.0f );

	rms::VFMeshRenderer renderer(&m_mesh);
	renderer.Render_UV(false);	

	glColor3f(1.0f, 0.0f, 0.0f);
	glLineWidth(3.0f);
	glBegin(GL_LINE_LOOP);
	float fSize = m_fDecalRadius / (float)sqrt(2.0f);
	glVertex2f(-fSize, -fSize);
	glVertex2f(fSize, -fSize);
	glVertex2f(fSize, fSize);
	glVertex2f(-fSize, fSize);
	glEnd();

	glPopMatrix();

	glPopAttrib();
}

#if 1
//#if 0
//int binarySearch(double sorted[], int first, int last, float key) {
//	while (first <= last) {
//		int mid = (first + last) / 2;
//		if (key > sorted[mid])
//			first = mid + 1;
//		else if (key < sorted[mid])
//			last = mid - 1;
//		else
//			return max(min(mid, last), 0);
//	}
//	return max(min(first, last), 0);
//	/*
//	int ret = 0;
//	while(sorted[ret] < key) {ret++;}
//	return ret;*/
//}

// rui

void MeshObject::loadCurvature() {
	static bool once = false;
	if (once)
		return;

	// assume that curvature is already computed and stored in a disk file
	ifstream in("curvature.txt");

	if (!in) {
		printf("curvature.txt does not exist");
	} else {
		// insert scalar set
		int nsetID = m_mesh.AppendScalarSet();
		assert(nsetID == 0);
		m_mesh.InitializeScalarSet(nsetID);

		for (int i=0; i<m_mesh.GetVertexCount(); i++) {
			float value;
			in >> value;
			value = exp(-fabsf(value)) + 0.2f;		// rfunc
			m_mesh.SetScalar(i, nsetID, value);
		}
	}

	in.close();
	once = true;

}

#define rand_real() (((rand()<<15)+rand())/(float)((RAND_MAX<<15)+RAND_MAX+1))

namespace
{
	typedef SSSLib::SmallVec<float, 6> TFeature;
	typedef SSSLib::SmallVec<int, 6> TIdx;
	inline size_t hash_value(const TIdx& iKey)
	{
		size_t retVal = 0;
		for (int i=0; i<6; i++)
			boost::hash_combine(retVal, iKey[i]);
		return retVal;
	}

}

ASPoint MeshObject::generateRandomPoint(float totalarea) { // rui
	static bool initialized = false;
	if (!initialized) {
		//srand(GetTickCount());
		//srand(0);
		initialized = true;
	}
	float f = std::min(rand_real()*totalarea, totalarea);
	int idx = //binarySearch((double*)&cumarea[0], 0, cumarea.size()-1, f);
		lower_bound(cumarea.begin(), cumarea.end(), f)-cumarea.begin();
	idx = min(idx, (int)cumarea.size()-1);
	float u = sqrtf(rand_real());
	float l1 = 1.f-u;
	float l2 = rand_real()*u;
	return ASPoint(GetMesh(), idx, l1, l2, 1);
}

void MeshObject::generateASP(float pdr, int nthres, std::string& method, int tid) { // rui
#define _EUCLIDEAN_ONLY
#define _USE_HASH
	float normalWeight = 2.0f;

	if (cumarea.size()==0)
		return;
	float totalarea = cumarea[cumarea.size()-1];
	aspoints.clear();
	if (method == "wn") {
		int targetn = (int)(totalarea*2.f*0.75f*0.75f/(sqrtf(3.f)*pdr*pdr));
		printf("TargetN = %d\n", targetn);
		for (int i=0; i<targetn; i++) {
			aspoints.push_back(generateRandomPoint(totalarea));
		}

	} else if (method == "pd" || method == "apd") {

#ifdef _USE_HASH

		hash_map<size_t, vector<TFeature> > pointHash;

		float gridSize = pdr*2;
#endif

		rms::IMesh::VertexID vTri[3];
		bool foundPoint = true;

		//while (aspoints.size()<5000){
		while (foundPoint) {
			if (aspoints.size()%100==0)
				cout<<"Sampling "<<aspoints.size()<<endl;
			foundPoint = false;
			int ntry = std::max(1000, (int)aspoints.size() * 15);	// rui: set number of tries

			for (int i=0; i<ntry; i++) {
				ASPoint candidate = generateRandomPoint(totalarea);
				m_mesh.GetTriangle(candidate.triID, vTri);

				bool reject = false;
				// omp version
//				int numThread = omp_get_num_threads();
//				int pointPerThread = (aspoints.size()+numThread-1)/numThread;
//#pragma omp parallel for
//				for (int threads = 0; threads<numThread; threads++)
//				for (int jj=0; jj<pointPerThread; jj++) {
//					if (reject)
//						break;
//					int j = jj+threads*(pointPerThread);
//					if (j>=aspoints.size())
//						break;

#ifdef _USE_HASH
				TFeature newFeature;
				newFeature[0] = candidate.point[0];
				newFeature[1] = candidate.point[1];
				newFeature[2] = candidate.point[2];

				newFeature[3] = candidate.normal[0]*normalWeight;
				newFeature[4] = candidate.normal[1]*normalWeight;
				newFeature[5] = candidate.normal[2]*normalWeight;

				TIdx newIdx;
				TIdx downIdx;
				TIdx upIdx;
				for (int j=0; j<6; j++)
				{
					newIdx[j] = (int)floor(newFeature[j]/gridSize);
					downIdx[j] = (int)floor(newFeature[j]/gridSize-0.5f);
					upIdx[j] = (int)floor(newFeature[j]/gridSize+0.5f);
				}

				TIdx g;
				for (g[0]=downIdx[0]; g[0]<=upIdx[0] && !reject; g[0]++)
				for (g[1]=downIdx[1]; g[1]<=upIdx[1] && !reject; g[1]++)
				for (g[2]=downIdx[2]; g[2]<=upIdx[2] && !reject; g[2]++)
				for (g[3]=downIdx[3]; g[3]<=upIdx[3] && !reject; g[3]++)
				for (g[4]=downIdx[4]; g[4]<=upIdx[4] && !reject; g[4]++)
				for (g[5]=downIdx[5]; g[5]<=upIdx[5] && !reject; g[5]++)
				if (pointHash.count(hash_value(g)))
				{
					const vector<TFeature>& neighbourGrid = pointHash[hash_value(g)];
					for (int j=0; j<(int)neighbourGrid.size(); j++)
					{
						TFeature sfea = neighbourGrid[j];
						float dis = (sfea-newFeature).SqrLength();
						if (dis<pdr*pdr)
						{
							reject = true;
							break;
						}
					}
				}
				if (!reject)
					pointHash[hash_value(newIdx)].push_back(newFeature);
#else // _USE_HASH
				for (int j=0; j<aspoints.size(); j++) {
					const ASPoint & sp = aspoints[j];
					// skip if Euclidean distance is already very large
					
					// MODIFIED: use Euclidean only
						
#	ifdef _EUCLIDEAN_ONLY
					// use biliteral filtering
					float dis = (sp.point-candidate.point).SquaredLength();
					// according to Li-Yi's paper, the weight should be in 15~25
					//dis += (1.0f/20.0f*(sp.normal-candidate.normal)).SquaredLength();
					dis += (1.0f*(sp.normal-candidate.normal)).SquaredLength();
					

					if (dis < pdr*pdr)
					{
						reject = true;
						break;
					}
#	else
					float fdist2 = std::max(sp.r*pdr, candidate.r*pdr);
					fdist2 *= fdist2;
					if ((sp.point - candidate.point).SquaredLength() >= fdist2)
						continue;
					Wml::Vector2f* map = uvmap[j];
					if (map[vTri[0]].X() == FLT_MAX ||
						map[vTri[1]].X() == FLT_MAX ||
						map[vTri[2]].X() == FLT_MAX)
						continue;

					Wml::Vector2f uv = map[vTri[0]]*candidate.a + 
									   map[vTri[1]]*candidate.b +
									   map[vTri[2]]*(1.f-candidate.a-candidate.b);
					if (uv.SquaredLength() < fdist2)
					{
						reject = true;
						break;
					}
				}
#	endif
#endif // _USE_HASH
				if (!reject) {
					aspoints.push_back(candidate);
					// generate exponential map for the new point
#ifndef _EUCLIDEAN_ONLY
					this->SetDecalRadius(candidate.r*pdr);
					rms::Frame3f vHitFrame;
					Wml::Vector3f vHit, vHitNormal;
					vHitFrame.Origin() = candidate.point;
					vHitFrame.AlignZAxis(candidate.normal);
					MoveExpMap( vHitFrame );
					ValidateExpMap();
					Wml::Vector2f* newmap = new Wml::Vector2f[m_mesh.GetVertexCount()];

					int ptCount = 0;

					for (int t=0; t<m_mesh.GetVertexCount(); t++) {
						newmap[t] = Wml::Vector2f(FLT_MAX, FLT_MAX);
						m_mesh.GetUV(t, 0, newmap[t]);
						
						if (newmap[t].X()!=FLT_MAX)
							ptCount++;
					}

					//cout<<"ASP ID "<<aspoints.size()<<" Visible Vtx "<<ptCount<<endl;

					uvmap.push_back(newmap);
#endif
					foundPoint = true;
					break;
				}
			}
		}
		printf("%d points generated.\n", aspoints.size());

	} else {
		printf("Unsupported sampling method.\n");
		exit(-1);
	}
}
#endif


void MeshObject::outputPD( const char* pFilename, double pdr, int nthres) {	// rui

	std::vector<double> datax;
	std::vector<double> datay;
	rms::Frame3f vHitFrame;
	Wml::Vector3f vHit, vHitNormal;
	Wml::Vector2f vTriUV[3];
	rms::IMesh::VertexID vid[3];
	double rthres = pdr * nthres;
	double min_euc_dist = DBL_MAX;
	double min_geo_dist = DBL_MAX;
	double cor_geo_dist = DBL_MAX;
	for (int i=0; i<aspoints.size(); i+=4) {
		
		const ASPoint & sp = aspoints[i];
		vHitFrame.Origin() = Wml::Vector3f(sp.point[0], sp.point[1], sp.point[2]);
		vHitFrame.AlignZAxis(sp.normal);	
		MoveExpMap( vHitFrame );
		ValidateExpMap();

		for (int j=0; j<aspoints.size(); j++) {
			if (j==i) continue;
			const ASPoint & dp = aspoints[j];
			m_mesh.GetTriangle(dp.triID, vid);
			if (m_mesh.GetTriangleUV( dp.triID, 0, vTriUV) == true)
			{
				//if (fabsf((dp.point - sp.point).X()) > rthres || fabsf((dp.point - sp.point).Y()) > rthres)
				//	continue;
				if (vTriUV[0].SquaredLength() == 0 ||
					vTriUV[1].SquaredLength() == 0 ||
					vTriUV[2].SquaredLength() == 0)
					continue;
				Wml::Vector2d uv = Wml::Vector2d(vTriUV[0][0],vTriUV[0][1])*dp.a+
								   Wml::Vector2d(vTriUV[1][0],vTriUV[1][1])*dp.b+
								   Wml::Vector2d(vTriUV[2][0],vTriUV[2][1])*(1.0-dp.a-dp.b);

				double euc_dist = (dp.point - sp.point).Length();
				double geo_dist = uv.Length();

				uv = uv*pdr*2.0/(sp.r+dp.r);
				
				double cor_dist = uv.Length();

				if (fabs(uv[0]) <= rthres &&
					fabs(uv[1]) <= rthres)
				{
					//if (uv.SquaredLength() > pdr*pdr)
					{
						datax.push_back(uv[0]);	
						datay.push_back(uv[1]);
						min_euc_dist = std::min(euc_dist, min_euc_dist);
						min_geo_dist = std::min(geo_dist, min_geo_dist);
						cor_geo_dist = std::min(cor_dist, cor_geo_dist);
					}
				}
			}
		}
	}
	printf("min euc dist: %lf\n", min_euc_dist);
	printf("min geo dist: %lf\n", min_geo_dist);
	printf("cor geo dist: %lf\n", cor_geo_dist);

	std::ofstream fout;
	cout << "Writing to file " << pFilename << endl;
	fout.open(pFilename, ios_base::out | ios_base::binary);

	int size = aspoints.size();
	fout.write((char*)&size, sizeof(int));	// number of samples
	size = datax.size();
	fout.write((char*)&size, sizeof(int));	// number of $\diff$ pairs
	fout.write((char*)&datax[0], sizeof(double)*size);
	fout.write((char*)&datay[0], sizeof(double)*size);
	
	fout.close();	
}
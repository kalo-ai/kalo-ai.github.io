// Author: Ryan Schmidt  (rms@unknownroad.com)  http://www.unknownroad.com
// Copyright (c) 2008. All Rights Reserved.
// The ExpMapDemo package is supplied "AS IS". The Author disclaims all warranties, expressed or implied, including, 
// without limitation, the warranties of merchantability and of fitness for any purpose. The Author assume no liability for 
// direct, indirect, incidental, special, exemplary, or consequential damages, which may result from the use of the 
// ExpMapDemo package, even if advised of the possibility of such damage. Permission is hereby granted to use, copy, 
// modify, and distribute this source code, or portions hereof, for any purpose, without fee, subject to the following restrictions:
// 1) The origin of this source code must not be misrepresented.
// 2) This Copyright notice may not be removed or altered from any source or altered source distribution.
// The Author specifically permits, without fee, the use of this source code as a component in commercial products.
#pragma once

#include "expmap\VFTriangleMesh.h"
#include "expmap\ExpMapGenerator.h"
#include "expmap\IMeshBVTree.h"
#include "Texture.h"


// rui
class ASPoint {
public:
	Wm4::Vector3f point;
	Wm4::Vector3f normal;			//
	rms::IMesh::VertexID v[3];		//
	rms::IMesh::TriangleID triID;	//
	double a, b, r;
	ASPoint(rms::VFTriangleMesh& mesh, rms::IMesh::TriangleID tid, double aa, double bb, double rr) {
		Wm4::Vector3f verts[3];
		Wm4::Vector3f norms[3];
		triID = tid;	
		mesh.GetTriangleNormal(triID, normal);

		mesh.GetTriangle(triID, v);
		mesh.GetTriangle(triID, verts, norms);
		a = aa;
		b = bb;
		r = rr;	// real r
		double c = 1.0-a-b;
		point = Wm4::Vector3f(verts[0][0]*a + verts[1][0]*b + verts[2][0]*c,
							  verts[0][1]*a + verts[1][1]*b + verts[2][1]*c,
							  verts[0][2]*a + verts[1][2]*b + verts[2][2]*c);		
		// compute interpolated normal
		//if (norms[0].Length()!=0 || norms[1].Length()!=0 || norms[2].Length()!=0)
		//{
		//	normal = Wm4::Vector3f(norms[0][0]*a + norms[1][0]*b + norms[2][0]*c,
		//						  norms[0][1]*a + norms[1][1]*b + norms[2][1]*c,
		//						  norms[0][2]*a + norms[1][2]*b + norms[2][2]*c);		
		//	normal.Normalize();
		//}
	}
};

class MeshObject
{
public:
	MeshObject(void);
	~MeshObject(void);

	void ReadMeshOBJ( const char * pFilename, Wml::Vector3f center = Wml::Vector3f(0, 0, 0), float scale = 1.0f );
	void ReadASPoints( const char* pFilename );						// rui
	void generateASP(float pdr, int nthres, std::string & method, int tid=0);	// rui
	void outputPD( const char* pFilename, double pdr, int nthres);			// rui
	void computeCumarea(rms::VFTriangleMesh & mesh);				// rui
	ASPoint generateRandomPoint(float totalarea);			// rui
	void MeshObject::loadCurvature();

	void SetMesh( rms::VFTriangleMesh & mesh );
	void NotifyMeshModified();

	void Render(bool bWireframe = false);
	void RenderParamMesh();

	rms::VFTriangleMesh & GetMesh() { return m_mesh; }
	rms::IMeshBVTree & GetBVTree() { return m_bvTree; }

	bool FindIntersection( Wml::Ray3f & vRay, Wml::Vector3f & vHit, Wml::Vector3f & vHitNormal );

	bool FindHitFrame( Wml::Ray3f & vRay, rms::Frame3f & vFrame );

	rms::Frame3f & ExpMapFrame() { return m_vSeedFrame; }
	void MoveExpMap( rms::Frame3f & vFrame );
	void ScaleExpMap( float fScale );
	void RotateExpMap( float fRotate );
	void ValidateExpMap();
	void SetDecalRadius( float fRadius );

	rms::ExpMapGenerator * GetExpMapGen() { return & m_expmapgen; }

//protected:
	rms::VFTriangleMesh m_mesh;
	rms::IMeshBVTree m_bvTree;

	rms::Frame3f m_vSeedFrame;
	float m_fDecalRadius;
	float m_fBoundaryWidth;

	rms::ExpMapGenerator m_expmapgen;
	bool m_bExpMapValid;
	bool m_bComputeExpMap;

	Texture m_texture;
	
	// rui
	std::vector<ASPoint>		aspoints;
	std::vector<double>			cumarea;
	std::vector<Wml::Vector2f*> uvmap;
	int aspID;
};


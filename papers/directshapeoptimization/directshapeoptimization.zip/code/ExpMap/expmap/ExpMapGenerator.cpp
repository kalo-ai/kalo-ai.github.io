// Author: Ryan Schmidt  (rms@unknownroad.com)  http://www.unknownroad.com
// Copyright (c) 2008. All Rights Reserved.
// The ExpMapDemo package is supplied "AS IS". The Author disclaims all warranties, expressed or implied, including, 
// without limitation, the warranties of merchantability and of fitness for any purpose. The Author assume no liability for 
// direct, indirect, incidental, special, exemplary, or consequential damages, which may result from the use of the 
// ExpMapDemo package, even if advised of the possibility of such damage. Permission is hereby granted to use, copy, 
// modify, and distribute this source code, or portions hereof, for any purpose, without fee, subject to the following restrictions:
// 1) The origin of this source code must not be misrepresented.
// 2) This Copyright notice may not be removed or altered from any source or altered source distribution.
// The Author specifically permits, without fee, the use of this source code as a component in commercial products.
#include <stdafx.h>
#include "ExpMapGenerator.h"
#include "rmsprofile.h"

#include <limits>
#include <list>
#include <set>
#include <hash_set>
#include <algorithm>

#include "VectorUtil.h"
#include "MeshUtils.h"

using namespace rms;


Wml::Vector2f ExpMapParticle::INVALID_PARAM = Wml::Vector2f( std::numeric_limits<float>::max(), std::numeric_limits<float>::max() );

ExpMapParticle::ExpMapParticle(const Wml::Vector3f & vPosition,
							   const Wml::Vector3f & vNormal)
							   : m_vPosition(vPosition), m_vNormal(vNormal)
{
	m_fSurfaceDistance = 0.0f;
	m_vSurfaceVector = Wml::Vector2f::ZERO;
	ClearNeighbourList();
	m_nVertexID = std::numeric_limits<unsigned int>::max();

	m_eState = ExpMapParticle::Inactive;
	m_pNearest = NULL;
	m_bNbrFlag = false;
}

ExpMapParticle::~ExpMapParticle()
{
	ClearNeighbourList();
}

void ExpMapParticle::AddNeighbour( ListEntry * pNeighbour )
{
	if ( m_pNeighbourList == NULL ) {
		m_pNeighbourList = pNeighbour;
		pNeighbour->pNext = NULL;
	} else {
		pNeighbour->pNext = m_pNeighbourList;
		m_pNeighbourList = pNeighbour;
	}
}

void ExpMapParticle::ClearNeighbourList()
{
	// cleared using memory pool in particle system!
	m_pNeighbourList = NULL;
}




/*
 * ExpMapGenerator
 */


ExpMapGenerator::ExpMapGenerator()
{
	m_bNeighbourListsValid = false;
	m_bParticleGridValid = false;
	m_fMaxNbrDist = 0.0f;
	m_pSeedParticle = NULL;

	m_pMesh = NULL;
	m_pMeshBVTree = NULL;

	m_bPrecomputeNeighbours = true;
	m_bUseMeshNeighbours = false;

	m_bEnableSquareCulling = false;
	m_fLastMaxRadius = 0.0f;
}

ExpMapGenerator::~ExpMapGenerator()
{
}






void ExpMapGenerator::SetSurface( VFTriangleMesh * pMesh, IMeshBVTree * pMeshBVTree )
{
	m_pMesh = pMesh;
	m_pMeshBVTree = pMeshBVTree;

	float fMin = 0, fAverage = 0;
	m_pMesh->GetEdgeLengthStats(fMin, m_fMaxMeshEdgeLength, fAverage);

	Reset();

	unsigned int nMaxVert = pMesh->GetMaxVertexID();
	m_vVtxToParticleMap.resize(0);
	m_vVtxToParticleMap.resize( nMaxVert, IMesh::InvalidID );

	IMesh::IVtxIterator curv(pMesh->BeginIVertices()), endv(pMesh->EndIVertices());
	while ( curv != endv ) {
		IMesh::VertexID nID = *curv;	curv++;

		// create particle
		ExpMapParticle * p = AllocateParticle();
		pMesh->GetVertex( nID, p->Position(), & p->Normal() );

		// associate w/ vertex
		p->VertexID() = nID;
		m_vVtxToParticleMap[nID] = AddParticle(p);

		// set arbitrary surface frame
		p->WorldFrame() = Frame3f( p->Position(), p->Normal() );
	}
}


void ExpMapGenerator::Reset()
{
	m_bParticleGridValid = false;
	ClearNeighbourLists();
	ClearParticles();
	m_vLastParticles.resize(0);
}



void ExpMapGenerator::CopyVertexUVs( IMesh * pMesh, IMesh::UVSetID nSetID )
{
	pMesh->ClearUVSet( nSetID );

	Wml::Vector2f vTexCoord;
	size_t nLastCount = m_vLastParticles.size();
	for ( unsigned int i = 0; i < nLastCount; ++i ) {
		ExpMapParticle * pParticle = m_vLastParticles[i];
		if ( pParticle->VertexID() != IMesh::InvalidID &&
			pParticle->SurfaceDistance() != std::numeric_limits<float>::max() )
			//rui
			pMesh->SetUV( pParticle->VertexID(), nSetID, pParticle->SurfaceVector() );
	}

}





// neighbour list setup code


ExpMapParticle::ListEntry * ExpMapGenerator::GetNeighbourList( ExpMapParticle * pParticle )
{
	if ( pParticle->GetNeighbourList() == NULL ) {
		m_vNeighbourBuf.resize(0);
		if ( m_bUseMeshNeighbours ) 
			FindNeighbours(pParticle, m_vNeighbourBuf);
		else
			FindNeighbours( pParticle->Position(), pParticle->Normal(), m_vNeighbourBuf, m_fMaxNbrDist, pParticle );	

		size_t nCount = m_vNeighbourBuf.size();
		for ( unsigned int i = 0; i < nCount; ++i ) {
			ExpMapParticle::ListEntry * pEntry = m_NeighbourMemoryPool.Allocate();
			pEntry->pParticle = m_vNeighbourBuf[i];
			pParticle->AddNeighbour(pEntry);
		}
	}
	
	return pParticle->GetNeighbourList();
}


class  NeighborTriBuffer : public IMesh::NeighborTriCallback
{
public:
	NeighborTriBuffer() {}

	const std::vector<IMesh::TriangleID> & Triangles() { return m_vTriangles; }

	virtual void BeginTriangles() 
		{ m_vTriangles.resize(0); }
	virtual void NextTriangle( IMesh::TriangleID tID )
		{ m_vTriangles.push_back(tID); }

protected:
	std::vector<IMesh::TriangleID> m_vTriangles;
};


void ExpMapGenerator::FindNeighbours( ExpMapParticle * pParticle,
									  std::vector<ExpMapParticle *> & vParticles)
{
	vParticles.resize(0);

	IMesh::VertexID vID = pParticle->VertexID();

	NeighborTriBuffer vBuffer;
	m_pMesh->NeighbourIteration(vID, &vBuffer);
	const std::vector<IMesh::TriangleID> & vTris = vBuffer.Triangles();
	size_t nCount = vTris.size();
	for ( unsigned int i = 0; i < nCount; ++i ) {
		IMesh::VertexID nTri[3];
		m_pMesh->GetTriangle( vTris[i], nTri);

		// check each vertex
		for ( int j = 0; j < 3; ++j ) {
			if ( nTri[j] == vID )
				continue;
			ExpMapParticle * pParticle = m_vParticles[ m_vVtxToParticleMap[nTri[j]] ];
			bool bFound = false;
			for ( unsigned int k = 0; k < vParticles.size() && ! bFound; ++k ) {
				if ( vParticles[k] == pParticle )
					bFound = true;
			}
			if ( ! bFound )
				vParticles.push_back( pParticle );
		}
	}
}




#define USE_KNN

bool ParticleDistanceSort( ExpMapParticle * p1, ExpMapParticle * p2 )
{
	return p1->SurfaceDistance() < p2->SurfaceDistance();
}


void ExpMapGenerator::FindNeighbours( const Wml::Vector3f & vPoint, const Wml::Vector3f & vNormal,
									  std::vector<ExpMapParticle *> & vParticles, float fRadiusThreshold,
									  ExpMapParticle * pSkip )
{
	float fDistSqrThreshold = fRadiusThreshold*fRadiusThreshold;

	std::vector<ExpMapParticle *> vNeighbours;
	const unsigned int sMaxNbrs = 15;
//	const unsigned int sMaxNbrs = 8;

	ParticleGrid<ExpMapParticle *>::BoxIterator itr( &m_particleGrid, vPoint, fRadiusThreshold );
	if ( itr.Done() )
		DebugBreak();
	while ( ! itr.Done() ) {
		ExpMapParticle * pTmp = *itr;
		++itr;

		if ( pTmp == pSkip )
			continue;

		float fDistSqr = ( pTmp->Position() - vPoint ).SquaredLength();
		float fNormalDir = pTmp->Normal().Dot( vNormal );
		//if ( fDistSqr < fDistSqrThreshold && fNormalDir > -0.1f) {
		if ( fDistSqr < fDistSqrThreshold ) {
			pTmp->SurfaceDistance() = fDistSqr;
			vNeighbours.push_back( pTmp );
		} 
	}	

#ifdef USE_KNN
	std::sort( vNeighbours.begin(), vNeighbours.end(), ParticleDistanceSort );
	unsigned int nMaxNbrs = std::min(sMaxNbrs, (unsigned int)vNeighbours.size() );
#else
	unsigned int nMaxNbrs = (unsigned int)vNeighbours.size();
#endif

	vParticles.resize(nMaxNbrs);
	for ( unsigned int i = 0; i < nMaxNbrs; ++i ) {
		vParticles[i] = vNeighbours[i];
	}
}


void ExpMapGenerator::InitializeNeighbourLists( )
{
	if (! m_bUseMeshNeighbours ) {
		// find max nbr dist
		float fMin = 0, fAverage = 0;
		m_pMesh->GetEdgeLengthStats(fMin, m_fMaxNbrDist, fAverage);
		InitializeParticleGrid(m_fMaxNbrDist);
	}

	if ( m_bPrecomputeNeighbours && ! m_bNeighbourListsValid ) {
		// force nbr generation for all particles
		size_t nParticleCount = m_vParticles.size();	
		for ( unsigned int i = 0; i < nParticleCount; ++i ) 
			GetNeighbourList(m_vParticles[i]);

		m_bNeighbourListsValid = true;
	}
}



void ExpMapGenerator::ClearNeighbourLists()
{
	size_t nParticleCount = m_vParticles.size();
	for ( unsigned int i = 0; i < nParticleCount; ++i ) {
		m_vParticles[i]->ClearNeighbourList();
	}
	m_NeighbourMemoryPool.ClearAll();

	m_bNeighbourListsValid = false;
}









// particle grid setup code

void ExpMapGenerator::InitializeParticleGrid(float fCellSize)
{
	if (m_bParticleGridValid == true )
		return;

	Wml::AxisAlignedBox3f partBounds;
	size_t nParticleCount = m_vParticles.size();	
	for ( unsigned int i = 0; i < nParticleCount; ++i ) {
		ExpMapParticle * pCur = m_vParticles[i];
		if ( i == 0 )
			partBounds = Wml::AxisAlignedBox3f( 
			pCur->Position().X(), pCur->Position().X(),
			pCur->Position().Y(), pCur->Position().Y(),
			pCur->Position().Z(), pCur->Position().Z() );
		else
			rms::Union( partBounds, pCur->Position() );
	}
	// dilate by one cell
	partBounds.XMin() -= fCellSize;  partBounds.XMax() += fCellSize;
	partBounds.YMin() -= fCellSize;  partBounds.YMax() += fCellSize;
	partBounds.ZMin() -= fCellSize;  partBounds.ZMax() += fCellSize;

	m_particleGrid.Initialize( rms::Center(partBounds), fCellSize );

	// add each particle
	for ( unsigned int i = 0; i < nParticleCount; ++i ) {
		ExpMapParticle * pCur = m_vParticles[i];

		m_particleGrid.AddParticle( pCur, pCur->Position() );
	}

	m_bParticleGridValid = true;
}	


void ExpMapGenerator::InitializeParticles( ExpMapParticle * pSkip )
{
	if ( true || m_vLastParticles.empty() ) {
		size_t nParticleCount = m_vParticles.size();
		for ( unsigned int i = 0; i < nParticleCount; ++i ) {
			if ( m_vParticles[i] == pSkip )
				continue;
			m_vParticles[i]->Clear();
		}
	} else {
		size_t nCount = m_vLastParticles.size();
		for ( unsigned int i = 0; i < nCount; ++i ) {
			if ( m_vLastParticles[i] == pSkip )
				continue;
			m_vLastParticles[i]->Clear();
		}
		m_vLastParticles.resize(0);
	}
}









void ExpMapGenerator::SetSurfaceDistances( const Wml::Vector3f & vSeedPoint, float fNeighbourThreshold,
													   float fStopDistance,
													   const Frame3f * pSeedFrame)
{
	_RMSTUNE_start(4);

	// create seed particle
	InitializeNeighbourLists();
	InitializeSeedParticle( vSeedPoint, & pSeedFrame->Z(), pSeedFrame );

	// compute approximate geodesic distances to seed particle
	m_fLastMaxRadius = fStopDistance;
	ComputeExpMap( fStopDistance );

	_RMSTUNE_end(4);
	//_RMSInfo("Total time was %f\n", _RMSTUNE_time(4) );
}

void ExpMapGenerator::SetSurfaceDistances( const Frame3f & vSeedFrame, float fNeighbourThreshold, unsigned int nMaxCount )
{
	_RMSTUNE_start(4);

	// create seed particle
	InitializeNeighbourLists();
	InitializeSeedParticle( vSeedFrame.Origin(), & vSeedFrame.Z(), &vSeedFrame );

	// compute approximate geodesic distances to seed particle
	ComputeExpMap( std::numeric_limits<float>::max(), nMaxCount );

	_RMSTUNE_end(4);
//	_RMSInfo("Total time was %f\n", _RMSTUNE_time(4) );
}



void ExpMapGenerator::ComputeExpMap( float fStopDistance, unsigned int nMaxCount )
{
	// set all particle distances to max and state to inactive
	size_t nParticleCount = m_vParticles.size();
	InitializeParticles( m_pSeedParticle );

	// now initialize pq
	std::multiset< ParticleQueueWrapper > pq;
	UpdateNeighbours( m_pSeedParticle, pq );

	// run until pq is empty
	float fStopDistSquare = fStopDistance / (float)sqrt(2.0f);
	unsigned int nTouched = 0;
	while ( ! pq.empty() && nTouched < nMaxCount ) {

		// pop front	
		ExpMapParticle * pFront = pq.begin()->Particle();
		pq.erase( pq.begin() );

		// freeze particle
		pFront->State() = ExpMapParticle::Frozen;
		m_vLastParticles.push_back( pFront );

		// set frame for pFront
		PropagateFrameFromNearest( pFront );

		if ( pFront->SurfaceDistance() > fStopDistance )
			continue;

		// Square-culling. This gives a significant speed-up...
		if ( m_bEnableSquareCulling ) {
			if ( (float)abs(pFront->SurfaceVector().X()) > fStopDistSquare || 
				(float)abs(pFront->SurfaceVector().Y()) > fStopDistSquare )
				continue;
		}

		// update neighbours
		RemoveNeighbours( pFront, pq );
		UpdateNeighbours( pFront, pq );
		++nTouched;
	}
//	_RMSInfo("Touched %d particles while updating\n", nTouched);

	// mark any left-over particles for cleanup
	std::multiset<ParticleQueueWrapper>::iterator cur(pq.begin()), end(pq.end());
	while ( cur != end ) {
		(*cur).Particle()->SurfaceDistance() = std::numeric_limits<float>::max();
		m_vLastParticles.push_back( (*cur).Particle() );
		++cur;
	}
}




void ExpMapGenerator::RemoveNeighbours( ExpMapParticle * pParticle, std::multiset< ParticleQueueWrapper > & pq )
{
	ExpMapParticle::ListEntry * pCur = GetNeighbourList( pParticle );
	if ( pCur == NULL ) DebugBreak();
	while ( pCur != NULL ) {

		ExpMapParticle * pCurParticle = pCur->pParticle;
		pCur = pCur->pNext;

		if ( pCurParticle->State() != ExpMapParticle::Active )
			continue;

		// find entry in pq
#if 1
		std::multiset<ParticleQueueWrapper>::iterator found( 
			pq.find( ParticleQueueWrapper( pCurParticle->SurfaceDistance() ) ) );
		if ( found != pq.end() ) {

			while ( (*found).Particle() != pCurParticle &&
						(*found).QueueValue() == pCurParticle->SurfaceDistance() )
				++found;

			// [RMS: this should always happen...]
			ASSERT( (*found).Particle() == pCurParticle );
			if ( (*found).Particle() == pCurParticle ) {
				pq.erase( found );
			}
		} else {
			ASSERT( found != pq.end() );
		}

#else 
		std::multiset<ParticleQueueWrapper>::iterator cur( pq.begin() );
		bool bFound = false;
		while ( !bFound && cur != pq.end() ) {
			if ( (*cur).Particle() == pCurParticle ) {
				pq.erase( cur );
				bFound = true;
			} else
				++cur;
		}
		ASSERT( bFound );
#endif

	}
}


void ExpMapGenerator::UpdateNeighbours( ExpMapParticle * pParticle, std::multiset< ParticleQueueWrapper > & pq )
{
	// iterate through neighbours, updating particle distances and pushing onto pq
	ExpMapParticle::ListEntry * pCur = GetNeighbourList( pParticle );
	if ( pCur == NULL ) DebugBreak();
	while ( pCur != NULL ) {

		ExpMapParticle * pCurParticle = pCur->pParticle;
		pCur = pCur->pNext;

		// skip inactive particles
		if ( pCurParticle->State() == ExpMapParticle::Frozen )
			continue;

		// set active state
		pCurParticle->State() = ExpMapParticle::Active;

		// compute new distance
		float fDistToPoint = (pParticle->Position() - pCurParticle->Position()).Length();
		float fSurfDist = fDistToPoint + pParticle->SurfaceDistance();

		// update particle distance and/or nearest particle
		bool bUpdated = false;
		if ( fSurfDist < pCurParticle->SurfaceDistance() ) {
			pCurParticle->SetNearestParticle( pParticle );
			pCurParticle->SurfaceDistance() = fSurfDist;
			bUpdated = true;
		}

		// re-insert particle into priority queue
		pq.insert( ParticleQueueWrapper(pCurParticle) );
	}	

}





ExpMapParticle * ExpMapGenerator::InitializeSeedParticle( const Wml::Vector3f & vPosition,
														  const Wml::Vector3f * pSeedNormal,
														  const Frame3f * pLastSeedPointFrame )
{
	if ( m_pSeedParticle == NULL )
		m_pSeedParticle = new ExpMapParticle();

	ExpMapParticle * pSeedParticle = m_pSeedParticle;
	pSeedParticle->Reset();
	pSeedParticle->Position() = vPosition;
	pSeedParticle->Normal() = *pSeedNormal;
	pSeedParticle->State() = ExpMapParticle::Frozen;

#if 0
	// just use 3 nearest mesh neighbours...
	Wml::Vector3f vNearest;
	IMesh::TriangleID tID;
	if ( ! m_pMeshBVTree->FindNearest( vPosition, vNearest, tID ) )
		DebugBreak();
	IMesh::VertexID nTri[3], nNbrTri[3];
	m_pMesh->GetTriangle( tID, nTri );

	// add direct nbrs
	m_vNeighbourBuf.resize(0);
	for ( int j = 0; j < 3; ++j ) {
		m_vNeighbourBuf.push_back( m_vParticles[ m_vVtxToParticleMap[nTri[j]] ] );
		m_vNeighbourBuf.back()->m_bNbrFlag = true;
	}

	// add each of their one-rings
	NeighborTriBuffer vBuffer;
	for ( int j = 0; j < 3; ++j ) {
		m_pMesh->NeighbourIteration( nTri[j], &vBuffer );
		const std::vector<IMesh::TriangleID> & vTriangles = vBuffer.Triangles();
		size_t nCount = vTriangles.size();
		for ( unsigned int i = 0; i < nCount; ++i ) {
			m_pMesh->GetTriangle( vTriangles[i], nNbrTri );
			for ( int k = 0; k < 3; ++k ) {
				ExpMapParticle * pParticle = m_vParticles[ m_vVtxToParticleMap[nNbrTri[j]] ];
				if ( pParticle->m_bNbrFlag == false ) {
					m_vNeighbourBuf.push_back(pParticle);
					m_vNeighbourBuf.back()->m_bNbrFlag = true;
				}
			}
		}
	}
#else

	// RMS TODO: why does this break m_vLastParticles ?!?!?
	m_vNeighbourBuf.resize(0);
	FindNeighbours( vPosition, *pSeedNormal, m_vNeighbourBuf, m_fMaxNbrDist, pSeedParticle );

#endif

	// ok now add them all as neighbours, and clear neighbour flags
	size_t nCount = m_vNeighbourBuf.size();
	for ( unsigned int i = 0; i < nCount; ++i ) {
		ExpMapParticle::ListEntry * pEntry = m_NeighbourMemoryPool.Allocate();
		pEntry->pParticle = m_vNeighbourBuf[i];
		pSeedParticle->AddNeighbour( pEntry );
		m_vNeighbourBuf[i]->m_bNbrFlag = false;
	}


	// compute 3D frame at seed point
	Frame3f startWorldFrame( pSeedParticle->Position(), pSeedParticle->Normal() );

	// if this argument was passed non-null, try to minimize the tangent-frame rotation of the
	// current seed point wrt the last one
	if ( pLastSeedPointFrame != NULL ) {
		Frame3f vLastFrame( *pLastSeedPointFrame );
		vLastFrame.AlignZAxis( startWorldFrame );
		vLastFrame.Origin() = startWorldFrame.Origin();
		startWorldFrame = vLastFrame;
	}

	pSeedParticle->WorldFrame() = startWorldFrame;
	//pSeedParticle->WorldFrame() = rms::Frame3f();

	return pSeedParticle;
}





void ExpMapGenerator::PropagateFrameFromNearest( ExpMapParticle * pParticle )
{
	ExpMapParticle * pCenterParticle = pParticle->NearestParticle();

	if ( pParticle->SurfaceDistance() == 0.0f ) {
		// pathological case where seed point == input point (or other duplicate points)
		pParticle->SurfaceVector() = pCenterParticle->SurfaceVector();
		return;
	} else { 
		Wml::ExtPlane3f vTangentPlane;
		Frame3f vCenterWorldFrame;
		Wml::Matrix2f matFrameRotate;
		PrecomputePropagationData( pCenterParticle, vTangentPlane, vCenterWorldFrame, matFrameRotate );

		pParticle->SurfaceVector() = ComputeSurfaceVector( pCenterParticle, pParticle, 
			vTangentPlane, vCenterWorldFrame, matFrameRotate );
	}

	// check error and re-set distance if it is too high
#if 1
	float fVecLengthSqr = pParticle->SurfaceVector().SquaredLength();
	float fError = fabs(
		fVecLengthSqr / (pParticle->SurfaceDistance()*pParticle->SurfaceDistance()) - 1.0f );
	static const float s_fMaxErr = 2*0.5f - 0.5f*0.5f;		// 0.5f == 50% - arbitrary threshold...
	if ( fError > s_fMaxErr ) {
		if ( true ) {
			pParticle->SurfaceVector().Normalize();
			pParticle->SurfaceVector() *= pParticle->SurfaceDistance();
			//_RMSInfo("Fix!\n");
		}
	}
#endif
}








void ExpMapGenerator::PrecomputePropagationData( ExpMapParticle * pCenterParticle,
															 Wml::ExtPlane3f & vTangentPlane, 
															 Frame3f & vCenterWorldFrame,
															 Wml::Matrix2f & matFrameRotate )
{
	// compute 3D frame at center point
	vCenterWorldFrame = pCenterParticle->WorldFrame();

	// compute surface-tangent plane at particle
	Wml::Vector3f vNormal( pCenterParticle->Normal() );
	//Wml::Vector3f vNormal( vCenterWorldFrame.Z() );

	// compute plane at this point
	vTangentPlane = Wml::ExtPlane3f( vNormal, pCenterParticle->Position() );


	// rotate seed world frame Z into this particle's Z
	Frame3f seedWorldFrame( m_pSeedParticle->WorldFrame() );
	seedWorldFrame.AlignZAxis( vCenterWorldFrame );

	// compute cos(angle) between axis
	Wml::Vector3f vCenterAxisX( vCenterWorldFrame.Axis( Frame3f::AxisX ) );
	Wml::Vector3f vSeedAxisX( seedWorldFrame.Axis( Frame3f::AxisX ) );
	float fCosTheta = vCenterAxisX.Dot(vSeedAxisX);

	// compute rotated min-dist vector for this particle
	float fTmp = 1 - fCosTheta*fCosTheta;
	if ( fTmp < 0 ) fTmp = 0;		// need to clamp so that sqrt works...
	float fSinTheta = (float)sqrt(fTmp);
	Wml::Vector3f vCross = vCenterAxisX.Cross(vSeedAxisX);
	if ( vCross.Dot( vNormal ) < 0 )	// get the right sign...
		fSinTheta = -fSinTheta;

	// create transposed 2D rotation matrix
	matFrameRotate = Wml::Matrix2f( fCosTheta, fSinTheta, -fSinTheta, fCosTheta );
}

Wml::Vector2f ExpMapGenerator::ComputeSurfaceVector( ExpMapParticle * pCenterParticle, 
																 ExpMapParticle * pNbrParticle,
																 Wml::ExtPlane3f & vTangentPlane, 
																 Frame3f & vCenterWorldFrame, 
																 Wml::Matrix2f & matFrameRotate )
{
	// project point into plane
	Wml::Vector3f vPlanePoint = vTangentPlane.RotatePointIntoPlane( pNbrParticle->Position(), & pNbrParticle->Normal() );

	// project point into coord system of frame
	vPlanePoint -= pCenterParticle->Position();
	vCenterWorldFrame.ToFrameLocal(vPlanePoint);

	// now we can project into surface frame simply by dropping z (which should be 0 anyway,
	//   since the vector lies in the plane!)
	Wml::Vector2f vSurfaceFrame( vPlanePoint.X(), vPlanePoint.Y() );

	// reverse vector so it points back to current particle
	vSurfaceFrame *= -1.0f;

	// transform local vector into coord system of initial surface reference frame
	//  and add accumulated surface vector
	return pCenterParticle->SurfaceVector() + (matFrameRotate * vSurfaceFrame);
}


rms::Frame3f ExpMapGenerator::GetSeedFrame()
{
	if ( m_pSeedParticle )
		return m_pSeedParticle->WorldFrame();
	else
		return rms::Frame3f();
}

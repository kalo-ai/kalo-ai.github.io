/*Copyright (C) 2016 Yahan Zhou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "..\SSSLib\SSSLibOGL\SSSVolMesh.h"
#include "..\SSSLib\SSSLibOGL\SSSMesh.h"
#include "..\SSSLib\SSSFunc.h"
#include <string>
#include <iostream>
#include <algorithm>

using namespace std;

int main(int argc, char* argv[])
{
	assert(argc>2);
	string inFileName(argv[1]);
	string outFileName(argv[2]);
	transform(inFileName.begin(), inFileName.end(), inFileName.begin(), tolower);
	transform(outFileName.begin(), outFileName.end(), outFileName.begin(), tolower);
	SSSLib::SSSMesh mesh;
	if (inFileName.substr(inFileName.length()-3, 3)=="obj")
		mesh.LoadObj(argv[1]);
	else if (inFileName.substr(inFileName.length()-4, 4)=="mesh")
		mesh.LoadDisteneMesh(argv[1]);
	else
		cout<<"Unsupport format "<<argv[1]<<endl;

	//mesh.Scale(SSSLib::Vec3d(4, 4, 2));
	//mesh.Scale(SSSLib::Vec3d(19.1/6, 19.1/6, 9.2456/2.5/2));
	//mesh.Scale(SSSLib::Vec3d(0.2, 0.2, 0.2));
	//mesh.Rotate(SSSLib::Vec3d(1,0,0), -SSSLib::Pi/2);
	//mesh.Scale(SSSLib::Vec3d(10.0, 10.0, 10.0));
	double scaleRate = 1.0457827922293529138827169838907;
	mesh.Scale(SSSLib::Vec3d(scaleRate, scaleRate, scaleRate));

	if (outFileName.substr(outFileName.length()-3, 3)=="stl")
		mesh.WriteStl(argv[2]);
	else if (outFileName.substr(outFileName.length()-3, 3)=="obj")
		mesh.WriteObj(argv[2]);
	else if (outFileName.substr(outFileName.length()-4, 4)=="mesh")
		mesh.WriteDisteneMesh(argv[2]);
	else if (outFileName.substr(outFileName.length()-4, 4)=="node")
		SSSLib::SSSVolMesh::WriteNodes(outFileName.c_str(), mesh.mVtx);
	else
		cout<<"Unsupport format "<<argv[2]<<endl;
	return 0;
}


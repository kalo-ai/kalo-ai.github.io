/*Copyright (C) 2016 Yahan Zhou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "..\..\StaticADMMLib\PhysImpSolve3D.h"
#include "..\..\SSSLib\SSSColor.h"
#include <fstream>
#include <string>

using namespace std;
using namespace SSSLib;

PhysImpSolve3D gSolver;
SSSLib::SSSVolMesh gVolMesh;

string prefix = "script\\";
bool gbShowVM = false;
bool gbNormVol = false;

void PrintNodeFile(const std::map<int, _T_FLOAT>& iContainer,
				   int iOffset,
				   const char* iFileName,
				   const char* iTagName)
{
	ofstream outFile(iFileName);
	outFile<<"*NSET,NSET="<<iTagName<<endl;
	for (std::map<int, _T_FLOAT>::const_iterator ite = iContainer.begin();
		ite != iContainer.end();
		ite++)
		outFile<<ite->first+iOffset<<",\n";
}

void OutputCalculixFile(const char* iFileName, const char* iMeshName)
{
	ofstream outFile(iFileName);
	outFile<<"*INCLUDE,INPUT="<<iMeshName<<"\n\n";

	// boundary
	if (gSolver.mFixedForce.size()>0)
	{
		PrintNodeFile(gSolver.mFixedForce, 1, (prefix+"fix.nam").c_str(), "Nfix");
		outFile<<"*INCLUDE,INPUT=fix.nam\n";
		outFile<<"*BOUNDARY\nNfix,1,3\n\n";
	}

	// material
	outFile<<"*MATERIAL,NAME=EL\n"
			<<"*ELASTIC\n"
			<<gSolver.mYoungs<<","<<gSolver.mPR<<endl
			<<"*DENSITY\n"
			<<gSolver.mDensity<<endl;

	if (gVolMesh.mTets.size()>0)
		outFile<<"*SOLID SECTION,ELSET=PART1,MATERIAL=EL\n\n";
	if (gVolMesh.mHexs.size()>0)
		outFile<<"*SOLID SECTION,ELSET=PART2,MATERIAL=EL\n\n";

	//step
	outFile<<"*STEP\n"
			<<"*STATIC\n"
			<<"*NODE FILE\n"
			<<"U\n"
			<<"*EL FILE\n"
			<<"S, E\n\n";

	// node load
	{
		ofstream forceFile((prefix+"load.frc").c_str());
		for (int i=0; i<(int)gSolver.mVtxPresetForce.size(); i++)
		for (int c=0; c<3; c++)
		if (gSolver.mVtxPresetForce[i][c]!=0)
		{
			forceFile<<i+1<<","<<c+1<<","<<gSolver.mVtxPresetForce[i][c]<<endl;
		}

		outFile<<"*CLOAD\n"
			<<"*INCLUDE,INPUT=load.frc\n\n";
	}

	outFile<<"*END STEP\n";

}

// debugging setup
// tet
// parameters: VM twisted_stool2.xml vmclr.obj tmp.data
//
// hex
// parameters: VM cube.xml vmclr.obj tmp.data

int main(int argc, char* argv[])
{
	if (argc==1)
	{
		cout<<"Usage:\n"
			<<"\t1. [VM] (von Mises color encoding) or [DISP] (displacement)\n"
			<<"\t2. [xml config file]\n"
			<<"\t3. [output color encoding file name]\n"
			<<"\t4. [state file name (.data)]\n"
			<<"\t5. [color encoding max value]\n"
			<<"\t6. [true or false, is normalized]";

		return 0;
	}

	if (strcmp(argv[1], "vm") == 0 || strcmp(argv[1], "VM") == 0)
		gbShowVM = true;
	else
		gbShowVM = false;

	if (argc>6 && strcmp(argv[6], "true")==0)
		gbNormVol = true;

	string cmd = "mkdir ";
	cmd += prefix;
	system(cmd.c_str());

	Vec3d low;
	Vec3d high;

	gSolver.ParseConfigFile(argv[2], gVolMesh);

	gVolMesh.mSurfaceMesh.ComputeBB(low, high);
	double maxDim = high[0]-low[0];
	maxDim = Max(maxDim, Max(high[1]-low[1], high[2]-low[2]));

	gSolver.mX0 = gVolMesh.mVtx;
	gSolver.mXV.clear();
	gSolver.mXV.resize(gSolver.mX0.size(), SVec3Float(0, 0, 0));

	gSolver.mXRef = gSolver.mX0;
	gSolver.mP0 = gSolver.mX0;
	gSolver.mPV = gSolver.mXV;

	vector<Vec2i> hexEdges;
	gVolMesh.ComputeHexEdges(hexEdges);
	gSolver.mpEdges = &gVolMesh.mSurfaceMesh.mEdges;
	gSolver.mpHexEdges = &hexEdges;
	gSolver.Init(&gVolMesh);

	

	string vmFileName;
	string vmFilePrefix(argv[2]);

	SSSVolMesh originalMesh = gVolMesh;

	gSolver.mbStatic = true;

	// for debug
	//{
	//	gSolver.mbStatic = true;
	//	gSolver.mbCorotation = false;
	//}
	double originalVol = gVolMesh.mSurfaceMesh.ComputeSignedVol();

	if (argc>4)
	{
		gSolver.LoadState(argv[4]);

		// for debug
		//{
		//	gSolver.RunPhysics(1e-5, 5);
		//}
		
		gVolMesh.mVtx = gSolver.mX0;
		gVolMesh.BuildSurfaceMesh();

		vmFileName = "solverMaxVM.txt";

		if (gbNormVol)
		{
			double volAfter = gVolMesh.mSurfaceMesh.ComputeSignedVol();

			if (volAfter<0)
				return 0;

			for (int i=0; i<(int)gVolMesh.mVtx.size(); i++)
				gVolMesh.mVtx[i] = originalMesh.mVtx[i]*pow(volAfter/originalVol, 1/3.0);

			gVolMesh.mSurfaceMesh.mVtx = gVolMesh.mVtx;

			gSolver.mXV.assign(gSolver.mX0.size(), SVec3Float(0, 0, 0));
			gSolver.mPV.assign(gSolver.mX0.size(), SVec3Float(0, 0, 0));
			gSolver.mX0 = gVolMesh.mVtx;
			gSolver.mP0 = gVolMesh.mVtx;

			gSolver.RunPhysics(1e-4, 5);


			vmFileName = "normMaxVM.txt";
		}

	}
	else
	{
		gSolver.RunPhysics(1e-4, 5);
		//if (gbShowVM)

		vmFileName = "defaultSolverMaxVM.txt";
		gVolMesh.BuildSurfaceMesh();
	}

	if (gbShowVM)
	{
		gSolver.ComputeVMForce(true, PhysImpSolve3D::ContVM);
		gSolver.ComputeVMPerVtx();
	}

	//gVolMesh.BuildSurfaceMesh();

	// output color encoded mesh
	{
		double clrScale = -1;
		if (argc>5)
		{
			clrScale = atof(argv[5]);
		}

		if (clrScale<0)
		for (int i=0; i<(int)gSolver.mX0.size(); i++)
		{
			double val;
			if (gbShowVM)
				val = sqrt(gSolver.mVMVtx[i]);
			else
				val = (gSolver.mX0[i]-gSolver.mXRef[i]).Length();
			clrScale = Max(clrScale, val);
		}

		SSSMesh& surface = gVolMesh.mSurfaceMesh;
		surface.mColor.resize(surface.mVtx.size());

		for (int i=0; i<(int)surface.mVtx.size(); i++)
		{
			double val = 0;
			if (gbShowVM)
				val = sqrt(gSolver.mVMVtx[i]);
			else
				val = (gSolver.mX0[i]-gSolver.mXRef[i]).Length();
			surface.mColor[i] = Value2RGBJet(val/clrScale);
		}

		Vec3d newLow;
		Vec3d newHigh;
		surface.ComputeBB(newLow, newHigh);
		surface.Translate(-(newLow+newHigh)/2);
		surface.Scale(Vec3d(1/maxDim, 1/maxDim, 1/maxDim));

		surface.WriteObj(argv[3]);
		vmFilePrefix = argv[3];
		
	}	

	int cutPst = Max(vmFilePrefix.find_last_of("\\"), vmFilePrefix.find_last_of("/"));
	if (cutPst==string::npos)
		cutPst = -1;
	vmFilePrefix.erase(vmFilePrefix.begin()+1+cutPst, vmFilePrefix.end());

	//gSolver.ComputeVMForce(true, PhysImpSolve3D::ContVM);
	
	if (gbShowVM)
	{
		double maxVM = sqrt(gSolver.ComputeMaxVM());
		ofstream vmFile(vmFilePrefix+vmFileName);
		vmFile<<maxVM;

		gVolMesh.WriteAbaqusMsh((prefix+"mesh.msh").c_str());

		//ofstream outFile((prefix+"out.inp").c_str());
		OutputCalculixFile((prefix+"out.inp").c_str(), "mesh.msh");
	}

	//if (argc>3)
	//{
	//	double originalVol = originalMesh.mSurfaceMesh.ComputeSignedVol();
	//	double deformedVol = gVolMesh.mSurfaceMesh.ComputeSignedVol();

	//	cout<<"Original Vol: "<<originalVol<<endl
	//		<<"Deformed Vol: "<<deformedVol<<endl;

	//	for (int i=0; i<(int)gVolMesh.mVtx.size(); i++)
	//		gVolMesh.mVtx[i] = originalMesh.mVtx[i]*deformedVol/originalVol;

	//	gVolMesh.WriteAbaqusMsh((prefix+"mesh_norm.msh").c_str());

	//	OutputCalculixFile((prefix+"out_norm.inp").c_str(), "mesh_norm.msh");
	//}

	return 0;
}
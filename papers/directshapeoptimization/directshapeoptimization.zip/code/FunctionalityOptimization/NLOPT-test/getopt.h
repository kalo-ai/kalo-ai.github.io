#ifndef GETOPT_H
#define GETOPT_H

extern int getopt(int nargc, char * const nargv[], const char *ostr) ;
extern char    *optarg;                /* argument associated with option */

#endif
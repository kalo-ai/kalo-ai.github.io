/*Copyright (C) 2016 Yahan Zhou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "..\StaticADMMLib\PhysImpSolve3D.h"
#include <gl\glew.h>
#include <GL\freeglut.h>
#include <iostream>
#include <fstream>
#include "..\SSSLib\SSSLibOGL\SSSVolMesh.h"
#include "..\SSSLib\SSSLibOGL\OGLFrame.h"
#include "..\SSSLib\SSSLibOGL\OGLCamModel.h"

using namespace SSSLib;
using namespace std;

//#define _VTK_RELAX
//#define _CUBE_TET_RELAX
#define _INP_RELAX

OGLCamModel* g_testCam;
SSSVolMesh gHexMesh;
int gShowHex = 0;
int gShowVtx = 0;
int gRender = 1;

Vec3f gModelCenter(0, 0, 0);
float gModelScale = 1.0f;

void SetVtxColor(int iVtx)
{
	if (gHexMesh.mSurfaceMesh.mbPlanarVtx.size()>0)
	{
		if (gHexMesh.mSurfaceMesh.mbPlanarVtx[iVtx])
			glColor3ub(0, 0, 255);
		else
			glColor3ub(255, 255, 255);
	}
}

void RenderHex(int iHex, int iCenteringOption, Vec3f iCenter = Vec3f(0, 0, 0))
{
	SSSVolMesh::_THex hex = gHexMesh.mHexs[iHex];
	Vec3d centering(0, 0, 0);
	if (iCenteringOption==1)
	{
		for (int v=0; v<8; v++)
			centering += gHexMesh.mVtx[hex[v]];
		centering /= 8;
	}
	else if (iCenteringOption==2)
		centering = iCenter;
	for (int f=0; f<6; f++)
	{
		Vec4i face = gHexMesh.GetHexFace(f);
		
		for (int vv=0; vv<4; vv++)
		{
			int v = vv;
			if (vv==2)
				v = 3;
			else if (vv==3)
				v = 2;
			SetVtxColor(hex[face[v]]);
			glVertex3dv((gHexMesh.mVtx[hex[face[v]]]-centering).val);
		}
		//for (int i=0; i<3; i++)
		//{
		//	glVertex3fv((gHexMesh.mVtx[hex[face[i]]]-centering).val);
		//}
		//for (int i=3; i>=1; i--)
		//{
		//	glVertex3fv((gHexMesh.mVtx[hex[face[i]]]-centering).val);
		//}
	}
}

void TestRender(OGLScene::TStageName, int)
{

	g_testCam->SetProjMatrix();
	g_testCam->SetViewMatrix();
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glColor3f(1.0f, 1.0f, 1.0f);

	glBegin(GL_TRIANGLES);
	if (0)
	for (int t=0; t<(int)gHexMesh.mSurfaceMesh.mFace.size(); t++)
	{
		Vec3i face = gHexMesh.mSurfaceMesh.mFace[t];
		for (int v=0; v<3; v++)
			glVertex3dv(gHexMesh.mSurfaceMesh.mVtx[face[v]].val);
	}
	glEnd();

	glBegin(GL_LINES);
	if (0)
	for (int i=0; i<(int)gHexMesh.mSurfaceMesh.mQuad.size(); i++)
	{
		Vec4i quad = gHexMesh.mSurfaceMesh.mQuad[i];
		for (int j=0; j<4; j++)
		{
			SetVtxColor(quad[j]);
			glVertex3dv(gHexMesh.mSurfaceMesh.mVtx[quad[j]].val);
			SetVtxColor(quad[(j+1)%4]);
			glVertex3dv(gHexMesh.mSurfaceMesh.mVtx[quad[(j+1)%4]].val);
		}
	}
	glEnd();

	glBegin(GL_LINES);
	if (0)
	{
		if (0)
		RenderHex(gShowHex, 1);

		//if (0)
		for (int h=0; h<(int)gHexMesh.mHexs.size(); h++)
		{
			bool brender = false;
			SSSVolMesh::_THex hex = gHexMesh.mHexs[h];
			for (int v=0; v<8; v++)
			if (hex[v] == gShowVtx)
				brender = true;
			if (brender)
				RenderHex(h, 2, gHexMesh.mVtx[gShowVtx]);
		}
	}
	glEnd();

	//if (0)
	{
		glColor3f(0.0f, 0.0f, 0.8f);
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glBegin(GL_QUADS);
			RenderHex(gShowHex, 0);
		glEnd();

		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		glColor3f(1.0f, 1.0f, 1.0f);
		glBegin(GL_QUADS);
		for (int h=0; h<(int)gHexMesh.mHexs.size(); h++)
		{
			bool brender = false;
			SSSVolMesh::_THex hex = gHexMesh.mHexs[h];
			RenderHex(h, 0);
		}
		glEnd();
	}
	glFlush();
	glutSwapBuffers();
}

void Keyboard(unsigned char iKey, int x, int y)
{
	switch (iKey)
	{
	case '+':
		gShowHex = (gShowHex+1)%gHexMesh.mHexs.size();
		gShowVtx = (gShowVtx+1)%gHexMesh.mVtx.size();
		break;
	case '-':
		gShowHex = (gShowHex+gHexMesh.mHexs.size()-1)%gHexMesh.mHexs.size();
		gShowVtx = (gShowVtx+gHexMesh.mVtx.size()-1)%gHexMesh.mVtx.size();
		break;
	case 'c':
		{
			/*int mode;
			glGetIntegerv(GL_CULL_FACE_MODE, &mode);
			if (mode==GL_FRONT_AND_BACK)
				glCullFace(GL_BACK);
			else
				glCullFace(GL_FRONT_AND_BACK);*/
			if (glIsEnabled(GL_CULL_FACE))
				glDisable(GL_CULL_FACE);
			else
				glEnable(GL_CULL_FACE);
		}
		break;
	}
}

void CheckHex()
{
	int badHex = 0;
	vector<MatXFloat, Eigen::aligned_allocator<MatXFloat> > hmat(8);
	for (int i=0; i<8; i++)
	{
		SVec3Float coord(i&1, (i>>1)&1, (i>>2)&1);
		coord = coord*2-1;
		coord = coord/sqrt(3);
		hmat[i] = PhysImpSolve3D::HexBuildH(coord, 8);
	}
	Vec3Float vtx[8];
	for (int h=0; h<(int)gHexMesh.mHexs.size(); h++)
	{
		SSSVolMesh::_THex hex = gHexMesh.mHexs[h];
		Vec3Float ox[3];
		int localBad = 0;
		for (int p=0; p<8; p++)
		{
			SVec3Float val = gHexMesh.mVtx[hex[p]];
			vtx[p] = Vec3Float(val.val);
		}
		for (int p=0; p<8; p++)
		{
			PhysImpSolve3D::HexEncode(vtx, hmat[p], ox);
			Mat3x3 mat;
			mat<<ox[0],ox[1],ox[2];
			_T_FLOAT vol = mat.determinant();
			if (vol<0)
			{
				badHex++;
				localBad++;
			}
		}

		if (localBad==8)
			cout<<"Reorderable\n";
	}
	cout<<"# of Bad Hex:\t"<<badHex<<endl;
}

void main(int argc, char* argv[])
{
	OGLFrame::Init(512, 512);
	//OGLFrame::GetInstance()->SetCommonFunction();
	OGLFrame::GetInstance()->AddRenderExt(TestRender);
	OGLFrame::GetInstance()->AddKeyboard(Keyboard);
	OGLFrame::EnableIdleRender();

	g_testCam = new OGLCamModel();
	g_testCam->EnableCam(OGLFrame::GetInstance());
	
	//glPolygonMode(GL_FRONT, GL_LINE);
	//glPolygonMode(GL_BACK, GL_LINE);

	//glEnable(GL_CULL_FACE);

	//{
	//	vector<Vec3i> cubes(8);
	//	for (int i=0; i<8; i++)
	//		cubes[i] = Vec3i(((i&4)>>2), (i&2)>>1, i&1);
	//	gHexMesh.BuildCubeMesh(&cubes[0], 8, Vec3f(1.0f, 1.0f, 1.0f), 1.0f, NULL, NULL);

	//}

#if defined(_VTK_RELAX) || defined(_INP_RELAX)

	if (strcmp(argv[1]+strlen(argv[1])-3, "vtk")==0)
		gHexMesh.LoadVtk(argv[1]);
	else if (strcmp(argv[1]+strlen(argv[1])-3, "inp")==0)
		gHexMesh.LoadInp(argv[1]);
	else if (strcmp(argv[1]+strlen(argv[1])-4, "mesh")==0)
		gHexMesh.LoadDisteneMesh(argv[1]);
	else
	{
		cout<<"Unrecognized format: "<<argv[1]<<endl;
		exit(1);
	}
	//Vec3i cube(0, 0, 0);
	//gHexMesh.BuildCubeMesh(&cube, 1, Vec3f(0, 0, 0), 1.0, NULL, NULL);
	
	gHexMesh.FindIntVtx();
	gHexMesh.BuildSurfaceMesh(false, true);

	Vec3d low, high;
	gHexMesh.mSurfaceMesh.ComputeBB(low, high);
	gModelCenter = (low+high)*0.5f;
	Vec3d delta = high-low;
	gModelScale = 1.0f/Max(Max(delta[0], delta[1]), delta[2]);
	//for (int i=0; i<(int)gHexMesh.mVtx.size(); i++)
	//{
	//	gHexMesh.mVtx[i] = (gHexMesh.mVtx[i]-gModelCenter)*gModelScale;
	//}

	//for (int i=0; i<(int)gHexMesh.mSurfaceMesh.mVtx.size(); i++)
	//{
	//	gHexMesh.mSurfaceMesh.mVtx[i] = (gHexMesh.mSurfaceMesh.mVtx[i]-gModelCenter)*gModelScale;
	//}
	//CheckHex();
	gHexMesh.Translate(-gModelCenter);
	//gHexMesh.Scale(0.1);
	//gHexMesh.Scale(gModelScale);
	//gHexMesh.Rotate(Vec3f(1.0f, 0, 0), -Pi/2);
	//gHexMesh.Rotate(Vec3f(0.0f, 0, 1.0f), Pi/2);

	//gHexMesh.mSurfaceMesh.VtxPlanarRelaxProc();
	//gHexMesh.Scale(Vec3d(1.0, 0.25, 1.0));
	gHexMesh.mVtx = gHexMesh.mSurfaceMesh.mVtx;
	gHexMesh.HexVtxRelax();
	//gHexMesh.HexVtxRelax();
	//gHexMesh.HexVtxRelax();

	CheckHex();
#elif defined _CUBE_TET_RELAX

	vector<Vec3i> cubes;
	int reso = 1;
	for (int x=0; x<reso; x++)
	for (int y=0; y<reso; y++)
	for (int z=0; z<reso; z++)
		cubes.push_back(Vec3i(x, y, z));
	vector<Vec2i> edges;
	vector<Vec2i> hexEdges;
	gHexMesh.BuildCubeMesh(&cubes[0], reso*reso*reso, Vec3f(-0.5f*reso, -0.5f*reso, -0.5f*reso), 1.0f/reso, &edges, &hexEdges);

	gHexMesh.mHexs.clear();
	gHexMesh.Tet2Hex();
	gHexMesh.mTets.clear();
	gHexMesh.FindIntVtx();
	gHexMesh.BuildSurfaceMesh();

	gHexMesh.HexVtxRelax();
	CheckHex();

#endif

	if (argc>2)
		gHexMesh.WriteVtk(argv[2]);

	if (argc>3)
	{
		gHexMesh.BuildSurfaceMesh(true, false);
		gHexMesh.mSurfaceMesh.WriteObj(argv[3]);
		//gHexMesh.mSurfaceMesh.WriteStl(argv[3]);
	}

	gHexMesh.Scale(gModelScale);

	glutMainLoop();
}

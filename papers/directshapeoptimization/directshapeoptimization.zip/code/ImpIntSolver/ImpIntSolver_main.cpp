/*Copyright (C) 2016 Yahan Zhou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <gl\glew.h>

#include "..\StaticFEM\Static2d.h"
#include "..\StaticFEM\StaticTable.h"
#include "..\StaticADMMLib\PhysImpSolve.h"
#include "..\SSSLib\SSSLibOGL\OGLFrame.h"
#include "..\SSSLib\SSSLibOGL\OGLCamModel.h"
#include "..\SSSLib\SSSLibOGL\OGLSimpleObj.h"
#include "..\SSSLib\SSSLibOGL\OGLTexture.h"
#include "..\SSSLib\SSSLibOGL\OGLSEasyProgram.h"
#include "..\SSSLib\SSSSmallVec.h"
#include "..\SSSLib\SSSColor.h"
#include "..\SSSLib\SSSFunc.h"
#include <iostream>
//#include "..\FEMLib\FEMObj.h"
#include <Windows.h>
#include <GL\freeglut.h>

#ifdef _USE_MATLAB
#pragma comment(lib, "mclmcrrt.lib")
#pragma comment(lib, "FOptLib.lib")
#endif

using namespace SSSLib;
using namespace std;

OGLCamModel* g_testCam;
OGLSEasyProgram* g_pProgram;
StaticTable gFEM;
PhysImpSolve g_PhysImp;

int gWindowHeight = 500;
int gSteps = 0;

void TestRender(OGLScene::TStageName, int)
{
	gSteps++;
	//g_PhysImp.PStep(1e-3);
	g_PhysImp.ComputeExtForce();

	//g_PhysImp.XPStep(2e-2);
	g_PhysImp.XPStep(1e-2);
	//g_PhysImp.XPStep(2e-3);
	//g_PhysImp.XPStep(1e-3);
	//g_PhysImp.XPStep(1e-4);
	//g_PhysImp.XPStep(1e-5);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glViewport(0, 0, gWindowHeight, gWindowHeight);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glColor3f(1.0f, 1.0f, 1.0f);

	glBegin(GL_LINES);
		for (int i=0; i<(int)gFEM.mTriangles.size(); i++)
		{
			Vec3i tri = gFEM.mTriangles[i];
			for (int v=0; v<3; v++)
			{
				glVertex2dv((double*)&gFEM.mRest[tri[v]]);
				glVertex2dv((double*)&gFEM.mRest[tri[(v+1)%3]]);
			}
		}
	glEnd();
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glViewport(gWindowHeight, 0, gWindowHeight, gWindowHeight);

	glBegin(GL_LINES);
		for (int i=0; i<(int)gFEM.mTriangles.size(); i++)
		{
			Vec3i tri = gFEM.mTriangles[i];
			_T_FLOAT val = gFEM.ComputeVM(i)/g_PhysImp.mVMBound;
			//cout<<"\tVM\t"<<gFEM.ComputeVM(i);
			Vec3uc clr = SSSLib::Value2RGBuc(0.4999f+float(SSSLib::clamp(val*0.5, 0.0, 0.5)));
			if (val>1.0)
				clr = Vec3uc(255, 0, 255);
			glColor3ub(clr[0], clr[1], clr[2]);
			for (int v=0; v<3; v++)
			{
				glVertex2dv((double*)&gFEM.mStatic[tri[v]]);
				glVertex2dv((double*)&gFEM.mStatic[tri[(v+1)%3]]);
			}
		}
	glEnd();

	//cout<<endl;

	glFlush();
	glutSwapBuffers();
	int err = glGetError();
	if (err>0)
		std::cout<<"Drawing Error:"<<err<<std::endl;
}

void Keyboard(unsigned char iKey, int x, int y)
{
	switch (iKey)
	{
	case '+':
		g_PhysImp.mVMBound *= 1.2;
		cout<<"New Von Mises Crit:"<<g_PhysImp.mVMBound<<endl;
		break;
	case '-':
		g_PhysImp.mVMBound /= 1.2;
		cout<<"New Von Mises Crit:"<<g_PhysImp.mVMBound<<endl;
		break;
	case 'q':
		g_PhysImp.mVMWeight *= 1.5;
		cout<<"New Von Mises Weight:"<<g_PhysImp.mVMWeight<<endl;
		break;
	case 'w':
		g_PhysImp.mVMWeight /= 1.5;
		cout<<"New Von Mises Weight:"<<g_PhysImp.mVMWeight<<endl;
		break;

	}
}

void KeyboardUp(unsigned char iKey, int x, int y)
{
	switch (iKey)
	{
	case 'r':
		g_PhysImp.Init();
		break;
	}
}

void BuildTable()
{

	int reso = 3;

	gFEM.InitParam(1e8, 0.3f);

	gFEM.SetParameters(8*reso, 1*reso, 5*reso, 4*reso, 1*reso, 0, 0, 0.2f/reso);
	gFEM.BuildTable();

	//int reso = 1;
	//gFEM.InitParam(1e7, 0.0f);

	//gFEM.SetParameters(0, 0, 0, 0, 0, 0, 0, 1/1.0f);
	//gFEM.BuildRect(reso, 0, 0, reso);
	//gFEM.mOrigin[0] = reso*0.5;
	//gFEM.mOrigin[1] = reso*0.5;`
	//gFEM.BuildFloatVtx();

	//for (map<Vec2i, int>::iterator ite = gFEM.mPt2Idx.begin();
	//	ite != gFEM.mPt2Idx.end();
	//	ite++)
	//if (ite->first[1]==reso)
	//{
	//	gFEM.mFixedVtx[ite->second] = 1;
	//}
}

void main(int argc, char** argv)
{

	OGLFrame::Init(gWindowHeight*2,gWindowHeight);
	//OGLFrame::GetInstance()->SetCommonFunction();
	OGLFrame::GetInstance()->AddRenderExt(TestRender);
	OGLFrame::GetInstance()->AddKeyboard(Keyboard);
	OGLFrame::GetInstance()->AddKeyboardUp(KeyboardUp);
	OGLFrame::EnableIdleRender();
	//OGLFrame::GetInstance()->AddKey0board(
	g_testCam = new OGLCamModel();
	g_testCam->EnableCam(OGLFrame::GetInstance());

	BuildTable();

	//gFEM.InitRect(2, 2, 0.9);
	////gFEM.InitParam(1e7, 0.3f);
	//gFEM.InitParam(1e7, 0.0f);
	////gFEM.InitParam(2e3, 0.0f);
	//gFEM.mForce[0] = Vec2Float(0, -5e4f);
	//gFEM.mForce[1] = Vec2Float(0, -5e4f);
	//gFEM.mFixedVtx[2] = 1;
	//gFEM.mFixedVtx[3] = 1;

	//gFEM.InitRect(6, 6, 0.15);
	////gFEM.InitParam(1e7, 0.3f);
	//gFEM.InitParam(1e7, 0.0f);
	////for (int i=0; i<(int)gFEM.mForce.size(); i++)
	////	gFEM.mForce[i] = Vec2Float(0, -9.8f);
	//gFEM.mForce[0] = Vec2Float(0, -1e4);
	//gFEM.mForce[5] = Vec2Float(0, -1e4);
	////gFEM.mForce[30] = Vec2Float(0, -10.0f);
	////gFEM.mForce[5] = Vec2Float(-10.0f, 0);
	////gFEM.mForce[33] = Vec2Float(0, 10.0f);
	////gFEM.mForce[32] = Vec2Float(0, 9.8f);
	////gFEM.mForce[35] = Vec2Float(0, -9.8f);
	//gFEM.mFixedVtx[30] = 1;
	//gFEM.mFixedVtx[31] = 1;
	//gFEM.mFixedVtx[32] = 1;
	//gFEM.mFixedVtx[33] = 1;
	//gFEM.mFixedVtx[34] = 1;
	//gFEM.mFixedVtx[35] = 1;

	g_PhysImp.mpStatic2D = &gFEM;
	g_PhysImp.mDensity = 1e4;
	g_PhysImp.Init();

	gFEM.SetGravityWithMassVec(g_PhysImp.mMass);

	cout<<"Length\t"<<gFEM.mRest[gFEM.mRest.size()-1]-gFEM.mRest[0]<<endl;
	//glewInit();
	//g_pProgram = new OGLSEasyProgram(NULL,"restshader.txt");
	//g_pProgram->Use();
	glutMainLoop();
}

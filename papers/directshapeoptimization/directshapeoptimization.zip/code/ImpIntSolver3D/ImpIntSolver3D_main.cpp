/*Copyright (C) 2016 Yahan Zhou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "../StaticADMMLib/PhysImpSolve3D.h"

#ifndef _NO_GL
#include <GL/glew.h>

//#include "../StaticFEM/Static2d.h"
//#include "../StaticFEM/StaticTable.h"

#include "../SSSLib/SSSLibOGL/OGLFrame.h"
#include "../SSSLib/SSSLibOGL/OGLCamModel.h"
#include "../SSSLib/SSSLibOGL/OGLSimpleObj.h"
#include "../SSSLib/SSSLibOGL/OGLTexture.h"
#include "../SSSLib/SSSLibOGL/OGLSEasyProgram.h"
#include <GL/freeglut.h>
#include "../SSSLib/SSSLibOGL/OGLFunc.h"
#endif

#include "../SSSLib/SSSSmallVec.h"
#include "../SSSLib/SSSColor.h"
#include "../SSSLib/SSSFunc.h"
#include "../SSSLib/SSSUtil.h"
#include <iostream>
//#include <Windows.h>
#include "TableUtil3D.h"
#include "../StaticADMMLib/TestConfig.h"

#include <omp.h>

//#define _SHOW_TOPOLOGY

#define _MATLAB_OPT
//#define _RENDER_SOLID

//#define _PRINT_SCREEN

//#ifdef _MATLAB_OPT
//#	pragma comment(lib, "mclmcrrt.lib")
//#endif

using namespace SSSLib;
using namespace std;

#ifndef _NO_GL
OGLCamModel* g_testCam;
OGLSEasyProgram* g_pProgram;
#endif
SSSVolMesh gTetMesh;
PhysImpSolve3D g_PhysImp;

int gWindowHeight = 800;
int gSteps = 0;

_T_FLOAT gVMShowScale = 1.0;
_T_FLOAT gVtxScale = 1.0;

#ifndef _NO_GL
void SetVtxTypeColor(int iVtxID)
{
	switch (g_PhysImp.mIntVtx[iVtxID])
	{
	case PhysImpSolve3D::VTInt:
		glColor3ub(255, 255, 255);
		//assert(gTetMesh.mbIntVtx.size()==0 || gTetMesh.mbIntVtx[iVtxID]);
		if (!gTetMesh.mbIntVtx[iVtxID])
		{
			//cout<<"?";
			glColor3ub(255, 0, 255);
		}
		break;
	case PhysImpSolve3D::VTSurf:
		glColor3ub(0, 0, 255);
		//assert(gTetMesh.mbIntVtx.size()==0 || !gTetMesh.mbIntVtx[iVtxID]);
		if (gTetMesh.mbIntVtx[iVtxID])
			glColor3ub(128, 0, 128);
		break;
	case PhysImpSolve3D::VTEdge:
		glColor3ub(255, 0, 0);
		//assert(gTetMesh.mbIntVtx.size()==0 || !gTetMesh.mbIntVtx[iVtxID]);
		if (gTetMesh.mbIntVtx[iVtxID])
			glColor3ub(128, 0, 128);
		break;
	case PhysImpSolve3D::VTPt:
		glColor3ub(0, 255, 0);
		//assert(gTetMesh.mbIntVtx.size()==0 || !gTetMesh.mbIntVtx[iVtxID]);
		if (gTetMesh.mbIntVtx[iVtxID])
			glColor3ub(128, 0, 128);
		break;
	}
}

void SetOffsetColor(_T_FLOAT iOffset)
{
	_T_FLOAT rescaleValue = SSSLib::clamp(iOffset*gVtxScale*30, 0.0, 0.69)+0.3;
	Vec3uc clr = SSSLib::Value2RGBuc(float(rescaleValue));
	glColor3ubv(clr.val);
}

void SetOffsetColor(int iVtxID)
{
	SetOffsetColor((g_PhysImp.mX0[iVtxID]-g_PhysImp.mXRef[iVtxID]).Length());
}

void TestRender(OGLScene::TStageName, int)
{
/*
#ifndef _MATLAB_OPT
	
	g_PhysImp.mdExtForce.clear();
	g_PhysImp.ComputePhysForce();

	g_PhysImp.XPStep(1e-1, true);
	g_PhysImp.ComputeVMForce(true, PhysImpSolve3D::ContVM);
	//if (gSteps<10)
	//	g_PhysImp.XPStep(1e-1, true);
	//else if (gSteps==10)
	//	g_PhysImp.UpdateVMBound(g_PhysImp.mVMBound, 0, true, true);
	//else
	//{
	//	g_PhysImp.XPStep(0.5, false);
	//}
#endif
	*/
	//g_PhysImp.mbStatic = true;
	//g_PhysImp.mdExtForce.clear();
	//g_PhysImp.ComputePhysForce();
	//g_PhysImp.XPStep(1, true);
	//g_PhysImp.ComputeExtForce();
	//g_PhysImp.XPStep(1e-1, true);
	//g_PhysImp.ComputeVMForce(false);
	//g_PhysImp.UpdateVMBound(g_PhysImp.mVMBound);

	//cout<<g_PhysImp.mX0[4][0]-g_PhysImp.mX0[0][0];

	int height = glutGet(GLUT_WINDOW_HEIGHT);
	int width = glutGet(GLUT_WINDOW_WIDTH)/2;

	g_testCam->SetProjMatrix(Vec4i(height, 0, 0, width));
	g_testCam->SetViewMatrix();
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glColor3f(1.0f, 1.0f, 1.0f);

#ifdef _RENDER_SOLID
#else
	glBegin(GL_LINES);
		for (int i=0; i<(int)gTetMesh.mTets.size(); i++)
		{
			Vec4i tet = gTetMesh.mTets[i];
			for (int v1=0; v1<3; v1++)
			for (int v2=v1+1; v2<4; v2++)
			{
#ifdef _SHOW_TOPOLOGY
				SetVtxTypeColor(tet[v1]);
#else
				SetOffsetColor(tet[v1]);
#endif
				glVertex3dv((g_PhysImp.mX0[tet[v1]]*gVtxScale).val);
#ifdef _SHOW_TOPOLOGY
				SetVtxTypeColor(tet[v2]);
#else
				SetOffsetColor(tet[v2]);
#endif
				glVertex3dv((g_PhysImp.mX0[tet[v2]]*gVtxScale).val);
			}
		}
	glEnd();
#endif
	//if (gTetMesh.mSurfaceMesh.mFace.size()>0)
	//for (int i=0; i<(int)gTetMesh.mSurfaceMesh.mFace.size(); i++)
	//	{
	//		Vec3i tri = gTetMesh.mSurfaceMesh.mFace[i];
	//		for (int v=0; v<3; v++)
	//		{
	//			glVertex3dv((double*)&g_PhysImp.mX0[tri[v]]);
	//			glVertex3dv((double*)&g_PhysImp.mX0[tri[(v+1)%3]]);
	//		}
	//	}
	//else


#ifdef _RENDER_SOLID
	glBegin(GL_QUADS);
	for (int i=0; i<(int)gTetMesh.mSurfaceMesh.mQuad.size(); i++)
	{
		Vec4i quad = gTetMesh.mSurfaceMesh.mQuad[i];
		for (int v=0; v<4; v++)
		{
			int idx = v;
			//if (v==2)
			//	idx = 3;
			//else if (v==3)
			//	idx = 2;
			SetOffsetColor(quad[idx]);
			glVertex3dv((g_PhysImp.mX0[quad[idx]]*gVtxScale).val);
		}

	}
	glEnd();
#else
	glBegin(GL_LINES);
	for (int i=0; i<(int)gTetMesh.mHexs.size(); i++)
		{
			SmallVec<int, 8> hex = gTetMesh.mHexs[i];
			for (int k=0; k<8; k++)
			for (int c=0; c<3; c++)
			if (((k>>c)&1)==0)
			{
				int l = (1<<c)+k;
#ifdef _SHOW_TOPOLOGY
				SetVtxTypeColor(hex[k]);
#else
				SetOffsetColor(hex[k]);
#endif
				glVertex3dv((g_PhysImp.mX0[hex[k]]*gVtxScale).val);
#ifdef _SHOW_TOPOLOGY
				SetVtxTypeColor(hex[l]);
#else
				SetOffsetColor(hex[l]);
#endif
				glVertex3dv((g_PhysImp.mX0[hex[l]]*gVtxScale).val);
			}
		}
	glEnd();
#endif


	g_testCam->SetProjMatrix(Vec4i(height, width, 0, width*2));

#ifdef _RENDER_SOLID
	vector<_T_FLOAT> vmSum(g_PhysImp.mX0.size(), 0);
	vector<_T_FLOAT> vmWeight(g_PhysImp.mX0.size(), 0);
	for (int i=0; i<(int)g_PhysImp.mVMHex.size(); i++)
	{
		SmallVec<_T_FLOAT, 8>& vm = g_PhysImp.mVMHex[i];
		SmallVec<int, 8>& hex = gTetMesh.mHexs[i];
		for (int k=0; k<8; k++)
		{
			_T_FLOAT val = vm[k]/g_PhysImp.mVMBound*gVMShowScale;
			vmSum[hex[k]] += val;
			vmWeight[hex[k]] += 1.0;
		}
	}

	glBegin(GL_QUADS);
	for (int i=0; i<(int)gTetMesh.mSurfaceMesh.mQuad.size(); i++)
	{
		Vec4i quad = gTetMesh.mSurfaceMesh.mQuad[i];
		for (int v=0; v<4; v++)
		{
			int idx = quad[v];
			//if (v==2)
			//	idx = 3;
			//else if (v==3)
			//	idx = 2;
			_T_FLOAT val = vmSum[idx]/vmWeight[idx];
			Vec3uc clr = SSSLib::Value2RGBuc(float(0.3+SSSLib::clamp(val*0.5, 0.0, 0.5)));
			if (val>1.0)
				clr = Vec3uc(255, 0, 0);
			glColor3ubv(clr.val);
			glVertex3dv((g_PhysImp.mX0[idx]*gVtxScale).val);
		}

	}
	glEnd();
#else
	glBegin(GL_LINES);
	//if (gTetMesh.mSurfaceMesh.mFace.size()>0)
	//for (int i=0; i<(int)gTetMesh.mSurfaceMesh.mFace.size(); i++)
	//	{
	//		Vec3i tri = gTetMesh.mSurfaceMesh.mFace[i];
	//		for (int v=0; v<3; v++)
	//		{
	//			glVertex3dv((double*)&g_PhysImp.mP0[tri[v]]);
	//			glVertex3dv((double*)&g_PhysImp.mP0[tri[(v+1)%3]]);
	//		}
	//	}
	//else
		for (int i=0; i<(int)gTetMesh.mTets.size(); i++)
		{
			Vec4i tet = gTetMesh.mTets[i];
			float val = (float)(g_PhysImp.mVM[i]/g_PhysImp.mVMBound*gVMShowScale);
			//float val = 0;
			//float val = 0;
			Vec3uc clr = SSSLib::Value2RGBuc(float(0.2+SSSLib::clamp(val*0.5, 0.0, 0.5)));
			//cout<<val<<"\t";
			if (val>1.0)
				clr = Vec3uc(255, 0, 0);
			glColor3ub(clr[0], clr[1], clr[2]);
			for (int v1=0; v1<3; v1++)
			for (int v2=v1+1; v2<4; v2++)
			{
				glVertex3dv((g_PhysImp.mP0[tet[v1]]*gVtxScale).val);
				glVertex3dv((g_PhysImp.mP0[tet[v2]]*gVtxScale).val);
			}
		}

		Vec3uc clr[8];
		for (int i=0; i<(int)gTetMesh.mHexs.size(); i++)
		{
			SmallVec<int, 8> hex = gTetMesh.mHexs[i];
			for (int k=0; k<8; k++)
			{
				float val = (float)(g_PhysImp.mVMHex[i][k]/g_PhysImp.mVMBound*gVMShowScale);
				//float val = 0;
				clr[k] = SSSLib::Value2RGBuc(float(0.4+SSSLib::clamp(val*0.5, 0.0, 0.5)));
				if (val>1.0)
					clr[k] = Vec3uc(255, 0, 0);
			}
			for (int k=0; k<8; k++)
			for (int c=0; c<3; c++)
			if (((k>>c)&1)==0)
			{
				int l = (1<<c)+k;
				glColor3ubv(clr[k].val);
				glVertex3dv((g_PhysImp.mP0[hex[k]]*gVtxScale).val);
				glColor3ubv(clr[l].val);
				glVertex3dv((g_PhysImp.mP0[hex[l]]*gVtxScale).val);
			}
		}
	glEnd();
#endif

//	cout<<endl;

	glFlush();
	glutSwapBuffers();
	int err = glGetError();
	if (err>0)
		std::cout<<"Drawing Error:"<<err<<std::endl;

#ifdef _PRINT_SCREEN
	if (gSteps%500==0)
	{
		char buffer[1000];
		sprintf_s(buffer, 1000, "screenshot\\%d.png", gSteps/500);
		PrintScreen(width*2, height, buffer);
	}
#endif

	gSteps++;
}

void Keyboard(unsigned char iKey, int x, int y)
{
	switch (iKey)
	{
	case '+':
		g_PhysImp.UpdateVMBound(g_PhysImp.mVMBound*1.2, -1, true, true);
		cout<<"New Von Mises Crit:"<<g_PhysImp.mVMBound<<endl;
		break;
	case '-':
		g_PhysImp.UpdateVMBound(g_PhysImp.mVMBound/1.2, -1, true, true);
		cout<<"New Von Mises Crit:"<<g_PhysImp.mVMBound<<endl;
		break;
	case 'q':
		g_PhysImp.mVMWeight *= 1.5;
		g_PhysImp.UpdateVMBound(g_PhysImp.mVMBound, -1, true, true);
		cout<<"New Von Mises Weight:"<<g_PhysImp.mVMWeight<<endl;
		break;
	case 'w':
		g_PhysImp.mVMWeight /= 1.5;
		g_PhysImp.UpdateVMBound(g_PhysImp.mVMBound, -1, true, true);
		cout<<"New Von Mises Weight:"<<g_PhysImp.mVMWeight<<endl;
		break;

	}
}

void KeyboardUp(unsigned char iKey, int x, int y)
{
	//switch (iKey)
	//{
	//case 'r':
	//	g_PhysImp.Init();
	//	break;
	//}
}

//void BuildTable()
//{
//
//	int reso = 3;
//
//	gFEM.InitParam(1e8, 0.3f);
//
//	gFEM.SetParameters(8*reso, 1*reso, 5*reso, 4*reso, 1*reso, 0, 0, 0.2f/reso);
//	gFEM.BuildTable();
//
//}
#endif

int main(int argc, char** argv)
{
	cout<<"input: [config xml file name] [number of thread (default -1)] [load tmp file or not]\n";

	int numThread = omp_get_max_threads();
        cout<<"Max thread "<<numThread<<endl;
        //cout<<"argc "<<argc<<endl;
	if (argc<=2 || atoi(argv[2])<=0)
		numThread = numThread-1;
	else
		numThread = atoi(argv[2]);
	omp_set_num_threads(numThread);
	cout<<"Setting "<<numThread<<" threads.\n";
#ifdef _OUTPUT_LOG
	ofstream log("log.txt");
	cout.rdbuf(log.rdbuf());
#endif
#ifndef _NO_GL
	OGLFrame::Init(gWindowHeight*2,gWindowHeight);
	//OGLFrame::GetInstance()->SetCommonFunction();
	OGLFrame::GetInstance()->AddRenderExt(TestRender);
	OGLFrame::GetInstance()->AddKeyboard(Keyboard);
	OGLFrame::GetInstance()->AddKeyboardUp(KeyboardUp);
	OGLFrame::EnableIdleRender();
	//OGLFrame::GetInstance()->AddKey0board(
	g_testCam = new OGLCamModel();
	g_testCam->EnableCam(OGLFrame::GetInstance());
#endif
        
	g_PhysImp.SetMaterialParam(1e5, 0.3);

	//BuildTable();

	//gTetMesh.LoadVolMesh(argv[1]);

	vector<Vec2i> edges;
	vector<Vec2i> hexEdges;
	vector<Vec2i> hexExtEdges;
	int reso = 2;

	{
		ofstream logfile("log.txt", ios::app | ios::out);
		logfile<<"begin time: "<<_GET_TICK_COUNT()<<" ms"<<endl;
	}

#if defined(_TABLE_TEST) || defined(_SINGLE_STAND_TEST) || defined(_TWO_STAND_TEST)
	{
		vector<Vec3i> cubes;
#	ifdef _TABLE_TEST
	// table
		int sw = 8;
		int sl = 8;
		int sh = 1*2;
		int ll = 4;
		BuildUtil::BuildTable(sw, sl, sh, ll, 1*2, 4, 4, cubes);
		gTetMesh.BuildCubeMesh(&cubes[0], cubes.size(), Vec3d(-0.5f*sw, -0.5f*sl, -0.5f*(sh+ll)), 1.0f/8.0f, &edges, &hexEdges);
#	elif defined _SINGLE_STAND_TEST
		int sw = 6;
		int sl = 6;
		int sh = 2;
		int ll = 2;
		int lt = 2;
		BuildUtil::BuildSingleStand(sw, sl, sh, ll, lt, cubes);
		gTetMesh.BuildCubeMesh(&cubes[0], cubes.size(), Vec3d(-0.5f*sw, -0.5f*sl, -0.5f*(sh+ll)), 1.0f/8.0f, &edges, &hexEdges);
#	else
		int sw = 6;
		int sl = 2;
		int sh = 2;
		int ll = 2;
		int lt = 2;
		int ld = 2;
		BuildUtil::BuildTwoStand(sw, sl, sh, ll, lt, ld, cubes);
		gTetMesh.BuildCubeMesh(&cubes[0], cubes.size(), Vec3d(-0.5f*sw, -0.5f*(sh+ll), -0.5f*sl), 1.0f/8.0f, &edges, &hexEdges);
#	endif
		gTetMesh.FindIntVtx();
		gTetMesh.BuildSurfaceMesh(true, true);
#	ifdef _TET
		gTetMesh.mHexs.clear();
		gTetMesh.mSurfaceMesh.WriteStl("tmp.stl");
		gTetMesh.mSurfaceMesh.ComputeEdges(1e-5);
#	else
		gTetMesh.ComputeHexEdges(hexEdges);
		gTetMesh.mTets.clear();
		//gTetMesh.BuildSurfaceMesh(false, true);
		gTetMesh.mSurfaceMesh.ComputeQuadEdges(hexExtEdges);
		g_PhysImp.mpHexExtEdges = &hexExtEdges;
#	endif
	}
#elif defined _2x2CUBE_TEST
	{
		vector<Vec3i> cubes;
		for (int x=0; x<reso; x++)
		for (int y=0; y<reso; y++)
		for (int z=0; z<reso; z++)
			cubes.push_back(Vec3i(x, y, z));
		gTetMesh.BuildCubeMesh(&cubes[0], reso*reso*reso, Vec3d(-0.5f*reso, -0.5f*reso, -0.5f*reso), 1.0f/reso, &edges, &hexEdges);
		//gTetMesh.BuildCubeMesh(&cubes[0], reso*reso*reso, Vec3d(0, 0, 0), 1.0f/reso, &edges);
		//gTetMesh.BuildCubeMesh(&cubes[0], 1, Vec3d(-0.5f, -0.5f, -0.5f), 1.0f);
		gTetMesh.FindIntVtx();
#ifdef _TET
		gTetMesh.mHexs.clear();
		gTetMesh.mSurfaceMesh.ComputeEdges(1e-5);
#else
		gTetMesh.mTets.clear();
#endif
	}
	//g_PhysImp.SetMaterialParam(1e5, 0.3);
#elif defined _LOAD_MODEL
#	ifdef _TET
	{
		gTetMesh.LoadVolMesh(argv[1]);
		gTetMesh.BuildSurfaceMesh();
		gTetMesh.mSurfaceMesh.ComputeEdges(0.05f);
		edges = gTetMesh.mSurfaceMesh.mEdges;
	}
#	else
	{
		gTetMesh.LoadVtk(argv[1]);
		gTetMesh.RemoveIsolatedVtx();
		gTetMesh.FindIntVtx();
		gTetMesh.BuildSurfaceMesh(true, true);
		gTetMesh.ComputeHexEdges(hexEdges);
	}
#	endif
#elif defined _LOAD_XML
	{
		g_PhysImp.ParseConfigFile(argv[1], gTetMesh);
		
		gTetMesh.ComputeHexEdges(hexEdges);
	}
#endif

	//{
	//	Vec3d high;
	//	Vec3d low;
	//	gTetMesh.mSurfaceMesh.ComputeBB(low, high);
	//	g_PhysImp.mMaxDim = Max(Max(high[0]-low[0], high[1]-low[1]), high[2]-low[2]);
	//	gVtxScale = 1/g_PhysImp.mMaxDim;
	//	g_PhysImp.mEdgeLengthEpsilon /= gVtxScale;
	//	
	//}
	gVtxScale = 1/g_PhysImp.mMaxDim;

	//gTetMesh.ComputeMass(g_PhysImp.mDensity);


	//gTetMesh.mHexs.clear();
	// hack mass
	//for (int i=0; i<8; i++)
	//if ((((i>>2)&1)+((i>>1)&1)+(i&1))%2==0)
	//	gTetMesh.mMass[i] = 1e4f/8.0f;
	//else
	//	gTetMesh.mMass[i] = 1e4f/8.0f*2;

	// for debug
	cout<<"Mat Size "<<sizeof(g_PhysImp.mE)<<endl;
	//g_PhysImp.mpEdges = &edges;
	g_PhysImp.mpEdges = &gTetMesh.mSurfaceMesh.mEdges;
	g_PhysImp.mpHexEdges = &hexEdges;
	g_PhysImp.Init(&gTetMesh);

	{
		_T_FLOAT minMass = g_PhysImp.mMass[0];
		_T_FLOAT maxMass = g_PhysImp.mMass[0];
		for (int i=0; i<(int)g_PhysImp.mX0.size(); i++)
		{
			minMass = Min(minMass, g_PhysImp.mMass[i]);
			maxMass = Max(maxMass, g_PhysImp.mMass[i]);
		}
		cout<<"Mass Ratio:"<<minMass/maxMass<<endl;
	}

	//g_PhysImp.mE(3, 3) = g_PhysImp.mE(4, 4) = g_PhysImp.mE(5, 5) = 0;
	cout<<"mE\n"<<g_PhysImp.mE<<endl;

	PhysImpSolve3D::spPhysImp = &g_PhysImp;

	if (argc>3 && ( atoi(argv[3])==1 || strcmp(argv[3], "true")==0))
		g_PhysImp.mbLoadState = true;
	else
		g_PhysImp.mbLoadState = false;
	
	//g_PhysImp.mpVolMesh->BuildHexVtxConnect(true);
	//g_PhysImp.mpVolMesh->BuildVtxConnect(false);

	// for debug
	//{
	//	for (int i=0; i<(int)gTetMesh.mVtx.size(); i++)
	//	{
	//		if (g_PhysImp.mIntVtx[i] == PhysImpSolve3D::VTInt
	//			&& !gTetMesh.mbIntVtx[i])
	//		{
	//			cout<<"Error: "<<i<<" VTInt but not MeshInt!\n";
	//		}

	//		if (g_PhysImp.mIntVtx[i] != PhysImpSolve3D::VTInt
	//			&& gTetMesh.mbIntVtx[i])
	//			cout<<"Error: "<<i<<" MeshInt but not VTInt!\n";
	//	}
	//}

	int init_sim = 0;

#ifdef _MATLAB_OPT
	//g_PhysImp.mVMWeight = 0;
	//g_PhysImp.mPhase = -2;
	init_sim = 5;
	
#ifdef _NO_GL
        PhysImpSolve3D::MatlabOptThread(&init_sim);
#else
	tthread::thread tt(PhysImpSolve3D::MatlabOptThread, &init_sim);
#endif
	
	//tthread::thread tt(PhysImpSolve3D::LBFGSOptThread, NULL);

	//PhysImpSolve3D::MatlabOptThread(NULL);
	//g_PhysImp.MatlabSimpleTest();

	// for debug
	//{
	//	std::ofstream out("log.txt");
	//	std::cout.rdbuf(out.rdbuf());
	//	g_PhysImp.LoadState();
	//	g_PhysImp.OptExport();
	//}
#else
	init_sim = -1;
	tthread::thread tt(PhysImpSolve3D::MatlabOptThread, &init_sim);
#endif

	//for (int i=0; i<(int)g_PhysImp.mP0.size(); i++)
	//{
	//	g_PhysImp.mP0[i][0] *= 2.0f;
	//	cout<<g_PhysImp.mP0[i][0]<<'\t'
	//		<<g_PhysImp.mP0[i][1]<<'\t'
	//		<<g_PhysImp.mP0[i][2]<<endl;
	//}

	//gFEM.SetGravityWithMassVec(g_PhysImp.mMass);
#ifndef _NO_GL
	glutMainLoop();
#endif
}

/*Copyright (C) 2016 Yahan Zhou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "TableUtil3D.h"

using namespace std;
using namespace SSSLib;
using namespace BuildUtil;

void BuildUtil::BuildTable(
		int iSW,
		int iSL,
		int iSH,
		int iLL,
		int iLT,
		int iLDL,
		int iLDW,
		std::vector<SSSLib::Vec3i>& oTable)
{
	assert((iSW-iLDW)%2==0);
	// surface
	for (int w=0; w<iSW; w++)
	for (int l=0; l<iSL; l++)
	for (int h=0; h<iSH; h++)
	{
		oTable.push_back(Vec3i(w, h+iLL, l));
	}

	// legs
	for (int leg=0; leg<4; leg++)
	{
		Vec3i offset(0, 0, 0);
		if (leg/2==0)
			offset[0] = (iSW-iLDW)/2-iLT;
		else
			offset[0] = iSW/2+iLDW/2;

		if (leg%2==0)
			offset[2] = (iSL-iLDL)/2-iLT;
		else
			offset[2] = iSL/2+iLDL/2;

		for (int w=0; w<iLT; w++)
		for (int l=0; l<iLT; l++)
		for (int ll=0; ll<iLL; ll++)
			oTable.push_back(offset+Vec3i(w, ll, l));
	}
}

void BuildUtil::BuildSingleStand(
		int iSW,
		int iSL,
		int iSH,
		int iLL,
		int iLT,
		std::vector<SSSLib::Vec3i>& oTable
		)
{
	assert((iSW-iLT)%2==0);
	assert((iSL-iLT)%2==0);

	// surface
	for (int w=0; w<iSW; w++)
	for (int l=0; l<iSL; l++)
	for (int h=0; h<iSH; h++)
	{
		oTable.push_back(Vec3i(w, h+iLL, l));
	}

	// legs
	Vec3i offset((iSW-iLT)/2, 0, (iSL-iLT)/2);
	for (int w=0; w<iLT; w++)
	for (int l=0; l<iLT; l++)
	for (int ll=0; ll<iLL; ll++)
		oTable.push_back(Vec3i(w, ll, l)+offset);
}


void BuildUtil::BuildTwoStand(
		int iSW,
		int iSL,
		int iSH,
		int iLL,
		int iLT,
		int iLD,
		std::vector<SSSLib::Vec3i>& oTable)
{
	assert((iSW-iLT)%2==0);
	assert((iSL-iLT)%2==0);

	// surface
	for (int w=0; w<iSW; w++)
	for (int l=0; l<iSL; l++)
	for (int h=0; h<iSH; h++)
	{
		oTable.push_back(Vec3i(w, h+iLL, l));
	}

	// legs
	for (int i=0; i<2; i++)
	{
		Vec3i offset;
		if (i==0)
			offset = Vec3i(0, 0, 0);
		else
			offset = Vec3i((iSW-iLD), 0, 0);
		for (int w=0; w<iLT; w++)
		for (int l=0; l<iLT; l++)
		for (int ll=0; ll<iLL; ll++)
			oTable.push_back(Vec3i(w, ll, l)+offset);
	}
}

#include "LaplacianDeformation.h"

using namespace trimesh;
using namespace std;

#define _FREE_AFFINE

Eigen::MatrixXd LaplacianDeformation::pinv( Eigen::MatrixXd& imat, double iEpsilon)
{
	using namespace Eigen;
	Eigen::JacobiSVD<MatrixXd> svd(imat, ComputeFullU|ComputeFullV);
	VectorXd lambda = svd.singularValues();
	MatrixXd inverseLambda = MatrixXd::Zero(lambda.size(), lambda.size());
	for (int i=0; i<(int)lambda.size(); i++)
	{
		double val = lambda(i);
		if (fabs(val)>iEpsilon)
			val = 1/val;
		else
			val = 1/iEpsilon;
		inverseLambda(i, i) = val;
	}
	MatrixXd retMat = MatrixXd(svd.matrixV())*inverseLambda*MatrixXd(svd.matrixU().transpose());
	return retMat;
} 

LaplacianDeformation::LaplacianDeformation(void)
	: mesh(NULL)
{

}


LaplacianDeformation::~LaplacianDeformation(void)
{
	control_point.clear();
	control_point_moved.clear();
	if(mesh != NULL)
	{
		delete mesh;
		mesh = NULL;
	}
}

LaplacianDeformation::LaplacianDeformation(string mesh_name, string c_file, string m_file, string out_mesh)
{
	loadMesh(mesh_name);
	loadControlPoint(c_file);
	loadMovedControlPoint(m_file);
	refineMovePoint();
	buildPointMeshConnection();
	calculateLaplacianvector();
	deformation(0);
	//deformationnew();
	outputMesh(out_mesh);
}

void LaplacianDeformation::loadMesh(string mesh_name)
{
	mesh = TriMesh::read(mesh_name);
	mesh->need_normals();
}

void LaplacianDeformation::loadControlPoint(string file_name)
{
	ifstream fin(file_name.c_str());
	control_point.clear();
	float x,y,z;
	while(fin >> x >> y >> z)
	{
		vec3 pos(x,y,z);
		control_point.push_back(pos);
	}
	makeControlPointSymmetry(control_point);
	cout << "load " << control_point.size() << " control points" << endl;
}

void LaplacianDeformation::makeControlPointSymmetry(vector<vec3> &point_set)
{
	int current_size = point_set.size();
	for(size_t i = 0; i < current_size ; i++)
	{
		vec3 pos = point_set[i];
		vec3 pos_s(-pos[0],pos[1],pos[2]);
		point_set.push_back(pos_s);
	}
}

void LaplacianDeformation::loadMovedControlPoint(string file_name)
{
	ifstream fin(file_name.c_str());
	control_point_moved.clear();
	float x,y,z;
	while(fin >> x >> y >> z)
	{
		vec3 pos(x,y,z);
		control_point_moved.push_back(pos);
	}
	makeControlPointSymmetry(control_point_moved);
	cout << "load " << control_point_moved.size() << " new control points" << endl;
}

void  LaplacianDeformation::buildPointMeshConnection()
{	
	is_select.resize(mesh->vertices.size(),0);
	point_list.clear();
	mesh->need_neighbors();
	laplacian_matrix.clear();
	for(size_t i = 0; i < mesh->vertices.size(); i++)
	{
		laplacian_matrix.push_back(mesh->neighbors[i]);
		point_list.push_back(Vec<3, double>(mesh->vertices[i]));
	}
	// build 5 ring neighbor 
	for(size_t i = 0; i < mesh->vertices.size(); i++)
	{
		vector<int> is_visited;
		is_visited.resize(mesh->vertices.size(), 0);
		is_visited[i] = 1;
		vector<int> near_list;
		near_list.push_back(i);
		int begin_ind = 0;
		int end_ind = near_list.size();
		for(int level = 0; level < RINGNEIGHBOR; level++)
		{

			if(level != 0)
			{
				begin_ind = end_ind;
				end_ind = near_list.size();
			}
			for(size_t j = begin_ind; j < end_ind; j++)
			{
				vector<int> list_j =  mesh->neighbors[near_list[j]];

				for(size_t near_j = 0; near_j < list_j.size(); near_j ++)
				{
					int near_id = list_j[near_j];
					if(is_visited[near_id] == 0 )
					{
						is_visited[near_id] = 1;
						near_list.push_back(near_id);
					}
				}
			}
		}
		near_list.erase(near_list.begin());
		laplacian_matrix[i] = near_list;
	}
	vector<NamedPoint> points;
	for (size_t i = 0; i < mesh->vertices.size(); i++)
	{
		points.push_back(NamedPoint(mesh->vertices[i][0], mesh->vertices[i][1], mesh->vertices[i][2], i));
	}
	KDTree3<NamedPoint> stree(points.begin(), points.end());
	matching_control_mesh.clear();
	for (size_t i = 0; i < control_point.size(); i++)
	{
		//point_list.push_back(control_point[i]);
		vector<int> near_vertex;
		near_vertex.clear();
		NamedPoint query(control_point[i][0], control_point[i][1], control_point[i][2]);
		BoundedSortedArray<PKDTree::Neighbor> k_closest_elems(NEIGHBORSIZE);
		stree.kClosestElements<MetricL2>(query, k_closest_elems, -1);  // -1 means there's no limit on the maximum allowed
		for (size_t ind = 0; ind< NEIGHBORSIZE; ind++)
		{
			int near_id = stree.getElements()[k_closest_elems[ind].getIndex()].id;
			//laplacian_matrix[near_id].push_back(i + mesh->vertices.size());
			near_vertex.push_back(near_id);
			//is_select[near_id] = 1;
		}
		//laplacian_matrix.push_back(near_vertex);
		matching_control_mesh.push_back(near_vertex);
	}
	for(size_t i = 0; i < control_point.size(); i++)
	{
		int near_vertex = matching_control_mesh[i][0];
		for(size_t j = 0; j < laplacian_matrix[near_vertex].size(); j++)
		{
			is_select[laplacian_matrix[near_vertex][j]] = 1;
		}
	}
	cout << "total mesh vertex " << mesh->vertices.size() << " total control point size " << control_point.size() << endl;
	float average_near = 0;
	for(size_t i = 0; i < laplacian_matrix.size(); i++)
	{
		average_near += laplacian_matrix[i].size();
	}
	cout << "average neighbor size is " << average_near/laplacian_matrix.size() << endl;
	int total_select = 0;
	for(size_t i = 0; i < is_select.size(); i++)
	{
		total_select += is_select[i];
	}
	cout << "total_select is " << total_select << endl;
}

void LaplacianDeformation::refineMovePoint()
{
	vector<vector<int> > laplacian_matrix_control;
	laplacian_matrix_control.clear();
	vector<vec3> laplacian_vector_control; 
	laplacian_vector_control.clear();
	vector<NamedPoint> points;
	for (size_t i = 0; i < control_point.size(); i++)
	{
		points.push_back(NamedPoint(control_point[i][0], control_point[i][1], control_point[i][2], i));
	}
	KDTree3<NamedPoint> stree(points.begin(), points.end());
	for (size_t i = 0; i < control_point.size(); i++)
	{
		vec3 diff = control_point[i];
		vector<int> near_vertex;
		near_vertex.clear();
		NamedPoint query(control_point[i][0], control_point[i][1], control_point[i][2]);
		BoundedSortedArray<PKDTree::Neighbor> k_closest_elems(CONTROLNEIGHBORSIZE);
		stree.kClosestElements<MetricL2>(query, k_closest_elems, -1);  // -1 means there's no limit on the maximum allowed
		for (size_t ind = 0; ind< CONTROLNEIGHBORSIZE; ind++)
		{
			int near_id = stree.getElements()[k_closest_elems[ind].getIndex()].id;
			if(near_id != i)
			{
			 near_vertex.push_back(near_id);
			 diff = diff - control_point[near_id]/(float)(CONTROLNEIGHBORSIZE - 1);
			}
		}
		laplacian_matrix_control.push_back(near_vertex);
		laplacian_vector_control.push_back(diff);
		//cout << diff << endl;
	}

	std::vector<std::map<int, double> >  LapMat;
	std::vector<std::vector<double> >	  LapB;
	LapB.resize(1);
	for (int iv = 0; iv < control_point.size(); iv++)
	{
		cout << iv << "/" << control_point.size() << "\r";
		vec3 pos_i = control_point[iv];
#ifdef _FREE_AFFINE
		Eigen::MatrixXd DMatrix = Eigen::MatrixXd::Constant(3, 12, 0);
		for (int r=0; r<3; r++)
		for (int c=0; c<3; c++)
		{
			DMatrix(r, r*3+c) = laplacian_vector_control[iv][c];
		}
		Eigen::MatrixXd CMatrix = Eigen::MatrixXd::Constant(3*(1 + laplacian_matrix_control[iv].size()), 12, 0);
		for (int r=0; r<3; r++)
		{
			for (int c=0; c<3; c++)
			{
				CMatrix(r, r*3+c) = pos_i[c];
			}
			CMatrix(r, 9+r) = 1;
		}

		for(int j = 0; j <laplacian_matrix_control[iv].size(); j++)
		{
			int index_j = laplacian_matrix_control[iv][j];
			vec3 pos_j = control_point[index_j];

			for (int r=0; r<3; r++)
			{
				for (int c=0; c<3; c++)
				{
					CMatrix((j+1)*3+r, r*3+c) = pos_j[c];
				}
				CMatrix((j+1)*3+r, 9+r) = 1;
			}
		}
#else
		Eigen::MatrixXd DMatrix = Eigen::MatrixXd::Constant(3, 7, 0);
		DMatrix(0,0) = laplacian_vector_control[iv][0];
		DMatrix(0,2) = laplacian_vector_control[iv][2];
		DMatrix(0,3) = -laplacian_vector_control[iv][1];
		DMatrix(1,0) = laplacian_vector_control[iv][1];
		DMatrix(1,1) = -laplacian_vector_control[iv][2];
		DMatrix(1,3) = laplacian_vector_control[iv][0];
		DMatrix(2,0) = laplacian_vector_control[iv][2];
		DMatrix(2,1) = laplacian_vector_control[iv][1];
		DMatrix(2,2) = -laplacian_vector_control[iv][0];
		DMatrix(2,6) = 0;
		Eigen::MatrixXd CMatrix = Eigen::MatrixXd::Constant(3*(1 + laplacian_matrix_control[iv].size()), 7, 0);
		CMatrix(0,0) = pos_i[0];
		CMatrix(0,2) = pos_i[2];
		CMatrix(0,3) = -pos_i[1];
		CMatrix(0,4) = 1;
		CMatrix(1,0) = pos_i[1];
		CMatrix(1,1) = -pos_i[2];
		CMatrix(1,3) = pos_i[0];
		CMatrix(1,5) = 1;
		CMatrix(2,0) = pos_i[2];
		CMatrix(2,1) = pos_i[1];
		CMatrix(2,2) = -pos_i[0];
		CMatrix(2,6) = 1;
		for(int j = 0; j <laplacian_matrix_control[iv].size(); j++)
		{
			int index_j = laplacian_matrix_control[iv][j];
			vec3 pos_j = control_point[index_j];
			CMatrix(3*(j+1),0) = pos_j[0];
			CMatrix(3*(j+1),2) = pos_j[2];
			CMatrix(3*(j+1),3) = -pos_j[1];
			CMatrix(3*(j+1),4) = 1;
			CMatrix(3*(j+1)+1,0) = pos_j[1];
			CMatrix(3*(j+1)+1,1) = -pos_j[2];
			CMatrix(3*(j+1)+1,3) = pos_j[0];
			CMatrix(3*(j+1)+1,5) = 1;
			CMatrix(3*(j+1)+2,0) = pos_j[2];
			CMatrix(3*(j+1)+2,1) = pos_j[1];
			CMatrix(3*(j+1)+2,2) = -pos_j[0];
			CMatrix(3*(j+1)+2,6) = 1;
		}
#endif
		Eigen::MatrixXd CTranspose(CMatrix.transpose());
		Eigen::MatrixXd CTC = CTranspose*CMatrix;
		//Eigen::MatrixXd CTCI = CTC.inverse();
		Eigen::MatrixXd CTCI = pinv(CTC, 1e-3);
		Eigen::MatrixXd HMatrix = DMatrix*CTCI*CTranspose;
		// H = L - D(C^TC)^-1C^T
		Eigen::MatrixXd LMatrix = Eigen::MatrixXd::Constant(3, 3*(1 + laplacian_matrix_control[iv].size()), 0);
		LMatrix(0,0) =  1;
		LMatrix(1,1) =  1;
		LMatrix(2,2) =  1;
		for(int j = 0; j < laplacian_matrix_control[iv].size(); j++)
		{
			LMatrix(0,(j+1)*3)     = -1.0f/ laplacian_matrix_control[iv].size();
			LMatrix(1,(j+1)*3 + 1) = -1.0f/ laplacian_matrix_control[iv].size();
			LMatrix(2,(j+1)*3 + 2) = -1.0f/ laplacian_matrix_control[iv].size();
		}
		HMatrix = LMatrix - HMatrix;
		// convert to Large A
		// for dx
		LapMat.push_back(map<int, double>());
		(LapMat.back())[iv*3] =       HMatrix(0,0);
		(LapMat.back())[iv*3 + 1] =   HMatrix(0,1);
		(LapMat.back())[iv*3 + 2] =   HMatrix(0,2);
		for(int j = 0; j < laplacian_matrix_control[iv].size(); j++)
		{
			int index_j = laplacian_matrix_control[iv][j];
			(LapMat.back())[index_j*3] =       HMatrix(0,(j+1)*3);
			(LapMat.back())[index_j*3 + 1] =   HMatrix(0,(j+1)*3+1);
			(LapMat.back())[index_j*3 + 2] =   HMatrix(0,(j+1)*3+2);
		}
		LapMat.push_back(map<int, double>());
		(LapMat.back())[iv*3] =      HMatrix(1,0);
		(LapMat.back())[iv*3 + 1] =  HMatrix(1,1);
		(LapMat.back())[iv*3 + 2] =  HMatrix(1,2);
		for(int j = 0; j < laplacian_matrix_control[iv].size(); j++)
		{
			int index_j = laplacian_matrix_control[iv][j];
			(LapMat.back())[index_j*3] =      HMatrix(1,(j+1)*3);
			(LapMat.back())[index_j*3 + 1] =  HMatrix(1,(j+1)*3+1);
			(LapMat.back())[index_j*3 + 2] =  HMatrix(1,(j+1)*3+2);
		}
		LapMat.push_back(map<int, double>());
		(LapMat.back())[iv*3] =      HMatrix(2,0);
		(LapMat.back())[iv*3 + 1] =  HMatrix(2,1);
		(LapMat.back())[iv*3 + 2] =  HMatrix(2,2);
		for(int j = 0; j < laplacian_matrix_control[iv].size(); j++)
		{
			int index_j = laplacian_matrix_control[iv][j];
			(LapMat.back())[index_j*3] =      HMatrix(2,(j+1)*3);
			(LapMat.back())[index_j*3 + 1] =  HMatrix(2,(j+1)*3+1);
			(LapMat.back())[index_j*3 + 2] =  HMatrix(2,(j+1)*3+2);
		}
		LapB[0].push_back(0.0f);
		LapB[0].push_back(0.0f);
		LapB[0].push_back(0.0f);
	}
	cout << endl;
	for (int iv = 0; iv < control_point.size(); iv++)
	{
			LapMat.push_back(map<int, double>());
			(LapMat.back())[iv*3] =  1.0f ;
			LapMat.push_back(map<int, double>());
			(LapMat.back())[iv*3 + 1] =  1.0f ;
			LapMat.push_back(map<int, double>());
			(LapMat.back())[iv*3 + 2] =  1.0f ;
			LapB[0].push_back(control_point_moved[iv][0]);
			LapB[0].push_back(control_point_moved[iv][1]);
			LapB[0].push_back(control_point_moved[iv][2]);
	}
	cout << "begin " << endl;
	int nr_cols = control_point.size();
	LeastSquaresSparseSolver solver;
	solver.Init(LapMat, nr_cols);
	vector<vector<double> > eRes;
	solver.Solve(LapB, eRes);
	cout << "end " << endl;
	for (int iv=0; iv< control_point_moved.size(); iv++)
	{
		vec3 pos_i = control_point_moved[iv];
		pos_i[0] = eRes[0][iv];
		pos_i[1] = eRes[1][iv];
		pos_i[2] = eRes[2][iv];
		control_point_moved[iv] = pos_i;
		//std::cout << pos_i[0] << " "<< pos_i[1] << " " << pos_i[2] << std::endl;
	}

}

void LaplacianDeformation::calculateLaplacianvector()
{
	vertex_laplacian_vector.resize(laplacian_matrix.size());
#pragma omp parallel for
	for(int i = 0;  i < laplacian_matrix.size(); i++)
	{
		Vec<3, double> diff = point_list[i];
		//assert(laplacian_matrix[i].size()>0);
		for(int j = 0; j < laplacian_matrix[i].size(); j++)
		{
			int index_j = laplacian_matrix[i][j];
			Vec<3, double> posj = point_list[index_j];
			diff = diff - posj* (1.0/ laplacian_matrix[i].size());
		}
		vertex_laplacian_vector[i] = diff;
		if (laplacian_matrix[i].size()==0)
			vertex_laplacian_vector[i] = Vec<3, double>(0, 0, 0);
	}
}

void LaplacianDeformation::buildDeformationMatrix(int iDeform,
												  double iCurveEpsilon,
												std::vector<std::map<int, double> >& oLapMat,
												std::vector<std::vector<double> >* oLapB,
												std::set<int>* iIgnoreList)
{
	std::vector<std::map<int, double> >& LapMat = oLapMat;
	if (oLapB)
	{
		oLapB->clear();
		oLapB->resize(1);
	}

	if (iDeform != DEFORM_NON)
	for (int iv = 0; iv < point_list.size(); iv++)
	{
		if (!iIgnoreList || iIgnoreList->count(iv)==0)
		{
			//cout << iv << "/" << point_list.size() << "\r";
			Vec<3, double> pos_i = point_list[iv];
			Eigen::MatrixXd DMatrix;
			Eigen::MatrixXd CMatrix;
			if (iDeform==DEFORM_AFFINE)
			{
				DMatrix = Eigen::MatrixXd::Constant(3, 12, 0);
				for (int r=0; r<3; r++)
				for (int c=0; c<3; c++)
				{
					DMatrix(r, r*3+c) = vertex_laplacian_vector[iv][c];
				}
				CMatrix = Eigen::MatrixXd::Constant(3*(1 + mTransformNeighbourVtx[iv].size()), 12, 0);
				for (int r=0; r<3; r++)
				{
					for (int c=0; c<3; c++)
					{
						CMatrix(r, r*3+c) = pos_i[c];
					}
					CMatrix(r, 9+r) = 1;
				}

				for(int j = 0; j <mTransformNeighbourVtx[iv].size(); j++)
				{
					int index_j = mTransformNeighbourVtx[iv][j];
					Vec<3, double> pos_j = point_list[index_j];

					for (int r=0; r<3; r++)
					{
						for (int c=0; c<3; c++)
						{
							CMatrix((j+1)*3+r, r*3+c) = pos_j[c];
						}
						CMatrix((j+1)*3+r, 9+r) = 1;
					}
				}
			}
			else if (iDeform==DEFFORM_ROTATE)
			{
				// the coefficient before B_i in Yanjie's document
				DMatrix = Eigen::MatrixXd::Constant(3, 7, 0);
				DMatrix(0,0) = vertex_laplacian_vector[iv][0];
				DMatrix(0,2) = vertex_laplacian_vector[iv][2];
				DMatrix(0,3) = -vertex_laplacian_vector[iv][1];
				DMatrix(1,0) = vertex_laplacian_vector[iv][1];
				DMatrix(1,1) = -vertex_laplacian_vector[iv][2];
				DMatrix(1,3) = vertex_laplacian_vector[iv][0];
				DMatrix(2,0) = vertex_laplacian_vector[iv][2];
				DMatrix(2,1) = vertex_laplacian_vector[iv][1];
				DMatrix(2,2) = -vertex_laplacian_vector[iv][0];
				DMatrix(2,6) = 0;
				// the A matrix in the document
				CMatrix = Eigen::MatrixXd::Constant(3*(1 + mTransformNeighbourVtx[iv].size()), 7, 0);
				CMatrix(0,0) = pos_i[0];
				CMatrix(0,2) = pos_i[2];
				CMatrix(0,3) = -pos_i[1];
				CMatrix(0,4) = 1;
				CMatrix(1,0) = pos_i[1];
				CMatrix(1,1) = -pos_i[2];
				CMatrix(1,3) = pos_i[0];
				CMatrix(1,5) = 1;
				CMatrix(2,0) = pos_i[2];
				CMatrix(2,1) = pos_i[1];
				CMatrix(2,2) = -pos_i[0];
				CMatrix(2,6) = 1;
				for(int j = 0; j <mTransformNeighbourVtx[iv].size(); j++)
				{
					int index_j = mTransformNeighbourVtx[iv][j];
					Vec<3, double> pos_j = point_list[index_j];
					CMatrix(3*(j+1),0) = pos_j[0];
					CMatrix(3*(j+1),2) = pos_j[2];
					CMatrix(3*(j+1),3) = -pos_j[1];
					CMatrix(3*(j+1),4) = 1;
					CMatrix(3*(j+1)+1,0) = pos_j[1];
					CMatrix(3*(j+1)+1,1) = -pos_j[2];
					CMatrix(3*(j+1)+1,3) = pos_j[0];
					CMatrix(3*(j+1)+1,5) = 1;
					CMatrix(3*(j+1)+2,0) = pos_j[2];
					CMatrix(3*(j+1)+2,1) = pos_j[1];
					CMatrix(3*(j+1)+2,2) = -pos_j[0];
					CMatrix(3*(j+1)+2,6) = 1;
				}
			}
			else if (iDeform==DEFORM_SCALE)
			{
				DMatrix = Eigen::MatrixXd::Constant(3, 6, 0);
				for (int r=0; r<3; r++)
					DMatrix(r, r) = vertex_laplacian_vector[iv][r];
				CMatrix = Eigen::MatrixXd::Constant(3*(1 + mTransformNeighbourVtx[iv].size()), 6, 0);
				for (int r=0; r<3; r++)
				{
					CMatrix(r, r) = pos_i[r];
					CMatrix(r, 3+r) = 1;
				}

				for(int j = 0; j <mTransformNeighbourVtx[iv].size(); j++)
				{
					int index_j = mTransformNeighbourVtx[iv][j];
					Vec<3, double> pos_j = point_list[index_j];

					for (int r=0; r<3; r++)
					{
						CMatrix((j+1)*3+r, r) = pos_j[r];
						CMatrix((j+1)*3+r, 3+r) = 1;
					}
				}
			}

			Eigen::MatrixXd CTranspose(CMatrix.transpose());
			Eigen::MatrixXd CTC = CTranspose*CMatrix;
			//Eigen::MatrixXd CTCI = CTC.inverse();
			Eigen::MatrixXd CTCI = pinv(CTC, 1e-8);
			Eigen::MatrixXd HMatrix = DMatrix*CTCI*CTranspose;
			// H = L - D(C^TC)^-1C^T
			Eigen::MatrixXd LMatrix = Eigen::MatrixXd::Constant(3, 3*(1 + mTransformNeighbourVtx[iv].size()), 0);
			LMatrix(0,0) =  1;
			LMatrix(1,1) =  1;
			LMatrix(2,2) =  1;
			for(int j = 0; j <laplacian_matrix[iv].size(); j++)
			{
				assert(laplacian_matrix[iv][j]==mTransformNeighbourVtx[iv][j]);
				LMatrix(0,(j+1)*3)     = -1.0/ laplacian_matrix[iv].size();
				LMatrix(1,(j+1)*3 + 1) = -1.0/ laplacian_matrix[iv].size();
				LMatrix(2,(j+1)*3 + 2) = -1.0/ laplacian_matrix[iv].size();
			}
			// the -C_i matrix in Yanjie's document
			HMatrix = LMatrix - HMatrix;

			 //for debug
			//{
			//	ofstream debugFileA;
			//	int interestPts[4] = {0, 26, 78, 90};
			//	//int interestPts[4] = {0, 15, 35, 100};
			//	//int interestPts[4] = {4, 28, 49, 261};
			//	for (int i=0; i<4; i++)
			//	if (iv==interestPts[i])
			//	{
			//		char nameBuffer[1000];
			//		sprintf_s<1000>(nameBuffer, "debugCMatA%d.txt", i);
			//		debugFileA.open(nameBuffer);
			//	}
			//	Eigen::MatrixXd tmpMatrix = DMatrix*CTCI*CTranspose;
			//	//debugFileA<<tmpMatrix;
			//	if (debugFileA.is_open())
			//		debugFileA<<"C:\n "<<CMatrix
			//				<<"\nCTC:\n"<<CTC
			//				<<"\nCTCI:\n"<<CTCI
			//				<<"\nDMat:\n"<<DMatrix
			//				<<"\nAll:\n"<<tmpMatrix
			//				<<"\nHMatrix:\n"<<HMatrix;
			//}
		
			if (iCurveEpsilon>0)
				HMatrix = HMatrix/(len2(vertex_laplacian_vector[iv])+iCurveEpsilon);
			if (mLapWeight.size()>0)
				HMatrix = HMatrix*mLapWeight[iv];
		
			// convert to Large A
			// for dx
			for (int c=0; c<3; c++)
			{
				LapMat.push_back(map<int, double>());
				(LapMat.back())[iv*3] =       HMatrix(c,0);
				(LapMat.back())[iv*3 + 1] =   HMatrix(c,1);
				(LapMat.back())[iv*3 + 2] =   HMatrix(c,2);
				for(int j = 0; j < mTransformNeighbourVtx[iv].size(); j++)
				{
					int index_j = mTransformNeighbourVtx[iv][j];
					(LapMat.back())[index_j*3] =       HMatrix(c,(j+1)*3);
					(LapMat.back())[index_j*3 + 1] =   HMatrix(c,(j+1)*3+1);
					(LapMat.back())[index_j*3 + 2] =   HMatrix(c,(j+1)*3+2);
				}
			}
			//LapMat.push_back(map<int, double>());
			//(LapMat.back())[iv*3] =      HMatrix(1,0);
			//(LapMat.back())[iv*3 + 1] =  HMatrix(1,1);
			//(LapMat.back())[iv*3 + 2] =  HMatrix(1,2);
			//for(int j = 0; j < laplacian_matrix[iv].size(); j++)
			//{
			//	int index_j = laplacian_matrix[iv][j];
			//	(LapMat.back())[index_j*3] =      HMatrix(1,(j+1)*3);
			//	(LapMat.back())[index_j*3 + 1] =  HMatrix(1,(j+1)*3+1);
			//	(LapMat.back())[index_j*3 + 2] =  HMatrix(1,(j+1)*3+2);
			//}
			//LapMat.push_back(map<int, double>());
			//(LapMat.back())[iv*3] =      HMatrix(2,0);
			//(LapMat.back())[iv*3 + 1] =  HMatrix(2,1);
			//(LapMat.back())[iv*3 + 2] =  HMatrix(2,2);
			//for(int j = 0; j < laplacian_matrix[iv].size(); j++)
			//{
			//	int index_j = laplacian_matrix[iv][j];
			//	(LapMat.back())[index_j*3] =      HMatrix(2,(j+1)*3);
			//	(LapMat.back())[index_j*3 + 1] =  HMatrix(2,(j+1)*3+1);
			//	(LapMat.back())[index_j*3 + 2] =  HMatrix(2,(j+1)*3+2);
			//}
			if (oLapB)
			{
				(*oLapB)[0].push_back(0.0f);
				(*oLapB)[0].push_back(0.0f);
				(*oLapB)[0].push_back(0.0f);
			}
		}
		else
		{
			//cout<<"Ignoring node "<<iv<<endl;
			for (int c=0; c<3; c++)
			{
				LapMat.push_back(map<int, double>());
			}
			if (oLapB)
			{
				(*oLapB)[0].push_back(0.0f);
				(*oLapB)[0].push_back(0.0f);
				(*oLapB)[0].push_back(0.0f);
			}
		}
	}
	else
	{
		for (int iv = 0; iv < point_list.size(); iv++)
		{
			for (int c=0; c<3; c++)
			{
				LapMat.push_back(map<int, double>());
				(LapMat.back())[iv*3+c] = 1.0;
				for(int j = 0; j <mTransformNeighbourVtx[iv].size(); j++)
				{
					int index_j = mTransformNeighbourVtx[iv][j];
					(LapMat.back())[index_j*3+c] = -1.0/mTransformNeighbourVtx[iv].size();
				}
				(*oLapB)[0].push_back(vertex_laplacian_vector[iv][c]);
			}

		}
	}

}

void LaplacianDeformation::deformation(int iDeformType)
{
	std::vector<std::map<int, double> >  LapMat;
	std::vector<std::vector<double> >	  LapB;
	buildDeformationMatrix(iDeformType, -1, LapMat, &LapB);
	cout << endl;
	// control points
	for (int iv = 0; iv < control_point.size(); iv++)
	{
			LapMat.push_back(map<int, double>());
			for(size_t j = 0; j < 1; j++)
			{
				(LapMat.back())[matching_control_mesh[iv][j]*3] =  1.0f ;
			}
			LapMat.push_back(map<int, double>());
			for(size_t j = 0; j < 1; j++)
			{
				(LapMat.back())[matching_control_mesh[iv][j]*3 + 1] =  1.0f ;
			}
			LapMat.push_back(map<int, double>());
			for(size_t j = 0; j < 1; j++)
			{
				(LapMat.back())[matching_control_mesh[iv][j]*3 + 2] =  1.0f;
			}
			LapB[0].push_back(control_point_moved[iv][0]);
			LapB[0].push_back(control_point_moved[iv][1]);
			LapB[0].push_back(control_point_moved[iv][2]);
	}
	// fixed vertices
	for(size_t i = 0; i < mesh->vertices.size(); i++)
	{
		if(is_select[i] == 0)
		{
			LapMat.push_back(map<int, double>());
			(LapMat.back())[i*3] =  1.0f * LAPWEIGHT;
			LapMat.push_back(map<int, double>());
			(LapMat.back())[i*3 + 1] =  1.0f * LAPWEIGHT;
			LapMat.push_back(map<int, double>());
			(LapMat.back())[i*3 + 2] =  1.0f*LAPWEIGHT;
			LapB[0].push_back(point_list[i][0]*LAPWEIGHT);
			LapB[0].push_back(point_list[i][1]*LAPWEIGHT);
			LapB[0].push_back(point_list[i][2]*LAPWEIGHT);
		}
	}
	cout << "begin " << endl;
	int nr_cols = 3* point_list.size();
	LeastSquaresSparseSolver solver;
	solver.Init(LapMat, nr_cols);
	vector<vector<double> > eRes;
	solver.Solve(LapB, eRes);
	cout << "end " << endl;
	for (int iv=0; iv< mesh->vertices.size(); iv++)
	{
		vec3 pos_i = mesh->vertices[iv];
		pos_i[0] = eRes[0][iv*3];
		pos_i[1] = eRes[0][iv*3 + 1];
		pos_i[2] = eRes[0][iv*3 + 2];
		mesh->vertices[iv] = pos_i;
	}
}

void LaplacianDeformation::deformationnew()
{
	std::vector<std::map<int, double> >  LapMat;
	std::vector<std::vector<double> >	  LapB;
	LapB.resize(3);
	for (int iv=0; iv< laplacian_matrix.size(); iv++)
	{
		//std:: cout << "finish  "<< iv << "/" <<m_nVertices<<"\r";
		Vec<3, double> pos_i = point_list[iv];
		LapMat.push_back(map<int, double>());
		(LapMat.back())[iv] = 1.0f;
		for(int j = 0; j < laplacian_matrix[iv].size(); j++)
		{
			int index_j = laplacian_matrix[iv][j];
			(LapMat.back())[index_j] = -1.0f/laplacian_matrix[iv].size();
		}
		LapB[0].push_back(vertex_laplacian_vector[iv][0]);
		LapB[1].push_back(vertex_laplacian_vector[iv][1]);
		LapB[2].push_back(vertex_laplacian_vector[iv][2]);
	}

	// v - v '
	for (int iv = 0; iv < control_point.size(); iv++)
	{
		if(iv < 172 || iv > 455)
		{
			LapMat.push_back(map<int, double>());
			for(size_t j = 0; j < 1; j++)
			{
				(LapMat.back())[matching_control_mesh[iv][j]] =  1.0f ;
				LapB[0].push_back(control_point_moved[iv][0]);
				LapB[1].push_back(control_point_moved[iv][1]);
				LapB[2].push_back(control_point_moved[iv][2]);
			}			
		}
	}

	for(size_t i = 0; i < mesh->vertices.size(); i++)
	{
		if(is_select[i] == 0)
		{
			LapMat.push_back(map<int, double>());
			(LapMat.back())[i] =  1.0f * LAPWEIGHT;
			LapB[0].push_back(point_list[i][0]*LAPWEIGHT);
			LapB[1].push_back(point_list[i][1]*LAPWEIGHT);
			LapB[2].push_back(point_list[i][2]*LAPWEIGHT);
		}
	}
	cout << "begin " << endl;
	int nr_cols = mesh->vertices.size();
	LeastSquaresSparseSolver solver;
	solver.Init(LapMat, nr_cols);
	vector<vector<double> > eRes;
	solver.Solve(LapB, eRes);
	cout << "end " << endl;
	for (int iv=0; iv< mesh->vertices.size(); iv++)
	{
		vec3 pos_i = mesh->vertices[iv];
		pos_i[0] = eRes[0][iv];
		pos_i[1] = eRes[1][iv];
		pos_i[2] = eRes[2][iv];
		mesh->vertices[iv] = pos_i;
		//std::cout << pos_i[0] << " "<< pos_i[1] << " " << pos_i[2] << std::endl;
	}
}

void LaplacianDeformation::outputMesh(string mesh_name)
{
	mesh->write(mesh_name);
}

void LaplacianDeformation::visualResults(string ply_name)
{
	ofstream fout(ply_name.c_str());
	fout << "ply" << endl;
	fout << "format ascii 1.0" << endl;
	fout << "element vertex " << mesh->vertices.size() << endl;
	fout << "property float32 x" << endl;
	fout << "property float32 y" << endl;
	fout << "property float32 z" << endl;
	fout << "property float32 nx" << endl;
	fout << "property float32 ny" << endl;
	fout << "property float32 nz" << endl;
	fout << "property uchar red" << endl;
	fout << "property uchar green" << endl;
	fout << "property uchar blue" << endl;
	fout << "element face 0" << endl;
	fout << "property list uint8 int32 vertex_index" << endl;
	fout << "end_header" << endl;
	for (int iv=0; iv< mesh->vertices.size(); iv++)
	{
		ivec3 color(255,0,0);
		if(is_select[iv] == 1)
		{
			color[1] = 255;
		}
		//color = template_sample_color[i];
		fout << mesh->vertices[iv][0] << " " << mesh->vertices[iv][1] << " " << mesh->vertices[iv][2] << " ";
		fout << mesh->normals[iv][0] << " " << mesh->normals[iv][1] << " " << mesh->normals[iv][2] << " ";
		fout << color[0] << " " << color[1] << " " << color[2] << endl;
	}
}
#pragma once
#include<iostream>
#include<fstream>
#include <string>
#include<sstream>
#include<vector>
#include<ctime>
#include "trimesh2/include/TriMesh.h"
#include "trimesh2/include/TriMesh_algo.h"
#include "namepoint.h"
#include "sparse_solver_eigen.h"
#include <Eigen/Dense>
#include <set>
#define NEIGHBORSIZE 60
#define LAPWEIGHT 0.05
#define CONTROLNEIGHBORSIZE 20
#define RINGNEIGHBOR 1
class LaplacianDeformation
{
public:
	LaplacianDeformation(void);
	~LaplacianDeformation(void);
	LaplacianDeformation(string mesh_name, string c_file, string m_file, string out_mesh);
	static Eigen::MatrixXd pinv( Eigen::MatrixXd& imat, double iEpsilon);
//private:
	trimesh::TriMesh *mesh; // orginal mesh
	std::vector<trimesh::Vec<3, double> > point_list;
	std::vector<std::vector<int> > laplacian_matrix;
	std::vector<std::vector<int> > mTransformNeighbourVtx;
	std::vector<std::vector<int> > matching_control_mesh;
	std::vector<trimesh::Vec<3, double> > vertex_laplacian_vector;
	std::vector<trimesh::vec3>  control_point;
	std::vector<trimesh::vec3>  control_point_moved;
	std::vector<int> is_select;
	std::vector<double> mLapWeight;

	enum 
	{DEFORM_AFFINE, DEFFORM_ROTATE, DEFORM_SCALE, DEFORM_NON};

	void loadMesh(string mesh_name);
	void loadControlPoint(string file_name);
	void loadMovedControlPoint(string file_name);
	void buildPointMeshConnection();
	void calculateLaplacianvector();
	void buildDeformationMatrix(int iDeformType,
		double iCurveEpsilon,
		std::vector<std::map<int, double> >& oLapMat,
		std::vector<std::vector<double> >* oLapB,
		std::set<int>* iIgnoreList = NULL);
	void deformation(int iDeformType);
	void deformationnew();
	void outputMesh(string mesh_name);
	void visualResults(string ply_name);
	void makeControlPointSymmetry(std::vector<trimesh::vec3> &point_set);
	void refineMovePoint();
};


//============================================================================
//
// This file is part of the 'Modeling with High Level Attribute' project.
//
// This software is covered by the following BSD license, except for portions
// derived from other works which are covered by their respective licenses.
// For full licensing information including reproduction of these external
// licenses, see the file LICENSE.txt provided in the documentation.
//
// Copyright (c) 2013, UMass-Amherst
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// * Redistributions of source code must retain the above copyright notice,
// this list of conditions and the following disclaimer.
//
// * Redistributions in binary form must reproduce the above copyright notice,
// this list of conditions and the following disclaimer in the documentation
// and/or other materials provided with the distribution.
//
// * Neither the name of the copyright holders nor the names of contributors
// to this software may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//
//============================================================================

//#include "expmap\VFTriangleMesh.h"
//#include "expmap\ExpMapGenerator.h"
//#include "..\ExpMap\expmap\IMeshBVTree.h"
//#include "..\ExpMap\Texture.h"

#include "helper.h"
#include "Mesh.h"
#include "myXForm.h"
#include "ExpMapInterface.h"
#include <iostream>
#include <omp.h>

float gPRadius = 0.02;
using namespace std;

int main(int argc, char *argv[]) {
	if (argc>3)
	{
		sscanf(argv[3], "%f", &gPRadius);
	} 
	cout<<"Poisson Radius "<<gPRadius<<endl;

	string inputFileNameStr = argv[1];
	string outputFileNameStr = argv[2];
	const char* inputFileName = inputFileNameStr.c_str();

	{
		using namespace ExpMapExp;
		vector<Point> pts;
		LoadAndAppendSamples(inputFileNameStr.c_str(),
			gPRadius,
			SSSLib::Vec3f(0, 0, 0),
			1.0f,
			/*SSSLib::Vec3f(m.bsphereOnLoad.center[0],
						m.bsphereOnLoad.center[1],
						m.bsphereOnLoad.center[2]),
			m.bsphereOnLoad.r,*/
			pts);

		WriteSamplesObj(outputFileNameStr.c_str(), pts);

		// sizing
		Mesh sizeMesh(inputFileNameStr.c_str());
		vector<double> sizing(pts.size());
		for (int i=0; i<(int)sizing.size(); i++)
			sizing[i] = sizeMesh.CheckFeatureSize(
				point(pts[i].mPst),
				vec(pts[i].mNormal));

		if (argc>4)
		{
			int num = (int)sizing.size();
			ofstream tmpFile("tmp.txt");
			tmpFile<<num<<endl;
			double sumSize = 0;
			int sizeCount = 0;
			for (int i=0; i<(int)sizing.size(); i++)
			if (sizing[i]>0)
			{
				sumSize += sizing[i];
				sizeCount++;
			}
			for (int i=0; i<(int)sizing.size(); i++)
			{
				if (sizing[i]<=0)
					sizing[i] = sumSize/sizeCount;
				tmpFile<<sizing[i]<<endl;
			}

			ofstream sizeOutFile(argv[4], ios_base::binary);
			sizeOutFile.write((char*)&num, sizeof(num));
			sizeOutFile.write((char*)&sizing[0], sizeof(double)*num);


		}
	}
}
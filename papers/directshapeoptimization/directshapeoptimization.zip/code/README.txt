This directory contains our code along with other external libraries. Our code is under GPL license (see LICENSE.txt). 
Other libraries are covered by their own licenses (see beginning of every source file for license information). 

If you use this code or parts of it, please cite:

Direct shape optimization for strengthening 3D printable objects
Yahan Zhou, Evangelos Kalogerakis, Rui Wang, Ian R. Grosse
Computer Graphics Forum, Volume 35 (2016), Number 7

-----

To compile the code, you need the boost C++ library (http://www.boost.org/). You may use compile.sh to compile the code. To run experiments, use the following command:

./impintsolver3d *.xml -1 0

where *.xml is the config file name (see folder experiments in our supplementary material)
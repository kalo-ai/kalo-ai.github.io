#include "..\SSSLib\SSSLibOGL\SSSMesh.h"

using namespace SSSLib;

int main(int argc, char* argv[])
{
	SSSMesh mesh0;
	SSSMesh mesh1;
	mesh0.LoadObj(argv[1]);
	mesh1.LoadObj(argv[2]);
	assert(mesh0.mVtx.size()==mesh1.mVtx.size());

	SSSMesh outMesh;
	outMesh.mVtx = mesh0.mVtx;
	outMesh.mFace = mesh0.mFace;

	int totalNum = 360;

	for (int i=0; i<totalNum+1; i++)
	{
		float w0 = i/(float)totalNum;
		float w1 = 1-w0;

		for (int v=0; v<(int)outMesh.mVtx.size(); v++)
		{
			outMesh.mVtx[v] = w1*mesh0.mVtx[v]+w0*mesh1.mVtx[v];
		}

		char outBuffer[1000];
		sprintf_s<1000>(outBuffer, "%s\\%d.obj", argv[3], i);
		outMesh.WriteObj(outBuffer);
	}
}
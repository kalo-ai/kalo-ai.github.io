cd ImpIntSolver3D/ImpIntSolver3D/
make -B -f nbproject/Makefile-Release_no_GL.mk QMAKE= SUBPROJECTS= .build-conf
cp dist/Release_no_GL/GNU-Linux-x86/impintsolver3d ../../
cd ..
cd ..


/*
 * MATLAB Compiler: 4.13 (R2010a)
 * Date: Thu Jun 19 15:28:54 2014
 * Arguments: "-B" "macro_default" "-W" "lib:FOptLib" "-T" "link:lib"
 * "ComputeF.m" "XPFVal.m" "XPFValVecInput.m" "OptimizeXPF.m" "ComputeStress.m"
 * "ComputeVM.m" "DecodeInput.m" "VMVecInput.m" 
 */

#include <stdio.h>
#define EXPORTING_FOptLib 1
#include "FOptLib.h"
#ifdef __cplusplus
extern "C" {
#endif

extern mclComponentData __MCC_FOptLib_component_data;

#ifdef __cplusplus
}
#endif


static HMCRINSTANCE _mcr_inst = NULL;


#if defined( _MSC_VER) || defined(__BORLANDC__) || defined(__WATCOMC__) || defined(__LCC__)
#ifdef __LCC__
#undef EXTERN_C
#endif
#include <windows.h>

static char path_to_dll[_MAX_PATH];

BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, void *pv)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
        if (GetModuleFileName(hInstance, path_to_dll, _MAX_PATH) == 0)
            return FALSE;
    }
    else if (dwReason == DLL_PROCESS_DETACH)
    {
    }
    return TRUE;
}
#endif
#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultPrintHandler(const char *s)
{
  return mclWrite(1 /* stdout */, s, sizeof(char)*strlen(s));
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultErrorHandler(const char *s)
{
  int written = 0;
  size_t len = 0;
  len = strlen(s);
  written = mclWrite(2 /* stderr */, s, sizeof(char)*len);
  if (len > 0 && s[ len-1 ] != '\n')
    written += mclWrite(2 /* stderr */, "\n", sizeof(char));
  return written;
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

/* This symbol is defined in shared libraries. Define it here
 * (to nothing) in case this isn't a shared library. 
 */
#ifndef LIB_FOptLib_C_API
#define LIB_FOptLib_C_API /* No special import/export declaration */
#endif

LIB_FOptLib_C_API 
bool MW_CALL_CONV FOptLibInitializeWithHandlers(
    mclOutputHandlerFcn error_handler,
    mclOutputHandlerFcn print_handler)
{
    int bResult = 0;
  if (_mcr_inst != NULL)
    return true;
  if (!mclmcrInitialize())
    return false;
  if (!GetModuleFileName(GetModuleHandle("FOptLib"), path_to_dll, _MAX_PATH))
    return false;
    {
        mclCtfStream ctfStream = 
            mclGetEmbeddedCtfStream(path_to_dll, 
                                    1853363);
        if (ctfStream) {
            bResult = mclInitializeComponentInstanceEmbedded(   &_mcr_inst,
                                                                
                                                     &__MCC_FOptLib_component_data,
                                                                true, 
                                                                NoObjectType, 
                                                                LibTarget,
                                                                error_handler, 
                                                                print_handler,
                                                                ctfStream, 
                                                                1853363);
            mclDestroyStream(ctfStream);
        } else {
            bResult = 0;
        }
    }  
    if (!bResult)
    return false;
  return true;
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV FOptLibInitialize(void)
{
  return FOptLibInitializeWithHandlers(mclDefaultErrorHandler, mclDefaultPrintHandler);
}

LIB_FOptLib_C_API 
void MW_CALL_CONV FOptLibTerminate(void)
{
  if (_mcr_inst != NULL)
    mclTerminateInstance(&_mcr_inst);
}

LIB_FOptLib_C_API 
long MW_CALL_CONV FOptLibGetMcrID() 
{
  return mclGetID(_mcr_inst);
}

LIB_FOptLib_C_API 
void MW_CALL_CONV FOptLibPrintStackTrace(void) 
{
  char** stackTrace;
  int stackDepth = mclGetStackTrace(_mcr_inst, &stackTrace);
  int i;
  for(i=0; i<stackDepth; i++)
  {
    mclWrite(2 /* stderr */, stackTrace[i], sizeof(char)*strlen(stackTrace[i]));
    mclWrite(2 /* stderr */, "\n", sizeof(char)*strlen("\n"));
  }
  mclFreeStackTrace(&stackTrace, stackDepth);
}


LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxComputeF(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "ComputeF", nlhs, plhs, nrhs, prhs);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxXPFVal(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "XPFVal", nlhs, plhs, nrhs, prhs);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxXPFValVecInput(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "XPFValVecInput", nlhs, plhs, nrhs, prhs);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxOptimizeXPF(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "OptimizeXPF", nlhs, plhs, nrhs, prhs);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxComputeStress(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "ComputeStress", nlhs, plhs, nrhs, prhs);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxComputeVM(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "ComputeVM", nlhs, plhs, nrhs, prhs);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxDecodeInput(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "DecodeInput", nlhs, plhs, nrhs, prhs);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxVMVecInput(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "VMVecInput", nlhs, plhs, nrhs, prhs);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlfComputeF(int nargout, mxArray** f, mxArray* x, mxArray* p, mxArray* 
                              thick, mxArray* d)
{
  return mclMlfFeval(_mcr_inst, "ComputeF", nargout, 1, 4, f, x, p, thick, d);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlfXPFVal(int nargout, mxArray** val, mxArray* x, mxArray* p, mxArray* 
                            thick, mxArray* d, mxArray* x0, mxArray* p0, mxArray* f0, 
                            mxArray* rhox, mxArray* rhop, mxArray* rhof)
{
  return mclMlfFeval(_mcr_inst, "XPFVal", nargout, 1, 10, val, x, p, thick, d, x0, p0, f0, rhox, rhop, rhof);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlfXPFValVecInput(int nargout, mxArray** val, mxArray* vec, mxArray* 
                                    thick, mxArray* d, mxArray* x0, mxArray* p0, mxArray* 
                                    f0, mxArray* x_map, mxArray* p_map, mxArray* xnum, 
                                    mxArray* pnum, mxArray* rhox, mxArray* rhop, mxArray* 
                                    rhof)
{
  return mclMlfFeval(_mcr_inst, "XPFValVecInput", nargout, 1, 13, val, vec, thick, d, x0, p0, f0, x_map, p_map, xnum, pnum, rhox, rhop, rhof);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlfOptimizeXPF(int nargout, mxArray** x, mxArray** p, mxArray** f, 
                                 mxArray** val, mxArray* x_in1, mxArray* p_in1, mxArray* 
                                 thick, mxArray* d, mxArray* x0, mxArray* p0, mxArray* 
                                 f0, mxArray* x_fix, mxArray* p_fix, mxArray* rhox, 
                                 mxArray* rhop, mxArray* rhof, mxArray* stepTol, mxArray* 
                                 valTol, mxArray* maxVM)
{
  return mclMlfFeval(_mcr_inst, "OptimizeXPF", nargout, 4, 15, x, p, f, val, x_in1, p_in1, thick, d, x0, p0, f0, x_fix, p_fix, rhox, rhop, rhof, stepTol, valTol, maxVM);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlfComputeStress(int nargout, mxArray** stress, mxArray* x, mxArray* p, 
                                   mxArray* d)
{
  return mclMlfFeval(_mcr_inst, "ComputeStress", nargout, 1, 3, stress, x, p, d);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlfComputeVM(int nargout, mxArray** vm, mxArray* stress)
{
  return mclMlfFeval(_mcr_inst, "ComputeVM", nargout, 1, 1, vm, stress);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlfDecodeInput(int nargout, mxArray** x, mxArray** p, mxArray* vec, 
                                 mxArray* x0, mxArray* p0, mxArray* x_map, mxArray* 
                                 p_map, mxArray* xnum, mxArray* pnum)
{
  return mclMlfFeval(_mcr_inst, "DecodeInput", nargout, 2, 7, x, p, vec, x0, p0, x_map, p_map, xnum, pnum);
}

LIB_FOptLib_C_API 
bool MW_CALL_CONV mlfVMVecInput(int nargout, mxArray** valneq, mxArray** valeq, mxArray* 
                                vec, mxArray* d, mxArray* x0, mxArray* p0, mxArray* 
                                x_map, mxArray* p_map, mxArray* xnum, mxArray* pnum, 
                                mxArray* maxVM)
{
  return mclMlfFeval(_mcr_inst, "VMVecInput", nargout, 2, 9, valneq, valeq, vec, d, x0, p0, x_map, p_map, xnum, pnum, maxVM);
}

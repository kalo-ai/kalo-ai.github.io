/*
 * MATLAB Compiler: 4.13 (R2010a)
 * Date: Thu Jun 19 15:28:54 2014
 * Arguments: "-B" "macro_default" "-W" "lib:FOptLib" "-T" "link:lib"
 * "ComputeF.m" "XPFVal.m" "XPFValVecInput.m" "OptimizeXPF.m" "ComputeStress.m"
 * "ComputeVM.m" "DecodeInput.m" "VMVecInput.m" 
 */

#ifndef __FOptLib_h
#define __FOptLib_h 1

#if defined(__cplusplus) && !defined(mclmcrrt_h) && defined(__linux__)
#  pragma implementation "mclmcrrt.h"
#endif
#include "mclmcrrt.h"
#ifdef __cplusplus
extern "C" {
#endif

#if defined(__SUNPRO_CC)
/* Solaris shared libraries use __global, rather than mapfiles
 * to define the API exported from a shared library. __global is
 * only necessary when building the library -- files including
 * this header file to use the library do not need the __global
 * declaration; hence the EXPORTING_<library> logic.
 */

#ifdef EXPORTING_FOptLib
#define PUBLIC_FOptLib_C_API __global
#else
#define PUBLIC_FOptLib_C_API /* No import statement needed. */
#endif

#define LIB_FOptLib_C_API PUBLIC_FOptLib_C_API

#elif defined(_HPUX_SOURCE)

#ifdef EXPORTING_FOptLib
#define PUBLIC_FOptLib_C_API __declspec(dllexport)
#else
#define PUBLIC_FOptLib_C_API __declspec(dllimport)
#endif

#define LIB_FOptLib_C_API PUBLIC_FOptLib_C_API


#else

#define LIB_FOptLib_C_API

#endif

/* This symbol is defined in shared libraries. Define it here
 * (to nothing) in case this isn't a shared library. 
 */
#ifndef LIB_FOptLib_C_API 
#define LIB_FOptLib_C_API /* No special import/export declaration */
#endif

extern LIB_FOptLib_C_API 
bool MW_CALL_CONV FOptLibInitializeWithHandlers(
       mclOutputHandlerFcn error_handler, 
       mclOutputHandlerFcn print_handler);

extern LIB_FOptLib_C_API 
bool MW_CALL_CONV FOptLibInitialize(void);

extern LIB_FOptLib_C_API 
void MW_CALL_CONV FOptLibTerminate(void);



extern LIB_FOptLib_C_API 
void MW_CALL_CONV FOptLibPrintStackTrace(void);

extern LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxComputeF(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);

extern LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxXPFVal(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);

extern LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxXPFValVecInput(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);

extern LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxOptimizeXPF(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);

extern LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxComputeStress(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);

extern LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxComputeVM(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);

extern LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxDecodeInput(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);

extern LIB_FOptLib_C_API 
bool MW_CALL_CONV mlxVMVecInput(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);

extern LIB_FOptLib_C_API 
long MW_CALL_CONV FOptLibGetMcrID();



extern LIB_FOptLib_C_API bool MW_CALL_CONV mlfComputeF(int nargout, mxArray** f, mxArray* x, mxArray* p, mxArray* thick, mxArray* d);

extern LIB_FOptLib_C_API bool MW_CALL_CONV mlfXPFVal(int nargout, mxArray** val, mxArray* x, mxArray* p, mxArray* thick, mxArray* d, mxArray* x0, mxArray* p0, mxArray* f0, mxArray* rhox, mxArray* rhop, mxArray* rhof);

extern LIB_FOptLib_C_API bool MW_CALL_CONV mlfXPFValVecInput(int nargout, mxArray** val, mxArray* vec, mxArray* thick, mxArray* d, mxArray* x0, mxArray* p0, mxArray* f0, mxArray* x_map, mxArray* p_map, mxArray* xnum, mxArray* pnum, mxArray* rhox, mxArray* rhop, mxArray* rhof);

extern LIB_FOptLib_C_API bool MW_CALL_CONV mlfOptimizeXPF(int nargout, mxArray** x, mxArray** p, mxArray** f, mxArray** val, mxArray* x_in1, mxArray* p_in1, mxArray* thick, mxArray* d, mxArray* x0, mxArray* p0, mxArray* f0, mxArray* x_fix, mxArray* p_fix, mxArray* rhox, mxArray* rhop, mxArray* rhof, mxArray* stepTol, mxArray* valTol, mxArray* maxVM);

extern LIB_FOptLib_C_API bool MW_CALL_CONV mlfComputeStress(int nargout, mxArray** stress, mxArray* x, mxArray* p, mxArray* d);

extern LIB_FOptLib_C_API bool MW_CALL_CONV mlfComputeVM(int nargout, mxArray** vm, mxArray* stress);

extern LIB_FOptLib_C_API bool MW_CALL_CONV mlfDecodeInput(int nargout, mxArray** x, mxArray** p, mxArray* vec, mxArray* x0, mxArray* p0, mxArray* x_map, mxArray* p_map, mxArray* xnum, mxArray* pnum);

extern LIB_FOptLib_C_API bool MW_CALL_CONV mlfVMVecInput(int nargout, mxArray** valneq, mxArray** valeq, mxArray* vec, mxArray* d, mxArray* x0, mxArray* p0, mxArray* x_map, mxArray* p_map, mxArray* xnum, mxArray* pnum, mxArray* maxVM);

#ifdef __cplusplus
}
#endif
#endif

/*
 * MATLAB Compiler: 5.1 (R2014a)
 * Date: Mon Nov 03 16:30:11 2014
 * Arguments: "-B" "macro_default" "-W" "lib:TOMLAB_export" "-T" "link:lib"
 * "TOMLAB_export" "nlp_cdcS" "nlp_fg" "ktr_grad" 
 */

#ifndef __TOMLAB_export_h
#define __TOMLAB_export_h 1

#if defined(__cplusplus) && !defined(mclmcrrt_h) && defined(__linux__)
#  pragma implementation "mclmcrrt.h"
#endif
#include "mclmcrrt.h"
#ifdef __cplusplus
extern "C" {
#endif

#if defined(__SUNPRO_CC)
/* Solaris shared libraries use __global, rather than mapfiles
 * to define the API exported from a shared library. __global is
 * only necessary when building the library -- files including
 * this header file to use the library do not need the __global
 * declaration; hence the EXPORTING_<library> logic.
 */

#ifdef EXPORTING_TOMLAB_export
#define PUBLIC_TOMLAB_export_C_API __global
#else
#define PUBLIC_TOMLAB_export_C_API /* No import statement needed. */
#endif

#define LIB_TOMLAB_export_C_API PUBLIC_TOMLAB_export_C_API

#elif defined(_HPUX_SOURCE)

#ifdef EXPORTING_TOMLAB_export
#define PUBLIC_TOMLAB_export_C_API __declspec(dllexport)
#else
#define PUBLIC_TOMLAB_export_C_API __declspec(dllimport)
#endif

#define LIB_TOMLAB_export_C_API PUBLIC_TOMLAB_export_C_API


#else

#define LIB_TOMLAB_export_C_API

#endif

/* This symbol is defined in shared libraries. Define it here
 * (to nothing) in case this isn't a shared library. 
 */
#ifndef LIB_TOMLAB_export_C_API 
#define LIB_TOMLAB_export_C_API /* No special import/export declaration */
#endif

extern LIB_TOMLAB_export_C_API 
bool MW_CALL_CONV TOMLAB_exportInitializeWithHandlers(
       mclOutputHandlerFcn error_handler, 
       mclOutputHandlerFcn print_handler);

extern LIB_TOMLAB_export_C_API 
bool MW_CALL_CONV TOMLAB_exportInitialize(void);

extern LIB_TOMLAB_export_C_API 
void MW_CALL_CONV TOMLAB_exportTerminate(void);



extern LIB_TOMLAB_export_C_API 
void MW_CALL_CONV TOMLAB_exportPrintStackTrace(void);

extern LIB_TOMLAB_export_C_API 
bool MW_CALL_CONV mlxTOMLAB_export(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);

extern LIB_TOMLAB_export_C_API 
bool MW_CALL_CONV mlxNlp_cdcS(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);

extern LIB_TOMLAB_export_C_API 
bool MW_CALL_CONV mlxNlp_fg(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);

extern LIB_TOMLAB_export_C_API 
bool MW_CALL_CONV mlxKtr_grad(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);



extern LIB_TOMLAB_export_C_API bool MW_CALL_CONV mlfTOMLAB_export(int nargout, mxArray** x, mxArray** fval, mxArray* fun, mxArray* grad, mxArray* hess, mxArray* hessPattern, mxArray* x0, mxArray* linA, mxArray* linB, mxArray* nonlconPattern, mxArray* nonlcon, mxArray* nonlcon_grad, mxArray* eqConNum, mxArray* neqConNum);

extern LIB_TOMLAB_export_C_API bool MW_CALL_CONV mlfNlp_cdcS(int nargout, mxArray** Mode, mxArray** c, mxArray** z, mxArray* x, mxArray* Prob, mxArray* Mode_in1, mxArray* nState);

extern LIB_TOMLAB_export_C_API bool MW_CALL_CONV mlfNlp_fg(int nargout, mxArray** Mode, mxArray** f, mxArray** g, mxArray* x, mxArray* Prob, mxArray* Mode_in1, mxArray* nState);

extern LIB_TOMLAB_export_C_API bool MW_CALL_CONV mlfKtr_grad(int nargout, mxArray** g, mxArray** dc, mxArray* x, mxArray* Prob);

#ifdef __cplusplus
}
#endif
#endif

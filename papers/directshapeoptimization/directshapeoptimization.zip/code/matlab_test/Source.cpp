#include <iostream>

int main()
{
	std::cout<<"1";
	return 0;
}
#include "mclmcrrt.h"
#include "..\matlab_fmincon\fmincon_export.h"
#include <vector>
#include <iostream>

using namespace std;

vector<double> gRef;

void SimpleF(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
	vector<double> val(gRef.size());
	double* pr = mxGetPr(prhs[0]);
	assert(mxGetM(prhs[0])*mxGetN(prhs[0])==gRef.size());
	double diff = 0;
	for (int i=0; i<(int)gRef.size(); i++)
		diff += (pr[i]-gRef[i])*(pr[i]-gRef[i]);
	plhs[0] = mxCreateDoubleScalar(diff);
}

void SimpleCon(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
	plhs[0] = mxCreateDoubleMatrix(0, 0, mxREAL);
	plhs[1] = mxCreateDoubleMatrix(0, 0, mxREAL);
}

int main(int argc, char* argv[])
{
	mclInitializeApplication(NULL,0);
	fmincon_exportInitialize();

	gRef.resize(2);
	gRef[0] = 1.0;
	gRef[1] = 2.0;

	mxArray* x0 = mxCreateDoubleMatrix(2, 1, mxREAL);
	double* pr = mxGetPr(x0);
	pr[0] = 0.0;
	pr[1] = 1.0;

	mxArray* x_out = mxCreateDoubleMatrix(2, 1, mxREAL);
	mxArray* fval = mxCreateDoubleScalar(0);

	mxArray *Aeq = mxCreateDoubleMatrix(0, 0, mxREAL);
	mxArray *Beq = mxCreateDoubleMatrix(0, 0, mxREAL);

	mxArray* f = mclCreateSimpleFunctionHandle(SimpleF);
	mxArray* nonlcon = mclCreateSimpleFunctionHandle(SimpleCon);

	mlfFmincon_export(2, &x_out, &fval, f, x0, Aeq, Beq, nonlcon);

	pr = mxGetPr(x_out);
	cout<<"x_out: "<<pr[0]<<","<<pr[1]<<endl;
	cout<<"f:"<<mxGetScalar(fval)<<endl;
	char c;
	cin>>c;
	return 0;
}

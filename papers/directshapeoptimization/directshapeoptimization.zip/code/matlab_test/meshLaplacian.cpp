#include "TriMesh.h"
#include "TriMesh_algo.h"
#include "DijkstraForGeodesics.h"
#include "MeshSegmentationFeatures.h"

#ifdef USE_MATLAB
#include "matrix.h"

meshLaplacianReturnData meshLaplacian(TriMesh *m, Engine *matlabEng, float scale, int maxEigenFunction, float **allgeodDistances, int **allgeodVertices, int maxsize) {
	meshLaplacianReturnData ret;
	float h = scale / 3.0f;
	double sh = 1.0f / sqrt(2.0f * M_PI * h * h);
	double h2 = 2 * h * h;
	mwSize nzmax = 0;

	for (int i = 0; i < m->vertices.size(); i++) {
		for (int ij = 0; ij < maxsize; ij++) {
			float dist = allgeodDistances[i][ij];
			if (dist == FLT_MAX) {
				continue;
			}
			double expterm = (dist*dist) / h2;
			if (expterm < 5.0f) {
				nzmax++;
			}
		}
	}

	mxArray *laplacian = mxCreateSparse(m->vertices.size(), m->vertices.size(), nzmax, mxREAL);
	double *laplacianData = mxGetPr(laplacian);
	mwIndex *rowIndex = mxGetIr(laplacian);
	mwIndex *columnPos = mxGetJc(laplacian);
	int ii = 0;

	for (int i = 0; i < m->vertices.size(); i++) {
		columnPos[i] = ii;
		for (int ij = 0; ij < maxsize; ij++) {
			float dist = allgeodDistances[i][ij];
			if (dist == FLT_MAX) {
				continue;
			}
			double expterm = (dist*dist) / h2;
			if (expterm < 5.0f) {
				laplacianData[ii] = sh * exp( -expterm );
				rowIndex[ii] = allgeodVertices[i][ij];
				ii++;
			}
		}
	}
	columnPos[m->vertices.size()] = ii;

	engPutVariable(matlabEng, "L", laplacian);	


	////int state = engEvalString(matlabEng, "L = (L + L')/2"); // shit can happen
	////if (state != 0) {
	////	std::cerr << "L symmetrization command failed\n" << std::endl;
	////	return ret;
	////}
	int state = engEvalString(matlabEng, "[EIGENVECTORS EIGENVALUES] = eigs(L, 300, 'LR');");
	if (state != 0) {
		std::cerr << "eigs command failed\n" << std::endl;
		return ret;
	}
	mxDestroyArray( laplacian );
	state = engEvalString(matlabEng, "EIGENVALUES = diag(EIGENVALUES); EIGENVALUES = abs(EIGENVALUES);");
	if (state != 0) {
		std::cerr << "diag and abs commands failed\n" << std::endl;
		return ret;
	}
	state = engEvalString(matlabEng, "HKS = []; for t = 4*log( linspace( 10/EIGENVALUES(200), 10/EIGENVALUES(2), 10 ) ) HKS(:, end+1) = sum( scale_cols(EIGENVECTORS.^2, min(exp(-t * EIGENVALUES), 1e+300) ), 2); end");
	if (state != 0) {
		std::cerr << "hks computation command failed\n" << std::endl;
		return ret;
	}
	state = engEvalString(matlabEng, "HKStr = []; for t = 4*log( linspace( 10/EIGENVALUES(200), 10/EIGENVALUES(2), 10 ) ) HKStr(end+1) = sum( min(exp(-t * abs(EIGENVALUES)), 1e+300) ); end"); 
	if (state != 0) {
		std::cerr << "hks trace computation command failed\n" << std::endl;
		return ret;
	}
	state = engEvalString(matlabEng, "HKS = scale_cols(HKS, 1./HKStr);");
	if (state != 0) {
		std::cerr << "hks normalization command failed\n" << std::endl;
		return ret;
	}
	state = engEvalString(matlabEng, "HKS = log(abs(HKS)+1e-300);");
	if (state != 0) {
		std::cerr << "log abs hks command failed\n" << std::endl;
		return ret;
	}
	state = engEvalString(matlabEng, "clear EIGENVECTORS;");
	if (state != 0) {
		std::cerr << "clear eigenvectors command failed\n" << std::endl;
		return ret;
	}

	//state = engEvalString(matlabEng, "EIGENVECTORS = scale_cols(EIGENVECTORS, 1 ./ sqrt(EIGENVALUES));");
	//if (state != 0) {
	//	std::cerr << "scale_cols for eigenvectors command failed\n" << std::endl;
	//	return ret;
	//}
	//state = engEvalString(matlabEng, "EIGENVECTORS = abs(EIGENVECTORS);");
	//if (state != 0) {
	//	std::cerr << "abs eigenvectors command failed\n" << std::endl;
	//	return ret;
	//}
	//ret.eigen = engGetVariable(matlabEng,"EIGENVECTORS");

	ret.hks = engGetVariable(matlabEng,"HKS");
	return ret;
}
#endif
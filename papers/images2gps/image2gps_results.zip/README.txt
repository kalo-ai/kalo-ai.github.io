Image Sequence Geolocation with Human Travel Priors
	      Supplemental Material


This folder contains additional data that provide more information about our
examples and results.  All images in this archive have been downsampled/compressed
for reducing the size of files distributed in this archive. 

1. Toy dataset matches.
=======================

toy_dataset_fig6/
toy_dataset_fig7/

These folders contain the raw matches {I_m} for each image in the two
toy datasets in our paper (Figures 6 and 7). The test images and their
their raw matches are in the corresponding subfolders in the same
order they appear in the paper. On the bottom left of each raw match,
we show the location and the associated weight w_{km} (Equation 7).

For the Figure 6 example, each image has many matches from throughout
the world, but only Hawaii is consistent with all three images
(including the flower, beach, and waterfall).  These images are taken
from user 25812829 (see below for entire dataset).  We designed this
dataset to illustrate the algorithm's ability to localize without
landmarks.  However, this is not an unusual case; we found it easy to
find subsets of this user with this behavior (no peak in SIG, correct
peak in SEQ)."

In Figure 7, the top two matches for the first image are both taken
from exactly the same viewpoint at the Acropolis, and these two
matches dominate the weights; hence, they largely determine the
location of this image.  The second image's matches include several
taken from the same island of Santorini (particularly images 3, 15,
and 27), with a similar but not identical view to the test image.


2. Results for our test users.  ==============================

users/

Each subfolder contains a "route.jpg" file that shows the route taken by the
user (in red), and the route estimated by our algorithm (in blue).  

Each image file contains (from top to bottom):
 - a downsampled version of the original test image
 - the single-image match distribution P(L_k|I_k), and
 - the posterior distribution gamma = P(L_k|I_1:N).
The cross shows the ground-truth location of the image.

The users that correspond to Figure 10 are:

Top:      users/97304820@N00/
Middle:   users/25812829@N00/
Bottom:   users/24825559@N04/
This archive contains code for training our CNN model that generates procedural model parameters from sketches with Caffe, and code for extracting CNN features from given sketches.  The code is under GPL license (see LICENSE.txt). 

You need to have caffe compiled on your machine along with a procedural model for the code to work.

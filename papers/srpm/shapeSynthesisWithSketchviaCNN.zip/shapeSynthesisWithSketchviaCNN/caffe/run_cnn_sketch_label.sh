#!/bin/bash

nvidia-smi

exeRootDir=/home/caffe/.build_release
rootDir=/home/train/containers

$exeRootDir/tools/caffe train -solver $rootDir/solver/solver_sketch_label.prototxt -weights $rootDir/pre_train_model/bvlc_alexnet.caffemodel

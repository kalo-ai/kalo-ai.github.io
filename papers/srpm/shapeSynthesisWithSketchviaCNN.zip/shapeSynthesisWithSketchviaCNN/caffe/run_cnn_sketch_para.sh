#!/bin/bash

nvidia-smi

exeRootDir=/home/caffe/.build_release
rootDir=/home/train/containers

$exeRootDir/tools/caffe train -solver $rootDir/solver/solver_sketch_para.prototxt -weights $rootDir/snapshoot/caffenet_sketch_label_iter_20000.caffemodel

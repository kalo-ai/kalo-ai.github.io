%% WRITING TO HDF5
function write_sketch_data_all( mean_image, input_path,intput_path_label,intput_path_para, filename, paraSize)
im_image = mean_image;
myfile = ls(input_path);
num_total_samples= size(myfile,1) - 2
data_disk=rand(227,227,3,num_total_samples); 
label_disk=rand(1,num_total_samples); 
value_disk=rand(paraSize,num_total_samples); 
size(find(isnan(data_disk)))
for i = 3:size(myfile,1)
    file_name = myfile(i,:); 
    [pathstr,name,ext] = fileparts(file_name);
    input_file_name_label = strcat(intput_path_label,'\');
    input_file_name_label = strcat(input_file_name_label,name);
    input_file_name_label = strcat(input_file_name_label,'.parameters');
	lable = load(input_file_name_label)
    input_file_name_para = strcat(intput_path_para,'\');
    input_file_name_para = strcat(input_file_name_para,name);
    input_file_name_para = strcat(input_file_name_para,'.parameters');
	value = load(input_file_name_para)
    input_image_name = strcat(input_path,'\');
    input_image_name = strcat(input_image_name,name);
    input_image_name = strcat(input_image_name,'.png');
    im = imread(input_image_name);
    im = imresize(im, [227 227]);
    if(size(im,3) == 1)
         imdata = im;
         imdata = 1 - double(imdata)/255;
         imdata = imdata /(max(max(imdata)));
         data_disk(:,:,i - 2) = imdata - im_image;
    end
     if(size(im,3) == 3)
         imdata = 1 - double(im)/255;
         imdata = imdata /(max(max(max(imdata))));
         data_disk(:,:,:,i - 2) = imdata - im_image;
     end
    label_disk(:,i - 2) = label;
    value_disk(:,i - 2) = value;
end 
chunksz=10
created_flag=false;
totalct=0;
for batchno=1:num_total_samples/chunksz
  fprintf('batch no. %d\n', batchno);
  last_read=(batchno-1)*chunksz;
  % to simulate maximum data to be held in memory before dumping to hdf5 file 
  batchdata=data_disk(:,:,:,last_read+1:last_read+chunksz); 
  batchlabs=label_disk(:,last_read+1:last_read+chunksz);
  batchvals=value_disk(:,last_read+1:last_read+chunksz);
  % store to hdf5
  startloc=struct('dat',[1,1,1,totalct+1], 'lab', [1,totalct+1],'val', [1,totalct+1]);
  curr_dat_sz=store2hdf5_n(filename, batchdata, batchlabs, batchvals,~created_flag, startloc, chunksz); 
  created_flag=true;% flag set so that file is created only once
  totalct=curr_dat_sz(end);% updated dataset size (#samples)
end

h5disp(filename);

%% READING FROM HDF5

% Read data and labels for samples #1000 to 1999
data_rd=h5read(filename, '/data', [1 1 1 1000], [227, 227, 3, 1000]);
label_rd=h5read(filename, '/label', [1 1000], [1, 1000]);
value_rd = h5read(filename, '/value', [1 1000], [paraSize, 1000]);
fprintf('Testing ...\n');
try 
  assert(isequal(data_rd, single(data_disk(:,:,:,1000:1999))), 'Data do not match');
  assert(isequal(label_rd, single(label_disk(:,1000:1999))), 'Labels do not match');
  assert(isequal(value_rd, single(value_disk(:,1000:1999))), 'values do not match');
  fprintf('Success!\n');
catch err
  fprintf('Test failed ...\n');
  getReport(err)
end

%delete(filename);

% CREATE list.txt containing filename, to be used as source for HDF5_DATA_LAYER
FILE=fopen('list.txt', 'w');
fprintf(FILE, '%s', filename);
fclose(FILE);
fprintf('HDF5 filename listed in %s \n', 'list.txt');

% NOTE: In net definition prototxt, use list.txt as input to HDF5_DATA as: 
% layer {
%   name: "data"
%   type: "HDF5Data"
%   top: "data"
%   top: "labelvec"
%   hdf5_data_param {
%     source: "/path/to/list.txt"
%     batch_size: 64
%   }
% }
